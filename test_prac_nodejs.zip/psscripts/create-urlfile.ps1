# ref https://raw.githubusercontent.com/nicolonsky/Techblog/master/IntuneShortcut/CreateDesktopIcon.ps1
[CmdletBinding()]
Param (
    [Parameter(Mandatory = $false)]
    [String]$TempDestination,

    [Parameter(Mandatory = $true)]
    [String]$Url,

    [Parameter(Mandatory = $true)]
    [String]$ShortcutDisplayName    
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

try{
    $destinationPath = Join-Path -Path $TempDestination -ChildPath "$ShortcutDisplayName.url"
    $Shell = New-Object -ComObject ("WScript.Shell")
    $Favorite = $Shell.CreateShortcut($destinationPath)
    $Favorite.TargetPath = $Url;
    $Favorite.Save()

    return @{success = $true } | ConvertTo-Json
}
catch{
    return @{success = $false; message = $_.Exception.Message } | ConvertTo-Json
}
