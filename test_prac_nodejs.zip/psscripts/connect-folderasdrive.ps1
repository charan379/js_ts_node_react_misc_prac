<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/08
	 Created by:   	Conguide GmbH
	 Filename:     	connect-folderasdrive.ps1
	===========================================================================
	.DESCRIPTION
    Maps a local folder as drive - used together with addspodrive.ps1
#>

param(
    [Parameter(mandatory=$true)]
    $driveLetter,
    [Parameter(mandatory=$true)]
    $path,
    $driveName = $null
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

try{

    try{
        subst "$($driveLetter.ToLower()):" /D | Out-Null
    }
    catch{}

    if (!(Test-Path -Path $($path))) {
        # we create the path as dummy path if this does not exist
        New-Item -ItemType directory -Path "$($path)" | Out-Null
    }

    subst "$($driveLetter.ToLower()):" "$($path)" | Out-Null
    
    if (![string]::IsNullOrEmpty($driveName)) {
        $shell = New-Object -ComObject Shell.Application
        $shell.NameSpace("$($driveLetter):").Self.Name = $driveName
    }

    return @{success = $true;} | ConvertTo-Json
}
catch{
    return @{success = $false; message = $Error[0].Exception.Message } | ConvertTo-Json
}

