<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	add-printer.ps1
	===========================================================================
	.DESCRIPTION
		Installs and connects to given printers.

    .History
        7/2023 - Rev. 2 Updated to use CredMan instead of cmdkey
#>

param (
    [Parameter(Mandatory = $True)]
    [string]$Printername,
    [string]$PrinterDriverName,
    [Parameter(Mandatory = $True)]
    [string]$PrinterHostAddress,
    [int]$PrinterPort,
    [string]$LprHostAddress,
    [string]$LprQueueName,
    [bool]$LprByteCounting = $false,
    [bool]$NeedsCredentials = $false
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

$returnValue = 0

Write-Verbose "Executing directory:$($PSScriptRoot)"

$msgTable = Data {
    ConvertFrom-StringData -StringData @'
    formtitle = Connect to {0}
    usernamelabel = Username:
    passwordlabel = Password:
    okButton = OK
    cancelButton = Cancel
    errorMsgNoCredentialsTitle = Error
    errorMsgNoCredentials = {0} won't be available because you have not entered any credentials.
    genericError = Connection failed. Reason: {0}
    successMessage = Service Tool Connection
    successMessageDetails = Printer {0}: is now available.
    alreadyExists = The specified printer already exists.
'@
}

try {
    Import-LocalizedData -BindingVariable msgTable -ErrorAction SilentlyContinue
}
catch {}

$portname = "Port$Printername" 
$portname = $portname -replace '\s', ''

$serverResource = "$(([URI]$PrinterHostAddress).Host)"

# Sanity checks
if ($PrinterHostAddress -and $LprHostAddress) {
    throw "Both PrinterHost and LprHost were specified. Only one address can be specified. Exiting"
}

if ($null -ne (Get-Printer -Name "$($Printername)" -ErrorAction SilentlyContinue)){
     return @{success = $false; message = $msgTable.alreadyExists} | ConvertTo-Json 
}

try {
    if ($PrinterDriverName) {
        Add-PrinterDriver -Name $PrinterDriverName
    }
}
catch {
    Write-Warning "Error installing printer driver"
}



#region PwdManager

[String] $credentialManager = @"
    using System;
    using System.Runtime.InteropServices;
    using System.Collections;

    public class CredMan
    {
        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredReadW", CharSet = CharSet.Unicode)]
        private static extern bool CredReadW([In] string target, [In] uint type, [In] int flag, out IntPtr credential);
        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredFree")]
        private static extern void CredFree([In] IntPtr cred);

        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredWriteW", CharSet = CharSet.Unicode)]
        private static extern bool CredWrite([In] ref CredentialMem userCredential, [In] int flags);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct Credential
        {
            public uint Flags;
            public uint Type;
            public IntPtr TargetName;
            public IntPtr Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public UInt32 CredentialBlobSize;
            public IntPtr CredentialBlob;
            public UInt32 Persist;
            public UInt32 AttributeCount;
            public IntPtr Attributes;
            public IntPtr TargetAlias;
            public IntPtr UserName;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct CredentialMem
        {
            public int flags;
            public int type;
            public string targetName;
            public string comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME lastWritten;
            public int credentialBlobSize;
            public IntPtr credentialBlob;
            public int persist;
            public int attributeCount;
            public IntPtr credAttribute;
            public string targetAlias;
            public string userName;
        }
        
        public class CredReturn
        {
            public string UserName;
            public string Password;
            public DateTime LastModified;
            public string Target;
        }

        public static void SetUserCredential(string target, string userName, string password)
        {
            CredentialMem userCredential = new CredentialMem();

            userCredential.targetName = target;
            userCredential.type = 1;
            userCredential.userName = userName;
            userCredential.attributeCount = 0;
            userCredential.persist = 3;
            byte[] bpassword = System.Text.Encoding.Unicode.GetBytes(password);
            userCredential.credentialBlobSize = (int)bpassword.Length;
            userCredential.credentialBlob = Marshal.StringToCoTaskMemUni(password);
            if (!CredWrite(ref userCredential, 0))
            {
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            }
        }

        public static CredReturn GetCreds(string target)
        {
            IntPtr p;
            string password = null;
            string username = null;
            CredReturn cred = null;

            if (CredReadW(target, /*GENERIC type*/ 1, 0, out p))
            {
                Credential c = (Credential)Marshal.PtrToStructure(p, typeof(Credential));
                password = Marshal.PtrToStringUni(c.CredentialBlob, (int)(c.CredentialBlobSize / 2));
                username = Marshal.PtrToStringUni(c.UserName);
                CredFree(p);

                if (!String.IsNullOrEmpty(username))
                {
                    cred = new CredReturn();
                    cred.UserName = username;
                    cred.Password = password;
                    cred.Target = target;
                    cred.LastModified = WindowsTimeToDateTime(c.LastWritten);
                }
            }

            return cred;
        }

        public static DateTime WindowsTimeToDateTime(System.Runtime.InteropServices.ComTypes.FILETIME time)
        {
            ulong high = (ulong)time.dwHighDateTime;
            uint low = (uint)time.dwLowDateTime;
            long fileTime = (long)((high << 32) + low);
            try
            {
                return DateTime.FromFileTimeUtc(fileTime);
            }
            catch
            {
                return DateTime.FromFileTimeUtc(0xFFFFFFFF);
            }
        }
    }
"@

#endregion

try {
    Add-Type $credentialManager -ErrorAction Continue -IgnoreWarnings
}
catch {}

$credentialResult = [CredMan]::GetCreds($serverResource)

if ($NeedsCredentials -and $null -eq $credentialResult) {
    try {

    
        [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
        [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    
        $form = New-Object System.Windows.Forms.Form
        $form.Text = $msgTable.formtitle -f $serverResource
        $form.Size = New-Object System.Drawing.Size(300, 200)
        $form.StartPosition = 'CenterScreen'
        $form.MinimizeBox = $False
        $form.MaximizeBox = $False
        $form.FormBorderStyle = 'FixedDialog'

        try {
            $scriptPath = Split-Path $MyInvocation.MyCommand.Path -Parent
            $iconBase64 = [Convert]::ToBase64String((Get-Content "$($scriptPath)\icon.ico" -Encoding Byte -ErrorAction Stop))
            $iconBytes = [Convert]::FromBase64String($iconBase64)
            $stream = New-Object IO.MemoryStream($iconBytes, 0, $iconBytes.Length)
            $stream.Write($iconBytes, 0, $iconBytes.Length);
            $form.Icon = [System.Drawing.Icon]::FromHandle((New-Object System.Drawing.Bitmap -Argument $stream).GetHIcon())
        }
        catch {

        }

        $OKButton = New-Object System.Windows.Forms.Button
        $OKButton.Location = New-Object System.Drawing.Point(75, 120)
        $OKButton.Size = New-Object System.Drawing.Size(75, 23)
        $OKButton.Text = $msgTable.okButton
        $OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $form.AcceptButton = $OKButton
        $form.Controls.Add($OKButton)

        $CancelButton = New-Object System.Windows.Forms.Button
        $CancelButton.Location = New-Object System.Drawing.Point(150, 120)
        $CancelButton.Size = New-Object System.Drawing.Size(75, 23)
        $CancelButton.Text = $msgTable.cancelButton
        $CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $form.CancelButton = $CancelButton
        $form.Controls.Add($CancelButton)

        $label = New-Object System.Windows.Forms.Label
        $label.Location = New-Object System.Drawing.Point(10, 20)
        $label.Size = New-Object System.Drawing.Size(280, 20)
        $label.Text = $msgTable.usernamelabel
        $form.Controls.Add($label)

        $textBox = New-Object System.Windows.Forms.TextBox
        $textBox.Location = New-Object System.Drawing.Point(10, 40)
        $textBox.Size = New-Object System.Drawing.Size(260, 20)
        $textBox.Text = $userId
        $form.Controls.Add($textBox)

        $label2 = New-Object System.Windows.Forms.Label
        $label2.Location = New-Object System.Drawing.Point(10, 60)
        $label2.Size = New-Object System.Drawing.Size(280, 20)
        $label2.Text = $msgTable.passwordlabel
        $form.Controls.Add($label2)

        $textBox2 = New-Object System.Windows.Forms.MaskedTextBox
        $textBox2.PasswordChar = '*'
        $textBox2.Location = New-Object System.Drawing.Point(10, 80)
        $textBox2.Size = New-Object System.Drawing.Size(260, 20)
        $form.Controls.Add($textBox2)

        $form.Topmost = $true

        $form.Add_Shown( { $textBox.Select() })
        $result = $form.ShowDialog()

        if ($result -eq [System.Windows.Forms.DialogResult]::OK -and ![String]::IsNullOrEmpty($textBox2.Text) -and ![String]::IsNullOrEmpty($textBox.Text)) {
            $user = $textBox.Text
            $pass = $textBox2.Text

            [CredMan]::SetUserCredential($serverResource,$user,$pass)
        }
        else {
            $OUTPUT = [System.Windows.Forms.MessageBox]::Show( ($msgTable.errorMsgNoCredentials -f $serverResource), $msgTable.errorMsgNoCredentialsTitle , 0) 
            return @{success = $false; message = ($msgTable.errorMsgNoCredentials -f $serverResource) } | ConvertTo-Json
        }
    }
    catch {
        return @{success = $false; message = ($msgTable.genericError -f $Error[0]) } | ConvertTo-Json
    }
}

# We assume if no printer driver name was specified that a print server will take care of driver management
if ([string]::IsNullOrEmpty($PrinterDriverName)) {
    try{
        Add-Printer -ConnectionName "$($PrinterHostAddress)"  -ErrorAction Stop | Rename-Printer -NewName $($Printername) 
        
        # $wmiNet = new-Object -com WScript.Network 
        # $wmiNet.AddWindowsPrinterConnection($PrinterHostAddress) 
        # (New-Object -ComObject WScript.Network).SetDefaultPrinter($Printername) 
        
        return @{success = $true } | ConvertTo-Json
    }
    catch{
        return @{success = $false; message= $Error[0].Exception.Message } | ConvertTo-Json
    }
    
}

$portExists = Get-Printerport -Name "$portname" -ErrorAction SilentlyContinue

# Add printer port
if (-not $portExists) {
    if ($LprHostAddress) {

    }
    elseif ($PrinterHostAddress) {
        if ($PrinterPort) {
            Add-PrinterPort -name "$portName" -PrinterHostAddress  "$PrinterHostAddress" -PortNumber "$PrinterPort"
        }
        else {
            Add-PrinterPort -name "$portName" -PrinterHostAddress  "$PrinterHostAddress"
        }
    }
    else {
        throw "At least one HostAddress is needed. Execution stopped."
    }
}

# Map printer
$printDriverExists = Get-PrinterDriver -name "$PrinterDriverName" -ErrorAction SilentlyContinue

if ($printDriverExists) {
    try{
        Add-Printer -Name "$Printername" -PortName "$portName" -DriverName "$PrinterDriverName"
    }
    catch{
        return @{success = $false; message= $Error[0].Exception } | ConvertTo-Json
    }
    
}
else {
    return @{success = $false; message= $Error[0].Exception } | ConvertTo-Json
}

return @{success = $true } | ConvertTo-Json