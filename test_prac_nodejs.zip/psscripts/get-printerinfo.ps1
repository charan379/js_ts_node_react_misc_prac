
<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	get-printerinfo.ps1
	===========================================================================
	.DESCRIPTION
    Returns a list of statistics regarding printer drivers and ports
#>

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

$returnValue = [pscustomobject]@{}

try{
    $printers = Get-Printer -ErrorAction Continue
    $ports = Get-PrinterPort -ErrorAction Continue
    $drivers = Get-PrinterDriver -ErrorAction Continue

    $returnValue = [pscustomobject]@{
        printers = $printers
        ports = $ports
        drivers = $drivers
    }
}
catch{
    $returnValue = [pscustomobject]@{
        printers = ""
        ports = ""
        drivers = ""
    }
}

return ConvertTo-JSON $returnValue