<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	get-credentialmanagerinfo.ps1
	===========================================================================
	.DESCRIPTION
    Checks if credentials are already stored for the given resource
#>

Param(
    [Parameter(Mandatory = $true)]
    [string]$serverResource
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

$returnValue = [pscustomobject]@{
    storedCredentialsExists = $false
    info = ""
}

# testing
# return @"
# {
#     "storedCredentialsExists":  true,
#     "info":  {
#                  "UserName":  "admin",
#                  "Password":  "",
#                  "LastModified":  "\/Date(1628083141297)\/",
#                  "Target":  "backuptiger"
#              }
# }
# "@ 

[String] $credentialManager = @"
using System;
using System.Runtime.InteropServices;
using System.Collections;

public class CredMan {
	[DllImport("Advapi32.dll", SetLastError=true, EntryPoint="CredReadW", CharSet=CharSet.Unicode)]
	private static extern bool CredReadW([In] string target, [In] uint type, [In] int flag, out IntPtr credential);
	[DllImport("Advapi32.dll", SetLastError=true, EntryPoint="CredFree")]
	private static extern void CredFree([In] IntPtr cred);
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
	public struct Credential {
		public uint Flags;
		public uint Type;
		public IntPtr TargetName;
		public IntPtr Comment;
		public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
		public UInt32 CredentialBlobSize;
		public IntPtr CredentialBlob;
		public UInt32 Persist;
		public UInt32 AttributeCount;
		public IntPtr Attributes;
		public IntPtr TargetAlias;
		public IntPtr UserName;        
	}

    public class CredReturn {
        public string UserName;
        public string Password;
        public DateTime LastModified;
        public string Target;
    }

	public static CredReturn GetCreds(string target, bool hidePassword) {
		IntPtr p;
		string password = null;
        string username = null;
        CredReturn cred = null;

		if (CredReadW(target, /*GENERIC type*/ 1, 0, out p)) {
			Credential c = (Credential) Marshal.PtrToStructure(p, typeof(Credential));
			password = Marshal.PtrToStringUni(c.CredentialBlob, (int) (c.CredentialBlobSize / 2));
            username = Marshal.PtrToStringUni(c.UserName);
			CredFree(p);

            if (!String.IsNullOrEmpty (username)){
                cred = new CredReturn();
                cred.UserName = username;
                cred.Password = hidePassword ? "HIDDEN" : password;
                cred.Target = target;
                cred.LastModified = WindowsTimeToDateTime(c.LastWritten);
            }            
		}

        return cred;
	}

    public static DateTime WindowsTimeToDateTime(System.Runtime.InteropServices.ComTypes.FILETIME time)
    {
        ulong high = (ulong)time.dwHighDateTime;
        uint low = (uint)time.dwLowDateTime;
        long fileTime = (long)((high << 32) + low);
        try
        {
            return DateTime.FromFileTimeUtc(fileTime);
        }
        catch
        {
            return DateTime.FromFileTimeUtc(0xFFFFFFFF);
        }
    }
}
"@

try {
    Add-Type $credentialManager -ErrorAction Continue
}
catch {}

try{
    $hostaddress = "$(([URI]$serverResource).Host)"
    $storedCredentialExists = $false
    
    # cannot return last modified time
    # cmdkey /list:$hostaddress | ForEach-Object { if ($_ -like "*Target:*") { $storedCredentialExists = $true } }

    $credentialInfo = [CredMan]::GetCreds($hostaddress, $true) # hide password

    $returnValue.info = $credentialInfo
    $returnValue.storedCredentialsExists = $storedCredentialExists
}
catch{}

return ConvertTo-JSON $returnValue