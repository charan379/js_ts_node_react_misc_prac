<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	show-printersettings.ps1
	===========================================================================
	.DESCRIPTION
    Shows printer management dialog window (Windows only)
#>


Start-Process "ms-settings:printers"