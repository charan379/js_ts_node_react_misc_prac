**Command**

**.\mapdrive.ps1 -removeOnly $true -sourcePath location**

**Output (JSON)**

```powershell
{
    "enabled":  false
}
```

-----

tbd