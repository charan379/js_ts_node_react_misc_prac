**Command**

**.\register-autodrivemapper.ps1 -mode Status**

Returns the current install status for key

**HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\Service Tool Mapper**

**Output (JSON)**

```powershell
{
    "enabled":  false
}
```

-----

**Command**

**.\register-autodrivemapper.ps1 -mode Add**

Creates a reg key under **HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run**

This will execute the command (slightly delayed) after each logon.

**Output (JSON)**

```powershell
{
    "value":  "cmd /c start /min \"\" powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass \"\u0026 \"\"C:\\Program Files\\Service Tool\\resources\\psscripts\\start-autodrivemapper.ps1\"\"\"",
    "enabled":  true
}
```

------

**Command**

**.\register-autodrivemapper.ps1 -mode Remove**

Removes reg key under  **HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\Service Tool Mapper**

**Output (JSON)**

```powershell
{
    "enabled":  false
}
```

