**Command**

**.\start-autodrivemapper.ps1 **

Returns the current install status for key

**HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\Service Tool Mapper**

**Output (JSON)**

```powershell
{
    "enabled":  false
}
```

-----

**Command**