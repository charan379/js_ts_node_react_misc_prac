<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	get-smbdriveinfo.ps1
	===========================================================================
	.DESCRIPTION
    Checks if a drive is already mapped for the given resource
#>

Param(
    [Parameter(Mandatory = $true)]
    [string]$serverResource
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

$returnValue = $returnValue = [pscustomobject]@{
    exists = $false
}

try{
    $hostaddress = "$(([URI]$serverResource).Host)"

    $driveInfo = Get-SmbMapping | where-object { $_.RemotePath -and $_.RemotePath.Replace('\', '').startsWith("$hostaddress") }
    
    if ($null -ne $driveInfo){
        $returnValue.exists = $true
    }
}
catch{}

return ConvertTo-JSON $returnValue