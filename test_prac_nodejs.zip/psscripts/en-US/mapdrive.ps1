ConvertFrom-StringData -StringData @'
    formtitle = Connect to {0} ({1}:)
    usernamelabel = Username:
    passwordlabel = Password:
    okButton = OK
    cancelButton = Cancel
    errorMsgNoCredentialsTitle = Error
    errorMsgNoCredentials = {0}: won't be available because you have not entered any credentials
    genericError = Connection failed. Reason: {0}
    successMessage = Service Tool Connection
    successMessageDetails = Drive {0}: is now available.
'@