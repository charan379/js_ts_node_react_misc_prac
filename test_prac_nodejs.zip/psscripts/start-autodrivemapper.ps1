<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	start-autodrivemapper.ps1
	===========================================================================
	.DESCRIPTION
    Startup script - Loads and maps all user selected network drives (drives.json) - uses mapdrive.ps1

    Registered in Computer\HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
    cmd /c start /min "" powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass "& ""{path}\startup.ps1"""
#>

[CmdletBinding()]
param(
    $path = "$([Environment]::GetFolderPath([Environment+SpecialFolder]::ApplicationData))$([System.IO.Path]::DirectorySeparatorChar)ServiceTool$([System.IO.Path]::DirectorySeparatorChar)drives.json",
    $script = "mapdrive.ps1",
    $spoScript = "add-spodrive.ps1",
    $transcript = $false,
    $delay = $false, # delays execution random between 0 and 60 seconds
    $retryOnce = $true, # if true retry a connection request once more if the password was incorrect
    $showToast = $false
)


$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

function Write-DebugMessage(){
    [CmdletBinding()]
    param(
        [Parameter(ValueFromPipeline=$True)]
        $message
    )
    
    Write-Verbose $message
    $global:log += $message
}

$msgTable = Data {ConvertFrom-StringData -StringData @'
    userInfoTitle = Service Tool Notification
    userInfoMsg = Requested network resources were processed. It can take up to 2 minutes for Windows Explorer to reflect that change.
'@}

try{
    Import-LocalizedData -BindingVariable msgTable -ErrorAction SilentlyContinue
}
catch{}

function Show-Notification {
    [cmdletbinding()]
    Param (
        [string]
        $ToastTitle,
        [string]
        [parameter(ValueFromPipeline)]
        $ToastText
    )

    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
    $Template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)

    $RawXml = [xml] $Template.GetXml()
    ($RawXml.toast.visual.binding.text| Where-Object {$_.id -eq "1"}).AppendChild($RawXml.CreateTextNode($ToastTitle)) > $null
    ($RawXml.toast.visual.binding.text| Where-Object {$_.id -eq "2"}).AppendChild($RawXml.CreateTextNode($ToastText)) > $null

    $SerializedXml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $SerializedXml.LoadXml($RawXml.OuterXml)

    $Toast = [Windows.UI.Notifications.ToastNotification]::new($SerializedXml)
    $Toast.Tag = "PowerShell"
    $Toast.Group = "PowerShell"
    $Toast.ExpirationTime = [DateTimeOffset]::Now.AddMinutes(1)

    $Notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("PowerShell")
    $Notifier.Show($Toast);
}

if ($true -eq $transcript){
    Write-DebugMessage "Transcript file $($env:TEMP)\AutoDriveMapper$((Get-Date -UFormat "%Y-%m-%d_%I-%M-%S_%p").tostring()).log"
    Start-Transcript -Path "$($env:TEMP)\AutoDriveMapper$((Get-Date -UFormat "%Y-%m-%d_%I-%M-%S_%p").tostring()).log"
}

if ($true -eq $delay){
    # race condition in Explorer.exe?
    Start-Sleep -Seconds (Get-Random -Maximum 60)
}

$global:log = @()

if (!(Test-Path "$($PSScriptRoot)$([System.IO.Path]::DirectorySeparatorChar)$($script)")){
    Write-Error "Required file $($script) does not exist in current folder."
    exit
}

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

# fix ps7 behavior -v -verbose etc.
if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"]){
    $VerbosePreference="Continue"
}

Write-DebugMessage "Executing directory:$($PSScriptRoot)"
Write-DebugMessage "Input file path:$($path)"

if (!(Test-Path $path)) {
    Write-DebugMessage "Drives.json file does not exist at path $($path)."
    exit
}

# Parse file
$drives = (Get-Content $path -Encoding UTF8 | Out-String | ConvertFrom-Json)

foreach ($drive in $drives.PSObject.Properties) {
    Write-DebugMessage "Mapping drive $($drive.Value.DriveName)"
    try{

        # this is used for standard network resources
        if (($null -eq $drive.Value.ShareType) -or ($drive.Value.ShareType -eq "Legacy") -or ($drive.Value.ShareType -eq "Domain Services")) {
            $result = (& "$($PSScriptRoot)$([System.IO.Path]::DirectorySeparatorChar)$($script)" `
                    -driveLetter $drive.Value.DriveLetter -driveName $drive.Value.DriveName -sourcePath $drive.Value.Address) | Select-Object -Last 1 | ConvertFrom-Json
        
            if (!$result.Success) {
                Write-DebugMessage $result.Message
            
                # [System.Windows.Forms.MessageBox]::Show("$($result.Message)","Error",0) 
            
                if ($result.Message -like "*Password*" -or $result.Message -like "*Credentials*") {

                    if ($retryOnce) {
                        # the stored password should be removed at this point
                        Write-DebugMessage "Retry connection after password reset."

                        $result = (& "$($PSScriptRoot)$([System.IO.Path]::DirectorySeparatorChar)$($script)" `
                                -driveLetter $drive.Value.DriveLetter -driveName $drive.Value.DriveName -sourcePath $drive.Value.Address) | Select-Object -Last 1 | ConvertFrom-Json
                        
                        if (!$result.Success) {
                            # stop processing of this resource to prevent account lockout
                            Write-DebugMessage "Connection to $($drive.Value.DriveName) could not be restored."
                            continue;
                        }
                        else {
                            Write-DebugMessage "$($drive.Value.DriveName) mapping completed"
                            continue;
                        }
                    }
                    else {
                        continue;
                    }
                }

                Write-DebugMessage "Connection to $($drive.Value.DriveName) could not be restored."
            }
            else {
                Write-DebugMessage "$($drive.Value.DriveName) mapping completed"
            }
        }
        else{ #SharePoint   

            $result = (& "$($PSScriptRoot)$([System.IO.Path]::DirectorySeparatorChar)$($spoScript)" `
                    -metadata $drive.Value.Address -driveLetter $drive.Value.DriveLetter -mapAsDrive $true -driveName $drive.Value.DriveName) | Select-Object -Last 1 | ConvertFrom-Json
            
            if (!$result.Success) {
                Write-DebugMessage "Connection to $($drive.Value.DriveName) could not be restored."
            }
            else{
                Write-DebugMessage "SPO $($drive.Value.DriveName) mapping completed"
            }
        }
    }
    catch{
        Write-DebugMessage $_.Exception.Message
        continue # continue to next element - one unavailable resource does not necessarily mean that the others are not available
    }
}

Write-DebugMessage "Processing finished"

if ($true -eq $transcript){
    Write-Output $global:log
    Stop-Transcript
}

if ($true -eq $showToast){
    Show-Notification -ToastTitle $msgTable.userInfoTitle -ToastText ($msgTable.userInfoMsg -f "")
}

@{success = $true; message = $global:log } | ConvertTo-Json