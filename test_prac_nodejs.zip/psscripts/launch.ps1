<#	
	.NOTES
	===========================================================================
	 Created on:   	2020/07
	 Created by:   	Conguide GmbH
	 Filename:     	launch.ps1
	===========================================================================
	.DESCRIPTION
		Run Windows executable (default TeamViewer)
#>
param(
    $executable = "C:\Program Files (x86)\TeamViewer\TeamViewer.exe",
	$params = ""
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

try{
	
	# special handling for special file types
	if (($executable.IndexOf(".rdp") -ne -1) -or ($executable.indexOf(".lnk") -ne -1) -or ($executable.indexOf(".url") -ne -1)){
		Invoke-Item -Path $executable -ErrorAction Stop
		return @{success = $true } | ConvertTo-Json
	}
	else{
		if ($params){			
			Start-Process -FilePath $executable -ArgumentList $params -ErrorAction Stop
		}
		else{
			Start-Process -FilePath $executable -ErrorAction Stop
		}
	}
	
    return @{success = $true } | ConvertTo-Json
}
catch{
	return @{success = $false; message = $_.Exception.Message } | ConvertTo-Json
}