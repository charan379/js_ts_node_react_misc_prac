ConvertFrom-StringData -StringData @'
formtitle = Verbinden mit {0}
usernamelabel = Benutzername:
passwordlabel = Passwort:
okButton = OK
cancelButton = Abbrechen
errorMsgNoCredentialsTitle = Fehler
errorMsgNoCredentials = Drucker {0}: konnte nicht verbunden werden. Zugangsdaten sind unvollständig.
genericError = Verbindung fehlgeschlagen. Grund: {0}
successMessage = Service Tool Verbindung
successMessageDetails = Drucker {0}: wurde verbunden und kann nun verwendet werden.
'@