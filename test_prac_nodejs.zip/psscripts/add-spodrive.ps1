<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/08
	 Created by:   	Conguide GmbH
	 Filename:     	addspodrive.ps1
	===========================================================================
	.DESCRIPTION
    Connects SPO drive with OneDrive for Business. If parameter drive is given automatically 
    maps the library as a drive in Windows.

    Format: odopen://sync/?siteId={SITEID}&amp;webId={WEBID}&amp;
        listId={LISTID}&amp;userEmail={EMAILADDRESS}&amp;
            webUrl=URL&amp;webTitle={NAME FOR FOLDER IN EXPLORER}&amp;listTitle={LIBRARY NAME}

    Copy Link SPO Format
    #tenantId=xxx&siteId=xxx&webId=xxx&listId=xxx&webUrl=xxx&version=1
#>

param(
    [Parameter(mandatory=$true)]
    $metadata,    
    $mailaddress,
    $explorerWebTitle, # for Explorer
    $explorerListTitle, # for Explorer,
    $mapAsDrive = $false,
    $driveLetter,
    $driveName,
    $tenantName,
    $mapOnly = $false
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

Add-Type -AssemblyName System.Web

$nvCollection = [System.Web.HttpUtility]::ParseQueryString($metadata)

$values = [PSCustomObject]@{
    siteId= $nvCollection["siteId"]; 
    webId= $nvCollection["webId"];
    listId= $nvCollection["listId"];
    userEmail = @($nvCollection["mailaddress"],$mailaddress)[[byte](![String]::IsNullOrEmpty($mailaddress))];
    webUrl = $nvCollection["webUrl"];
    webTitle = @($nvCollection["webTitle"],$explorerWebTitle)[[byte](![String]::IsNullOrEmpty($explorerWebTitle))];
    listTitle = @($nvCollection["listTitle"],$explorerListTitle)[[byte](![String]::IsNullOrEmpty($explorerListTitle))];
}


if ([String]::IsNullOrEmpty($tenantName)){
    $tenantName = $nvCollection["tenantName"]
}

$driveLink = [System.Web.HttpUtility]::ParseQueryString([String]::Empty)

foreach ($key in ( $values.PSObject.Members| Where-Object { $_.MemberType -eq 'NoteProperty'}))
{
    if (![String]::IsNullOrEmpty($key.Value)){
        $driveLink.Add($key.Name, $key.Value)
    }
}

# Build the uri
$uriRequest = [System.UriBuilder]"odopen://sync/"
$uriRequest.Query = $driveLink.ToString().Replace("+","%20")

try{
    if (!$mapOnly){
        Start-Process $uriRequest.Uri.ToString()
    }

    # if no drive letter was provided skip this step
    if ([String]::IsNullOrEmpty($driveLetter) -or [String]::IsNullOrEmpty($driveName)){
        $mapAsDrive = $false;
        $mapOnly = $false;
    }
    elseif(![String]::IsNullOrEmpty($driveLetter)){
        $mapAsDrive = $true;
    }

    if ($mapAsDrive -or $mapOnly){
        if ($driveLetter -and $tenantName -and $values.webTitle -and $values.listTitle){
            
            Start-Sleep -s 5

            $pathForSubst = "$($home)\$($tenantName)\$($values.webTitle) - $($values.listTitle)"

            $output = (& "$($PSScriptRoot)$([System.IO.Path]::DirectorySeparatorChar)$("connect-folderasdrive.ps1")" `
                -driveLetter "$($driveLetter.ToLower())" -path "$($pathForSubst)" -driveName $driveName) | Select-Object -Last 1 | ConvertFrom-Json

            # $output = . .\connect-folderasdrive.ps1 -driveLetter "$($driveLetter.ToLower())" -path "$($pathForSubst)" -driveName $driveName
            # Write-Output $output

            if ($output.success -eq $true){
                return @{success = $true} | ConvertTo-Json;
            }
            else{
                return  @{success = $false; message=$output} | ConvertTo-Json;
            }
        }
    }

    return @{success = $true} | ConvertTo-Json
}
catch{
    return @{success = $false; message = $Error[0].Exception.Message } | ConvertTo-Json
}