<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/08
	 Created by:   	Conguide GmbH
	 Filename:     	mapper-registry-manager.ps1
	===========================================================================
	.DESCRIPTION
		Enable, remove and get status for the drive mapper startup script.
#>

param(
    [ValidateSet("Add", "Remove", "Status")]
    [Parameter(Mandatory = $true)]
    [String]
    $mode = "Status",
    $path = "$([Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFiles))$([System.IO.Path]::DirectorySeparatorChar)Service Tool$([System.IO.Path]::DirectorySeparatorChar)resources$([System.IO.Path]::DirectorySeparatorChar)psscripts$([System.IO.Path]::DirectorySeparatorChar)",
    $scriptToExecute = "start-autodrivemapper.ps1",
    $command = 'cmd /c start /min "" powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass "& ""' + $path + $scriptToExecute + '"""',
    $registryPath = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    $serviceToolValueName = "Service Tool Mapper"
)

$OutputEncoding = [System.Console]::OutputEncoding = [System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

function Test-RegistryValue {
    param (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]$Path,
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]$Name
    )
    
    try {    
        Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Name -ErrorAction Stop | Out-Null
        return $true
    }
    
    catch {
        return $false
    }
}

try {
    if ($mode -eq "Add") {
        if (Test-RegistryValue -Path $registryPath -Name $serviceToolValueName) {
            Set-ItemProperty -Path $registryPath -Name $serviceToolValueName -Value $command `
                -Force | Out-Null
        }
        else {
            New-ItemProperty -Path $registryPath -Name $serviceToolValueName -Value $command `
                -PropertyType STRING -Force | Out-Null
        }
        $value = Get-ItemPropertyValue -Path $registryPath -Name $serviceToolValueName
        return @{enabled = $true; value = $value } | ConvertTo-Json
    }
    elseif ($mode -eq "Remove") {
        $exists = Test-RegistryValue -Path $registryPath -Name $serviceToolValueName
    
        if ($exists) {
            Remove-ItemProperty -Path $registryPath -Name $serviceToolValueName        
        }
    
        return @{enabled = $false } | ConvertTo-Json
    }
    elseif ($mode -eq "Status") {
        $exists = Test-RegistryValue -Path $registryPath -Name $serviceToolValueName
        if ($exists) {
            $value = Get-ItemPropertyValue -Path $registryPath -Name $serviceToolValueName
            return @{enabled = $true; value = $value } | ConvertTo-Json
        }
        else {
            return @{enabled = $false } | ConvertTo-Json
        }
    }
}
catch {
    return @{enabled = $false }; 
}