<#	
	.NOTES
	===========================================================================
	 Created on:   	2021/07
	 Created by:   	Conguide GmbH
	 Filename:     	mapdrive.ps1
	===========================================================================
	.DESCRIPTION
		Script will connect network drives during Windows startup (includes integration with Windows Credential Manager)

        Replacement of script "smbdrivemapper.ps1".

    .History
        7/2023 - Rev. 2 Updated to use CredMan Pwd instead of cmdkey
#>

param(
    [Parameter(Mandatory = $True)]
    $sourcePath = "",
    $driveName = "",
    $driveLetter = "",
    $showToast = $false,
    $removeOnly = $false,
    $legacyMode = $false,
    $authRequired = $true
)

# fix ps7 behavior -v -verbose etc.
if ($PSCmdlet.MyInvocation.BoundParameters["Verbose"]){
    $VerbosePreference="Continue"
}

Write-Verbose "Executing directory:$($PSScriptRoot)"
Write-Verbose "Input file path:$($path)"

# default language en-US / other languages are loaded from {lang/.psd1}
$msgTable = Data {ConvertFrom-StringData -StringData @'
    formtitle = Connect to {0} ({1}:)
    usernamelabel = Username:
    passwordlabel = Password:
    okButton = OK
    cancelButton = Cancel
    errorMsgNoCredentialsTitle = Error
    errorMsgNoCredentials = {0}: won't be available because you have not entered required credentials.
    genericError = Connection failed. Reason: {0}
    successMessage = Service Tool Connection
    successMessageDetails = Drive {0}: is now available.
'@}

try{
    Import-LocalizedData -BindingVariable msgTable -ErrorAction SilentlyContinue
}
catch{}

$serverPath = "$(([URI]$sourcePath).Host)"

#region SmbDriveMapper 

# dynamic drive letter
if ([String]::IsNullOrEmpty($driveLetter)) {
    $driveLetter = (ls function:[d-z]: -n | Where-Object { !(test-path $_) } | select-object -Last 1).ToUpper()
    $driveLetter = $driveLetter.SubString(0, 1)
}

if ($removeOnly -eq $true) {
    try {
        # hardening - still not 100% functional in Windows 10
        Get-PSDrive | ForEach-Object {
            if ($_.DisplayRoot -eq "$($sourcePath)"){
                Remove-PSDrive -Name $_.Name -Scope Global
            }
        }
        
        try{
            # net use "$($sourcePath)" /delete 2>&1 | Out-Null
            Get-SmbMapping | ForEach-Object {
                if ($_.RemotePath -eq "$($sourcePath)"){
                    # Remove-SmbMapping -LocalPath $_.LocalPath -Force
                    net use @($_.LocalPath) /delete 2>&1 | out-Null
                }
            }
        }
        catch{
        }
       
        return @{success = $true; message = "Removed drived"} | ConvertTo-Json
    }
    catch {
        return @{success = $false; message = $_.Exception.Message } | ConvertTo-Json
    }
}

#endregion

if ([String]::IsNullOrEmpty($driveLetter)) {
    # should never happen
    return @{success = $false; message = "A free drive letter could not be found" } | ConvertTo-Json
}

$driveLetter = $driveLetter.ToUpper()

#region PwdManager

[String] $credentialManager = @"
    using System;
    using System.Runtime.InteropServices;
    using System.Collections;

    public class CredMan
    {
        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredReadW", CharSet = CharSet.Unicode)]
        private static extern bool CredReadW([In] string target, [In] uint type, [In] int flag, out IntPtr credential);
        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredFree")]
        private static extern void CredFree([In] IntPtr cred);

        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredWriteW", CharSet = CharSet.Unicode)]
        private static extern bool CredWrite([In] ref CredentialMem userCredential, [In] int flags);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct Credential
        {
            public uint Flags;
            public uint Type;
            public IntPtr TargetName;
            public IntPtr Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public UInt32 CredentialBlobSize;
            public IntPtr CredentialBlob;
            public UInt32 Persist;
            public UInt32 AttributeCount;
            public IntPtr Attributes;
            public IntPtr TargetAlias;
            public IntPtr UserName;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct CredentialMem
        {
            public int flags;
            public int type;
            public string targetName;
            public string comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME lastWritten;
            public int credentialBlobSize;
            public IntPtr credentialBlob;
            public int persist;
            public int attributeCount;
            public IntPtr credAttribute;
            public string targetAlias;
            public string userName;
        }
        
        public class CredReturn
        {
            public string UserName;
            public string Password;
            public DateTime LastModified;
            public string Target;
        }

        public static void SetUserCredential(string target, string userName, string password)
        {
            CredentialMem userCredential = new CredentialMem();

            userCredential.targetName = target;
            userCredential.type = 1;
            userCredential.userName = userName;
            userCredential.attributeCount = 0;
            userCredential.persist = 3;
            byte[] bpassword = System.Text.Encoding.Unicode.GetBytes(password);
            userCredential.credentialBlobSize = (int)bpassword.Length;
            userCredential.credentialBlob = Marshal.StringToCoTaskMemUni(password);
            if (!CredWrite(ref userCredential, 0))
            {
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            }
        }

        public static CredReturn GetCreds(string target)
        {
            IntPtr p;
            string password = null;
            string username = null;
            CredReturn cred = null;

            if (CredReadW(target, /*GENERIC type*/ 1, 0, out p))
            {
                Credential c = (Credential)Marshal.PtrToStructure(p, typeof(Credential));
                password = Marshal.PtrToStringUni(c.CredentialBlob, (int)(c.CredentialBlobSize / 2));
                username = Marshal.PtrToStringUni(c.UserName);
                CredFree(p);

                if (!String.IsNullOrEmpty(username))
                {
                    cred = new CredReturn();
                    cred.UserName = username;
                    cred.Password = password;
                    cred.Target = target;
                    cred.LastModified = WindowsTimeToDateTime(c.LastWritten);
                }
            }

            return cred;
        }

        public static DateTime WindowsTimeToDateTime(System.Runtime.InteropServices.ComTypes.FILETIME time)
        {
            ulong high = (ulong)time.dwHighDateTime;
            uint low = (uint)time.dwLowDateTime;
            long fileTime = (long)((high << 32) + low);
            try
            {
                return DateTime.FromFileTimeUtc(fileTime);
            }
            catch
            {
                return DateTime.FromFileTimeUtc(0xFFFFFFFF);
            }
        }
    }
"@

#endregion

try {
    Add-Type $credentialManager -ErrorAction Continue
}
catch {}
 
$result = [CredMan]::GetCreds($serverPath)

function Show-Notification {
    [cmdletbinding()]
    Param (
        [string]
        $ToastTitle,
        [string]
        [parameter(ValueFromPipeline)]
        $ToastText
    )

    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
    $Template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)

    $RawXml = [xml] $Template.GetXml()
    ($RawXml.toast.visual.binding.text| Where-Object {$_.id -eq "1"}).AppendChild($RawXml.CreateTextNode($ToastTitle)) > $null
    ($RawXml.toast.visual.binding.text| Where-Object {$_.id -eq "2"}).AppendChild($RawXml.CreateTextNode($ToastText)) > $null

    $SerializedXml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $SerializedXml.LoadXml($RawXml.OuterXml)

    $Toast = [Windows.UI.Notifications.ToastNotification]::new($SerializedXml)
    $Toast.Tag = "PowerShell"
    $Toast.Group = "PowerShell"
    $Toast.ExpirationTime = [DateTimeOffset]::Now.AddMinutes(1)

    $Notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("PowerShell")
    $Notifier.Show($Toast);
}

function ShowStorePasswordDialog() {
    param(
        $serverPath = $serverPath,
        $driveLetter = $driveLetter,
        $MyInvocation = $MyInvocation
    )

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

    try {
        $form = New-Object System.Windows.Forms.Form
        $form.Text = $msgTable.formtitle -f $serverPath,$driveLetter # "Connect to $serverPath ($($driveLetter):)"
        $form.Size = New-Object System.Drawing.Size(320, 200)
        $form.StartPosition = 'CenterScreen'
        $form.MinimizeBox = $False
        $form.MaximizeBox = $False
        $form.FormBorderStyle = 'FixedDialog'
    
        try {
            $scriptPath = Split-Path $MyInvocation.MyCommand.Path -Parent
            $iconBase64 = [Convert]::ToBase64String((Get-Content "$($scriptPath)\icon.ico" -Encoding Byte -ErrorAction Stop))
            $iconBytes = [Convert]::FromBase64String($iconBase64)
            $stream = New-Object IO.MemoryStream($iconBytes, 0, $iconBytes.Length)
            $stream.Write($iconBytes, 0, $iconBytes.Length);
            $form.Icon = [System.Drawing.Icon]::FromHandle((New-Object System.Drawing.Bitmap -Argument $stream).GetHIcon())
        }
        catch {
    
        }
    
        $OKButton = New-Object System.Windows.Forms.Button
        $OKButton.Location = New-Object System.Drawing.Point(70, 120)
        $OKButton.Size = New-Object System.Drawing.Size(75, 23)
        $OKButton.Text = $msgTable.okButton
        $OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $form.AcceptButton = $OKButton
        $form.Controls.Add($OKButton)
    
        $CancelButton = New-Object System.Windows.Forms.Button
        $CancelButton.Location = New-Object System.Drawing.Point(150, 120)
        $CancelButton.Size = New-Object System.Drawing.Size(75, 23)
        $CancelButton.Text = $msgTable.cancelButton
        $CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $form.CancelButton = $CancelButton
        $form.Controls.Add($CancelButton)
    
        $label = New-Object System.Windows.Forms.Label
        $label.Location = New-Object System.Drawing.Point(10, 20)
        $label.Size = New-Object System.Drawing.Size(280, 20)
        $label.Text = $msgTable.usernamelabel
        $form.Controls.Add($label)
    
        $textBox = New-Object System.Windows.Forms.TextBox
        $textBox.Location = New-Object System.Drawing.Point(10, 40)
        $textBox.Size = New-Object System.Drawing.Size(260, 20)
        $textBox.Text = $userId
        $form.Controls.Add($textBox)
    
        $label2 = New-Object System.Windows.Forms.Label
        $label2.Location = New-Object System.Drawing.Point(10, 70)
        $label2.Size = New-Object System.Drawing.Size(280, 20)
        $label2.Text = $msgTable.passwordlabel
        $form.Controls.Add($label2)
    
        $textBox2 = New-Object System.Windows.Forms.MaskedTextBox
        $textBox2.PasswordChar = '*'
        $textBox2.Location = New-Object System.Drawing.Point(10, 90)
        $textBox2.Size = New-Object System.Drawing.Size(260, 20)
        $form.Controls.Add($textBox2)
    
        $form.Topmost = $true
    
        $form.Add_Shown( { $textBox.Select() })
        $result = $form.ShowDialog()
    
        if ($result -eq [System.Windows.Forms.DialogResult]::OK -and ![String]::IsNullOrEmpty($textBox2.Text) -and ![String]::IsNullOrEmpty($textBox.Text)) {
            
            $user = $textBox.Text
            $pass = $textBox2.Text
           
            [CredMan]::SetUserCredential($serverPath,$user,$pass)
            
            return @{success = $true} | ConvertTo-Json
        }
        else {
            # $OUTPUT = [System.Windows.Forms.MessageBox]::Show( ($msgTable.errorMsgNoCredentials -f $driveLetter), $msgTable.errorMsgNoCredentialsTitle , 0) 
            return @{success = $false; message = ($msgTable.errorMsgNoCredentials -f $driveLetter) } | ConvertTo-Json
        }
    
    }
    catch {
        Write-Verbose $_.Exception.Message
        return @{success = $false; message = ($msgTable.genericError -f $Error[0]) } | ConvertTo-Json
    }
}

try{
    if (!$result -and $authRequired -eq $true) {
        Write-Verbose "Credentials for resource could not be found."
        
        $res = ShowStorePasswordDialog -serverPath $serverPath -driveLetter $driveLetter -MyInvocation $MyInvocation

        if (!($res| ConvertFrom-JSON).success){
            return @{success = $false; message= "Required credential info was not provided." } | ConvertTo-Json
        }

        # Load from store again
        $result = [CredMan]::GetCreds($serverPath)
    }

    if (!$result){
        return @{success = $false; message= "Required credential info was not provided." } | ConvertTo-Json
    }

}
catch{
    return @{success = $false; message= $Error[0].Exception} | ConvertTo-Json 
}

try {
    try {

        # legacy smbdrivemapper mode
        if ($legacyMode){
            try{
                New-PSDrive -Name "$driveLetter" -PSProvider FileSystem -Root $sourcePath -Persist -Scope Global -ErrorAction Stop 
                
                if (![String]::IsNullOrEmpty($driveName)){
                    $shell = New-Object -ComObject Shell.Application
                    $shell.NameSpace("$($driveLetter):").Self.Name = $driveName
                }
                
                return @{success = $true } | ConvertTo-Json
            }
            catch{
                return @{success = $false; message =($msgTable.genericError -f $Error[0])} | ConvertTo-Json
            }
        }

        $password = ConvertTo-SecureString $result.Password -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential ($result.UserName, $password)
    
        try {
            # Get-PSDrive $driveLetter.ToUpper() -ErrorAction Stop | Remove-PSDrive 
            # net use @($driveLetter + ":") /delete 2>&1 | out-Null

            Get-SmbMapping | ForEach-Object {
                if ($_.RemotePath -eq "$($sourcePath)"){
                    # Remove-SmbMapping -LocalPath $_.LocalPath -Force
                    net use @($_.LocalPath) /delete 2>&1 | out-Null
                }
            }

            Start-Sleep -Seconds 1 # windows sometimes needs a bit longer
        }
        catch {}

        try {
            Get-PSDrive $driveLetter.ToUpper() -ErrorAction SilentlyContinue | Remove-PSDrive | Out-null
            Start-Sleep -Seconds 1 # windows sometimes needs a bit longer
        }
        catch {}

        $res = New-PSDrive -Name "$driveLetter" -PSProvider FileSystem -Root "$($sourcePath)" -Credential $credentials -Persist -Scope Global -ErrorAction Stop 
        
        if ($showToast){
            Show-Notification -ToastTitle $msgTable.successMessage -ToastText ($msgTable.successMessageDetails -f $driveLetter)
        }
        
        
        # rename drive
        if (![string]::IsNullOrEmpty($driveName)) {
            $shell = New-Object -ComObject Shell.Application
            $shell.NameSpace("$($driveLetter):").Self.Name = $driveName
        }

        return @{success = $true } | ConvertTo-Json
    }
    catch {

        if ($_.Exception.Message -like "*does not exist*") {
            return @{success = $false; message= ($msgTable.genericError -f $Error[0]) } | ConvertTo-Json
        }
    
        if ($_.Exception.Message -like "*The network resource type is not*") {
            return @{success = $false; message= ($msgTable.genericError -f $Error[0]) } | ConvertTo-Json
        }

        if ($_.Exception.Message -like "*password*") {

            # remove stored credentials for this connection
            cmdkey.exe /delete:"$serverPath"
            Write-Verbose "Removed invalid credentials"

            return @{success = $false; message= "Password is not correct" } | ConvertTo-Json
        }
        if ($_.Exception.Message -like "*already exists*") {
            return @{success = $false; message= "Drive already exists" } | ConvertTo-Json
        }

        return @{success = $false; message= $_.Exception.Message + $driveLetter} | ConvertTo-Json
    }
}
catch {
    return @{success = $false; message = $_.Exception.Message +" - "+ $driveLetter} | ConvertTo-Json
}