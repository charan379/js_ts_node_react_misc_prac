/*
	- Registers a userConfig Object in global namespace
		global.userConfig.get("xyz");
	- Registers basedir for resource file handling
*/

global.__basedir = __dirname;

const {app, globalShortcut, ipcMain, screen} = require('electron');
const process = require('process');
const parseArgs = require('minimist');
const Store = require('./services/settings');
const MappedDriveInfo = require('./services/mappeddriveinfo');
const AutoRun = new (require('./services/autorun'))();
const path = require('path');
const { createAuthWindow } = require('./main/auth-process');

//default allow high dpi
app.commandLine.appendSwitch('high-dpi-support', 1);

app.disableHardwareAcceleration();

//check if there is a scale factor parameter present
let overrideScaleFactor = parseArgs(process.argv.slice(1), { boolean: 'minimized', float: "force-device-scale-factor"});

if (process.argv && process.argv.join().indexOf("force-device-scale-factor") > -1) {
	app.commandLine.appendSwitch('force-device-scale-factor', overrideScaleFactor['force-device-scale-factor']);
}

// default back to 1
if (!app.commandLine.getSwitchValue("force-device-scale-factor")){
	app.commandLine.appendSwitch('force-device-scale-factor', 1);
}

console.log("device-scale-factor", app.commandLine.getSwitchValue("force-device-scale-factor"))

const createAppWindow = require('./main/app-process');
const createInfoScreen = require('./main/infoscreen-window');

const authService = require('./services/authentication');
const moment = require('moment');
const Tray = require('./main/applicationtray');
const TrayMenu = require('./main/menu');
const axios = require('axios');
const osLocale = require('os-locale');

const isDevelopment = process.env.NODE_ENV === 'development';

const isPortable = process.env.PORTABLE_EXECUTABLE_APP_FILENAME ? true : false;

console.log ("PortableVersion", isPortable);

const rootPath = isDevelopment ? path.normalize(`${__dirname}`) : path.normalize(process.resourcesPath);
const envConfig = require(path.join(rootPath, './env-variables'));

const ActivityManager = require('./services/activity');
const Notification = require('./services/notification');

const ShortcutHandler = require('./services/shortcutHandler');

const dc = require('./services/datacontext');
const POWERSHELL = require('./services/powershell');

// change 05/2021
const gotTheLock = app.requestSingleInstanceLock()

if (!gotTheLock) {
	console.log("Another instance of the Service Tool already running. Quitting.");
	app.quit();
	return;
}

// fix working directory when autorun
process.chdir(path.resolve(rootPath));

if (!isDevelopment) {
	// needs more testing
	process.chdir("../");
}

// fix working directory when autorun
process.chdir(path.resolve(rootPath));

if (!isDevelopment) {
	// needs more testing
	process.chdir("../");
}

const store = new Store({
	// init user preferences
	configName: 'user-preferences',
	
	defaults: {
		windowBounds: { width: 600, height: 1000 }
	}
});

//Hotfix HighDPI Support (non dialog version)
if (store.exists()){
	let scaleFactor = store.get("scaleFactor");

	if (scaleFactor){
		//console.log("WE HAVE A VALUE", scaleFactor)
		app.commandLine.appendSwitch('force-device-scale-factor', parseFloat(scaleFactor));
	}
}



const mappedDriveInfo = new MappedDriveInfo({
	configName: 'drives'
});

let startMinimized = false;

function checkOnlineStatus() {
	return new Promise((resolve, reject) => {
		axios.get(envConfig.authorityurl).then(() => {
			resolve();
		}).catch(e => {

			reject();
		});
	});
}

app.on('ready', () => {
	handleArgsAndConfig();

	//during testing
	// 	const ret = globalShortcut.register('CommandOrControl+X', () => {
	// 	console.log('CommandOrControl+X is pressed')
	// 	authService.destroyAccessToken();
	// });

	checkOnlineStatus().then(() => {
		showWindow(startMinimized);
	}).catch(() => {
		let notification = new Notification();
		notification.notify("Offline", "You are offline. Please check network connectivity. App is quitting.");
		app.quit();
	});
});

// catch and stop application if anything unexpected is happening
process.on('unhandledRejection', (reason, p) => {
	console.error(reason, 'Unhandled Rejection at Promise', p);
}).on('uncaughtException', err => {
	console.error(err, 'Uncaught Exception thrown');
	process.exit(1);
});

app.on('window-all-closed', () => {
	app.quit(); // Quit when all windows are closed.
});

function handleArgsAndConfig() {
	// if file does not exist set defaults
	if (!store.exists()) {
		store.set("minimized", true);
		store.set("autostart", false);
		store.set("fileshareautomapping", true); //new default Q1 2022
	}

	// hack: if args are provided don't use user config
	let minimizedOverride = false;

	if (process.argv && process.argv.join().indexOf("minimized") > -1) {
		minimizedOverride = true;
	}

	if (process.argv && process.argv.join().indexOf("reset") > -1) {
		store.reset().then(()=>{
			console.log("Configuration reset. Application will exit now.");
			app.exit(0);
		});
	}

	global.userConfig = store;
	global.mappedDriveInfo = mappedDriveInfo;

	let minimized = false;
	let debug = false;

	let parsed = parseArgs(process.argv.slice(1), { boolean: 'minimized' });

	// load in override for base config
	// if (process.argv && process.argv.join().indexOf("envConfig") > -1) {
	// 	envConfig = require(parsed.envConfig);
	// }

	if (parsed && parsed.minimized) {
		minimized = parsed.minimized;
	}

	if (parsed && parsed.debug) {
		debug = parsed.debug;
		global.userConfig.set("isDebug", debug);
	}

	if (!minimizedOverride)
		minimized = global.userConfig.hasKey("minimized") ? Boolean(global.userConfig.get("minimized")) : true;

	startMinimized = minimized;

	let startWhenOSStarts = global.userConfig.get('autostart') ? Boolean(global.userConfig.get('autostart')) : false;

	if (startWhenOSStarts && !isDevelopment) {
		try { AutoRun.enable(); } catch { }
	}
	else {
		try { AutoRun.disable(); } catch { }
	}

	if (!global.userConfig.get("remotesupportapp")){
		global.userConfig.set("remotesupportapp", "C:\\Users\\Public\\Desktop\\TKE QuickSupport.exe");
	}

	// if the one is selected make sure we enable it
	if (global.userConfig.get("fileshareautomapping") && global.userConfig.get("fileshareautomapping") === true) {
		//change 2021/08 - if this option is selected make sure that the startup script is registered
		POWERSHELL.getStartupScriptStatus().then(s => {
			if (!s.enabled) {
				POWERSHELL.setStartupScript(true).then(s => {
					console.log(s);
				}).catch(e => {
					//for now we ignore this
				});
			}
		}).catch(e => {
			//for now we ignore this
		});

	}
	else {
		POWERSHELL.getStartupScriptStatus().then(s => {
			//disable it if it is enabled
			if (s.enabled) {
				POWERSHELL.setStartupScript(false).then(s => {
					console.log(s);
				}).catch(e => {
					//for now we ignore this
				});
			}
		}).catch(e => {
			//for now we ignore this
		});
	}

	// change 03/2020 - auto detect system language on first startup
	try {
		(async () => {
			let osLang = await osLocale();

			if (osLang && !global.userConfig.get('language')) {
				osLang = osLang.split("-")[0];
				global.userConfig.set('language', osLang)
				moment.locale(osLang);
			}
			else {
				moment.locale(global.userConfig.get('language') ? global.userConfig.get('language') : envConfig.defaultlng);
			}

			console.log("System language: " + osLang)
		})();
	}
	catch {
		//this should not fail - when this happens restart app anyway
	}

	// //global config for backend
	// moment.locale(global.userConfig.get('language') ? global.userConfig.get('language') : envConfig.defaultlng);
}

async function showWindow(minimized) {

	try {
		await authService.refreshTokens();
		return createAppWindow(mainAppStarted, minimized);
	} catch (err) {
		createAuthWindow(mainAppStarted); //if we are not authenticate create sign in window
	}
}

function mainAppStarted(window) {
	// callback - we don't want to show the tray until we have signed in
	mainAppWindow = window;

	// we don't use polling if user does not want any notifications - needs testing
	if (global.userConfig.get("sendnotifications")) {

		let dontShowIfHidden = global.userConfig.get("hide_modules");

		
		if (dontShowIfHidden && dontShowIfHidden.indexOf("news") != -1){
			// we don't send notifications then
		}
		else{
			let activityManager = new ActivityManager(window);
			activityManager.handleAnnouncements(envConfig.activitychecktimeout);
		}
	}

	//hack pwd update - removed for intermediate version
	let beta = false;
	beta = global.userConfig.get("beta"); // not used 
	
	// set password age from config otherwise specify in config (or orgconfig)
	const maxPasswordAge = global.userConfig.get("maxPasswordAge") ? global.userConfig.get("maxPasswordAge") : 90;

	if (!global.userConfig.get("hideNotificationOnStartup")) {
		dc.getUserLastPwdChange().then((result) => {

			// pwd reminder 
			if (beta){

				let storedReminderDate = global.userConfig.get("pwdexpiryreminderdate");
				let expiresOn = new Date(result).addDays(maxPasswordAge);
				let sameDate = false;

				if (storedReminderDate){
					storedReminderDate = new Date (storedReminderDate);

					if (moment(storedReminderDate).diff(expiresOn, 'days') == 0){
						sameDate = true;
					}
				}

				if (!sameDate){
					console.log("pwd will expire in " + Math.abs(moment().diff(expiresOn, 'days')))
					if (Math.abs(moment().diff(expiresOn, 'days')) <= 10){
						createInfoScreen(pwdExpiryReminderScreenShowing, false, "pwdexpiry", {"date": expiresOn, "date_title": moment(expiresOn).format("l")});
					}
				}
				else{
					console.log("User acknowledged the pwd expiry info.");
				}
			}

			lastReminder = global.userConfig.get("pwdreminderdate");

			if (global.userConfig.get("pwdreminderdate")){
				// console.log("Last pwd changed", result);

				if (new Date(lastReminder) < new Date(result)) {
					if (mappedDriveInfo.count() > 0) {

						let hasMatchingType = false;

						mappedDriveInfo.getAll().forEach(driveInfo =>{
							if(driveInfo.ShareType === "Domain Services"){
								hasMatchingType = true;
							}
						});

						// we don't need to show a reminder if we don't find a Domain Services type share
						if(hasMatchingType){
							createInfoScreen(infoScreenShowing, false, "pwdchange", {"date": result});
						}
					}
				}
			}
			else
			{
				// just assume this is the first time the application is starting up set today as last reminder date
				global.userConfig.set("pwdreminderdate", new Date());
			}
		});
	}

	const devToolsStartup = globalShortcut.register('CommandOrControl+Shift+D', () => {
		window.openDevTools();
	});

	// Change 2021/08
	handleOrgSettings();

	//fix race condition to async oslang
	setTimeout(()=>{
		// init tray menu
		let trayMenu = new TrayMenu(window);
		new Tray(window, trayMenu.submenu, path.normalize(`${__dirname}`) + '/main/appicon/png/32x32.png');
	}, 1000)

	// some global events

	ipcMain.on('navigate', (event, arg) => {
		window.webContents.send('route', arg);
		window.show();
		window.focus();
	});

	ipcMain.on('pwdexpiryreminderdate', (event, arg)=>{
		global.userConfig.set("pwdexpiryreminderdate", arg);
	});

	ipcMain.on('pwdreminderdate', (event, arg)=>{
		global.userConfig.set("pwdreminderdate", arg);
	});

	// handle native drag & drop
	const iconName = path.normalize(`${__dirname}`) + '/main/appicon/png/32x32.png';

	ipcMain.on('ondragstart', (event, fileData) => {
		ShortcutHandler.writeShortcut(fileData.fileInfo).then((file) => {

			event.reply("fileCreated");

			event.sender.startDrag({
				file: file,
				icon: iconName
			});
		});
	});

	ipcMain.on('handleSpecialLink', (event, fileData) => {
		ShortcutHandler.writeShortcut(fileData.fileInfo).then(file=>{
			POWERSHELL.launchAppPS(file).then((res)=>{
				event.reply ("specialLinkHandled", res);
			});
		}).catch(e=>{
			console.log(e);
		});
	});
}

function handleOrgSettings(){
	// get orgConfig from SPO
	return dc.getOrgSettings().then(settings => {
		if (settings.data.value) {
			//we can receive more than one element at this point

			let publishedConfigs = [];

			settings.data.value.forEach(row=>{
				if (row.fields._ModerationStatus === 0){
					row.fields.lastModifiedDateTimeFormatted = moment(new Date(row.lastModifiedDateTime)).fromNow();
					row.fields.lastModifiedDateTime = row.lastModifiedDateTime;
					publishedConfigs.push(row.fields);
				}
			})
			
			console.log("Remote configs", publishedConfigs ? publishedConfigs.length : 0)

			if (publishedConfigs.length == 0){
				//if there is no config there is nothing to do here
				return;
			}

			let hasUpdate = false;

			publishedConfigs.forEach((config)=>{
				let itemDate = new Date(config.lastModifiedDateTime).getTime();

				if (global.userConfig.get("lastremoteupdate")) {
					let lastUpdated = new Date(global.userConfig.get("lastremoteupdate")).getTime();
	
					if (itemDate > lastUpdated) {
						hasUpdate = true;
					}
				}
				else {
					hasUpdate = true;
				}
			});

			if (hasUpdate) { // skip if not approved
				createInfoScreen(configurationUpdateShowing, false, "configurationupdate", {"remoteConfigurations": publishedConfigs});
			}

			ipcMain.on('apply-org-data', (event, settings) => {
				if (settings){
					let changes = mergeConfigSettings(JSON.parse(settings.Settings), true);
					
					//last time config was updated from remote source
					global.userConfig.set("lastremoteupdate", new Date().toISOString()); //settings.lastModifiedDateTime);

					if (changes) {
						app.relaunch();
						app.exit(0);
					}
				}
			});
		}
	}).catch((e)=>{
		console.log(e); //if the list does not exist or we run into any other issue with remote config...skip
	});
}

function mergeConfigSettings(orgSettings, update){
	let hasChanges = false;

	for (var key in orgSettings) {
		//only change values if they differ
		if (JSON.stringify(global.userConfig.get(key)) !== JSON.stringify(orgSettings[key])) {
			if (update)
				global.userConfig.set(key, orgSettings[key]);
			
				hasChanges = true;
		}
	}

	return hasChanges;
}

/* #region signaling */

function infoScreenShowing(window, result) {
	if (window){
		console.log("Password reminder window created")
	}
	else{
		console.log("Password reminder window closed")
	}
}

function pwdExpiryReminderScreenShowing(window, result) {
	if (window){
		console.log("Password expiry reminder window created")
	}
	else{
		console.log("Password expiry reminder window closed")
	}
}

function configurationUpdateShowing(window, result) {
	if (window){
		console.log("Update window created")
	}
	else{
		console.log("Update window closed")
	}
}

//helpers
Date.prototype.addDays = function(days) {
	var date = new Date(this.valueOf());
	date.setDate(date.getDate() + days);
	return date;
}


/* #endregion */