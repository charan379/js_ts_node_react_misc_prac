const defaultMessage = 'Are you sure want to proceed?';

export class ConfirmDialog {

  static inject() {
    return [au.dialog.DialogController]
  }

  constructor(controller) {
    this.controller = controller;
    this.title = 'Confirmation';
  }

  // this is a lifecycle of dialog
  // which will be awaited
  // if there is remote data fetching, it's a perfect opportunity
  // to prepare data here for data binding later
  activate(modelOrMessage) {
    if (typeof modelOrMessage === 'string') {
      this.message = modelOrMessage;
    } else if (typeof modelOrMessage === 'object') {
      this.message = modelOrMessage && modelOrMessage.message;
      this.title = modelOrMessage && modelOrMessage.title;
    } else {
      this.message = defaultMessage;
    }
  }

  yes() {
    this.controller.ok({ yes: true, no: false, cancelled: false });
  }

  no() {
    this.controller.ok({ yes: false, no: true, cancelled: false });
  }

  cancel() {
    this.controller.ok({ yes: false, no: false, cancelled: true });
  }
}

// to give Aurelia a hint what the module that is associated with
// class ConfirmDialog is
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(ConfirmDialog, { moduleId: 'dialogs/confirm.js' });
