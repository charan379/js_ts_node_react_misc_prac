const defaultMessage = 'Are you sure want to proceed?';

export class PromptDialog {

  static inject() {
    return [au.dialog.DialogController]
  }

  constructor(controller) {
    this.controller = controller;
    this.title = 'Prompt';
    this.fields = [];
  }

  // this is a lifecycle of dialog
  // which will be awaited
  // if there is remote data fetching, it's a perfect opportunity
  // to prepare data here for data binding later
  activate(modelOrMessage) {
    if (typeof modelOrMessage === 'string') {
      this.message = modelOrMessage;
    } else if (typeof modelOrMessage === 'object') {
      this.message = modelOrMessage && modelOrMessage.message;
      this.title = modelOrMessage && modelOrMessage.title;
    } else {
      this.message = defaultMessage;
    }

    this.fields = modelOrMessage.fields;
  }

  get formIsValid(){
    let isValid = true;
    this.fields.forEach(f=>{
      if (!f.value)
        isValid = false;
    })

    return isValid
  }

  yes() {
    this.controller.ok({ yes: true, no: false, cancelled: false, fields: this.fields });
  }

  no() {
    this.controller.ok({ yes: false, no: true, cancelled: false });
  }

  cancel() {
    this.controller.ok({ yes: false, no: false, cancelled: true });
  }
}

// to give Aurelia a hint what the module that is associated with
// class ConfirmDialog is
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(PromptDialog, { moduleId: 'dialogs/prompt.js' });
