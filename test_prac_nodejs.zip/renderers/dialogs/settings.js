const { remote } = require('electron');
const POWERSHELL = remote.require('./services/powershell');
const i18n = remote.require('./services/translation');
const defaultMessage = i18n.t("settings.defaultsavemsg"); //'Are you sure want to proceed?';
const userConfig = remote.getGlobal("userConfig");
const path = remote.require('path');
const dc = remote.require('./services/datacontext');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const isPortable = process.env.PORTABLE_EXECUTABLE_APP_FILENAME ? true : false;

const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(remote.process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));
const AutoRun = new (remote.require('./services/autorun'))();
const mappedDriveInfo = remote.getGlobal("mappedDriveInfo");
var appVersion = require('electron').remote.app.getVersion();
import { ConfirmDialog } from '../dialogs/confirm.js';

export class SettingsDialog {

  static inject() {
    return [au.dialog.DialogController, au.dialog.DialogService]
  }

  constructor(controller, dialog) {
    this.iconclass = "oi-cog";
    this.dialog = dialog;

    this.selectedLanguage = userConfig.get("language") ? userConfig.get("language") : appConfig.defaultlng;
    this.currentLanguage = this.selectedLanguage;
    this.languages = appConfig.languages;
    this.controller = controller;
    this.isPortable = isPortable;

    this.alwaysontop = Boolean(userConfig.get("alwaysontop") ? userConfig.get("alwaysontop") : false);

    this.notifyUser = Boolean(userConfig.get("sendnotifications") ? userConfig.get("sendnotifications") : false);
    this.startWhenOSStarts = Boolean(userConfig.get("autostart") ? userConfig.get("autostart") : false);
    this.init_startWhenOSStarts = this.startWhenOSStarts;
    this.startMinimized = userConfig.get("minimized") ? Boolean(userConfig.get("minimized")) : false;
    this.width = "500px";
    this.title = i18n.t("settings.title");

    this.fileshareautomapping = Boolean(userConfig.get("fileshareautomapping") ? userConfig.get("fileshareautomapping") : false);
    this.hideNotificationOnStartup = Boolean(userConfig.get("hideNotificationOnStartup") ? userConfig.get("hideNotificationOnStartup") : false);
    this.enableDriveResetButton = false;
    this.version = "v" + appVersion;
    this.mapAllDrivesEnabled = true;

    this.disableNewsAlerts = false;
    let dontShowIfHidden = userConfig.get("hide_modules");
    if (dontShowIfHidden && dontShowIfHidden.indexOf("news") != -1){
      this.disableNewsAlerts = true;
    }
  }

  mapAllDrives(){
    let confirmMessage = i18n.t("settings.advanced-settings-mapdrives-confirm");
    let title = i18n.t("settings.advanced-settings-mapdrives");

    this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: confirmMessage, title: title }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
                  this.mapAllDrivesEnabled = false;
                  POWERSHELL.mapAllDrives().then(res=>{
                    this.mapAllDrivesEnabled = true;
                    if(res.message){
                      this.alert(res.message.join("<br/>"), title);
                    }
                  });
                }
            });
  }

  openDrivesFile(){
    dc.openLinkInExternalBrowser("file://" + mappedDriveInfo.filename());
  }

  openSettingsFile(){
    dc.openLinkInExternalBrowser("file://" + userConfig.filename());
  }

  resetConfiguration(){
    let confirmation = i18n.t("settings.advanced-settings-resetconfiguration-confirmation");
    let restart = i18n.t("settings.advanced-settings-resetconfiguration-restartmessage");

    this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: confirmation, title: i18n.t("settings.advanced-settings-resetconfiguration-dialogtitle") }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
                    //move to somewhere else
                    userConfig.reset();
                    alert(restart);
                    remote.app.relaunch();
                    remote.app.exit(0);
                }
            });
  }

  removeDrives(){

    let confirmation = i18n.t("settings.removeDrivesConfirmation");
    let restart = i18n.t("settings.removeDrivesRestartMessage");

    this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: confirmation, title: i18n.t("settings.advanced-settings-cleardrives") }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
                    //move to somewhere else
                    mappedDriveInfo.removeFile().then(()=>{
                      alert(restart);
                      remote.app.relaunch();
                      remote.app.exit(0);
                    });
                }
            });
  }
  
  activate(modelOrMessage) {

    // this is a lifecycle of dialog
    // which will be awaited
    // if there is remote data fetching, it's a perfect opportunity
    // to prepare data here for data binding later
    
    if (typeof modelOrMessage === 'string') {
      this.message = modelOrMessage;
    } else if (typeof modelOrMessage === 'object') {
      this.message = modelOrMessage && modelOrMessage.message;
      this.title = modelOrMessage && modelOrMessage.title;
    } else {
      this.message = defaultMessage;
    }

    if (mappedDriveInfo.count() > 0){
      this.enableDriveResetButton = true;
    }
    else{
      this.enableDriveResetButton = false;
    }

    // hack for now
    let beta = userConfig.get("beta");

    if (beta){
      dc.getUserLastPwdChange().then((lastPwdDate) => {
          let maxPasswordAge = userConfig.get("maxPasswordAge") ? userConfig.get("maxPasswordAge") : 90;
          let expiresOn = new Date(lastPwdDate).addDays(maxPasswordAge);
          this.pwdExpiresOn = i18n.t("infoscreen.pwdexpiry.shortmessage", {pwdExpiryDateFull: moment(expiresOn).format("l"), pwdExpiryDate:window.moment(new Date(expiresOn)).fromNow()});
      });
    }
  }

  alert(message, title) {
    this.dialog
      .open({
        viewModel: './dialogs/message.js',
        model: {
          message: message,
          title: title
        }
      })
  }

  yes() {
    userConfig.set("language", this.selectedLanguage);

    // we don't set this in portable mode
    if (!isPortable){
      userConfig.set("autostart", this.startWhenOSStarts);
      userConfig.set("fileshareautomapping", this.fileshareautomapping);
      userConfig.set("hideNotificationOnStartup", this.hideNotificationOnStartup);
    }

    
    userConfig.set("alwaysontop", this.alwaysontop);
    
    
    // if this is enabled the autostart option needs to b e on
    if (this.fileshareautomapping){
      userConfig.set("autostart", true);
    }
    
    if (this.init_startWhenOSStarts !== this.startWhenOSStarts) {
      if (this.startWhenOSStarts)
        AutoRun.enable();
      else
        AutoRun.disable();
    }

    

    POWERSHELL.setStartupScript(this.fileshareautomapping).then(s=>{
      console.log(s);
    }).catch(e=>{
      //for now we ignore this
      console.log("Error setting registry key", this.fileshareautomapping);
    });

    let window = remote.getCurrentWindow();
    window.setAlwaysOnTop(this.alwaysontop);

    userConfig.set("minimized",+ this.startMinimized);
    userConfig.set("sendnotifications", this.notifyUser);

    if (this.selectedLanguage !== this.currentLanguage) {
      this.alert(i18n.t("app.restart-required"), i18n.t("app.restart-required-title"));
    }

    this.controller.ok({ yes: true, no: false, cancelled: false });
  }

  no() {
    this.controller.ok({ yes: false, no: true, cancelled: false });
  }

  cancel() {
    this.controller.ok({ yes: false, no: false, cancelled: true });
  }
}

// to give Aurelia a hint what the module that is associated with
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(SettingsDialog, { moduleId: 'dialogs/settings.js' });
