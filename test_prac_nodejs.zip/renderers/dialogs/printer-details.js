const defaultMessage = 'Message';

export class PrinterDetailsDialog {

  static inject() {
    return [au.dialog.DialogController];
  }

  constructor(controller) {
    this.controller = controller;
    this.title = 'Alert';
    this.printer = {};
    this.width = "500px";
    this.height = "auto";
  }

  // this is a lifecycle of dialog
  // which will be awaited
  // if there is remote data fetching, it's a perfect opportunity
  // to prepare data here for data binding later
  activate(modelOrMessage) {

        this.printer = modelOrMessage;

    if (typeof modelOrMessage === 'string') {
      this.message = modelOrMessage;
    } else if (typeof modelOrMessage === 'object') {
      this.message = modelOrMessage && modelOrMessage.message;
      this.title = modelOrMessage && modelOrMessage.title;
    } else {
      this.message = defaultMessage;
    }
  }

  // alert dialog normally has only 1 button to close it
  // simplify the logic by doing just that
  // also every action of dialog is just close,
  // there is no need to differentiate between ok, close or cancel
  close() {
    this.controller.ok();
  }
}

// to give Aurelia a hint what the module that is associated with
// class ConfirmDialog is
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(PrinterDetailsDialog, { moduleId: 'dialogs/printer-details.js' });
