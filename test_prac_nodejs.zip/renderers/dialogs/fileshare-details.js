const defaultMessage = 'Message';
const {clipboard} = remote.require('electron');

export class FileshareDialog {

  static inject() {
    return [au.dialog.DialogController];
  }

  copyToClipboard(){
    clipboard.writeText(this.fileshare.Address);
  }

  constructor(controller) {
    this.controller = controller;
    this.title = 'Alert';
    this.fileshare = {};
    this.width = "500px";
    this.height = "auto";
  }

  getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

  // this is a lifecycle of dialog
  // which will be awaited
  // if there is remote data fetching, it's a perfect opportunity
  // to prepare data here for data binding later
  activate(modelOrMessage) {
    
    this.fileshare = modelOrMessage;

    if (this.fileshare.ShareType === 'SharePoint'){
      this.spoUrl = this.getParameterByName("webUrl", this.fileshare.Address);
    }

    if (typeof modelOrMessage === 'string') {
      this.message = modelOrMessage;
    } else if (typeof modelOrMessage === 'object') {
      this.message = modelOrMessage && modelOrMessage.message;
      this.title = modelOrMessage && modelOrMessage.title;
    } else {
      this.message = defaultMessage;
    }
  }

  // alert dialog normally has only 1 button to close it
  // simplify the logic by doing just that
  // also every action of dialog is just close,
  // there is no need to differentiate between ok, close or cancel
  close() {
    this.controller.ok();
  }
}

// to give Aurelia a hint what the module that is associated with
// class ConfirmDialog is
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(FileshareDialog, { moduleId: 'dialogs/fileshare-details.js' });
