export class ManageCredentialsDialog {

  static inject() {
    return [au.dialog.DialogController]
  }

  constructor(controller) {
    this.controller = controller;
    this.title = 'Confirmation';
    this.width = "460px";
    this.password = "";
    this.username = "";
    this.target = "";
    this.lastModified = "";
  }

  // this is a lifecycle of dialog
  // which will be awaited
  // if there is remote data fetching, it's a perfect opportunity
  // to prepare data here for data binding later
  activate(model) {
    if (!model){
      return;
    }

    this.message = model.message;
    this.title = model.title + " ("+model.target+")";
    this.username = model.username;
    this.target = model.target;
    this.lastModified = "";

    if (model.lastModified){
      this.lastModified = window.moment(new Date(parseInt(model.lastModified.substr(6)))).local().fromNow(); //.format('YYYY-MM-DD HH:mm:ss');
    }
  }

  get formValid(){
    return (this.password.length !== 0 && this.username.length !== 0) ? true: false;
  }

  yes() {

    if (this.password.length === 0 || this.username.length === 0){
      return;
    }

    this.controller.ok({ yes: true, no: false, cancelled: false, username: this.username, password: this.password});
  }

  no() {
    this.controller.ok({ yes: false, no: true, cancelled: false });
  }

  cancel() {
    this.controller.ok({ yes: false, no: false, cancelled: true });
  }
}

// to give Aurelia a hint what the module that is associated with
// class ConfirmDialog is
// Note than in Aurelia application built with bundler
// we don't do this as origins are preserved/marked on export
// or it gets inlined, so no dynamic html loading is needed
au.Origin.set(ManageCredentialsDialog, { moduleId: 'dialogs/managecredentials.js' });
