const { remote } = require('electron');
const { ipcRenderer } = require('electron');
const axios = require('axios');

const authService = remote.require('./services/authentication');
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));

export class Links {
  static inject() {
    return [au.dialog.DialogService]
  }

  constructor(dialog) {
    this.dialog = dialog;
    this.loading = false;
    this.links = [];
    this.showWaitCursor = false;

    this.accElement = ".accordion.promoted";
    // this.beta = remote.getGlobal("userConfig").get("beta");

    this.hasHyperlinks = false;
    this.hasShortcuts = false;
    this.hasRdpFiles = false;
  }

  activate() {
    this.loading = true;
    this.load().then(results => {
      // console.log(results.data);
      this.loading = false;
      this.links = results; //.data.value;
    })
  }

  attached() {
    setTimeout(()=>{
      this.initAcc (this.accElement, true);
    }, 50);

    ipcRenderer.on("specialLinkHandled", (result)=>{
      this.showWaitCursor = false;
    });

    ipcRenderer.on("fileCreated", (result)=>{
      this.loading = false;
    });
  }

  handleSpecialLink(item){
    this.loading = true;
    
    // just make sure we always return
    setTimeout(()=>{
      this.loading = false;
    }, 2000);

    ipcRenderer.send('handleSpecialLink', { fileInfo: item });
  }

  load() {
    let promise = new Promise((resolve, reject) => {

      var url = 'https://graph.microsoft.com/beta/sites/'
        + appConfig.servicesite_id + '/lists/' + "Links" 
          + '/items?expand=fields(select=Title,Id,URL,Comments,FSObjType,LinkContents,LinkType)&$orderby=fields/Title asc';
      axios.get(url, {
        headers: {
          'Authorization': `Bearer ${authService.getAccessToken()}`,
          'content-type': 'application/json',
          'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
        },
      }).then((response) => {
        this.errorDuringLoad = false;

        let filtered = [];
        
        //latest
        response.data.value.forEach(item => {
          if (item.fields.FSObjType === '0') {
            
            if (item.fields.LinkType){
              item.linkType = item.fields.LinkType;
            }
            else{
              item.linkType = "Hyperlink"; //set the default to standard hyperlink
            }

            filtered.push(item);
          }
        });

        this.hasHyperlinks = filtered.filter((obj) => obj.linkType === "Hyperlink").length > 0;
        this.hasRdpFiles = filtered.filter((obj) => obj.linkType === "Rdp").length > 0;
        this.hasShortcuts = filtered.filter((obj) => obj.linkType === "Shortcut").length > 0;

        resolve(filtered);
      }).catch((error) => {
        authService.refreshTokens();
        if (error) {
          console.log(error);
          reject();
          this.loading = false;
          this.errorDuringLoad = true;
          throw new Error(error);
        }
      });
    });

    return promise;
  }

  reload() {
    this.loading = true;

    this.load().then(results => {
      if (results && results.data) {
        this.links = results.data.value;
      }
      this.loading = false;
    });
  }

  dragstart(item) {
    this.showWaitCursor = true;

    setTimeout(()=>{
      this.showWaitCursor = false;
    }, 2000);

    // send everything decide in the backend what to do with it
    ipcRenderer.send('ondragstart', { fileInfo: item });
  }

  // #region Accordion handling

  handleExpandCollapse(element, option, e) {
    // console.log(element.parentElement)
    // console.log(element, option, mouseEvent)
    if (!element.parentElement.classList.contains('active')) {
      if (option == true) {
        var elementList = document.querySelectorAll('.a-container');
        Array.prototype.forEach.call(elementList, function (e) {
          e.classList.remove('active');
        });
      }
      if (element.parentElement.classList.contains("a-container")) {
        element.parentElement.classList.add('active');
        e.stopPropagation();
        e.preventDefault();
      }
    } else {
      if (element.parentElement.classList.contains("a-container")) {
        element.parentElement.classList.remove('active');
        e.stopPropagation();
        e.preventDefault();
      }
    }
  }

  initAcc(elem, option) {

    this.accElement = elem;

    let elements = document.querySelectorAll(elem + " .a-btn");
    Array.prototype.forEach.call(elements, el => {
      el.addEventListener('click', this.handleExpandCollapse.bind(event, el, option));
    });

    // document.addEventListener('click', (e)=>{this.handleClick(e,elem,option)});
  }

  openAcc(elem) {
    let etype = "click";
    let elementToClick = document.querySelectorAll(elem)[0];
    if (elementToClick) {

      if (elementToClick.parentElement.classList.contains("active")) {
        return;
      }

      if (elementToClick.fireEvent) {
        elementToClick.fireEvent('on' + etype);
      } else {
        var evObj = document.createEvent('Events');
        evObj.initEvent(etype, true, false);
        elementToClick.dispatchEvent(evObj);
      }
    }
  }

  // #endregion
}