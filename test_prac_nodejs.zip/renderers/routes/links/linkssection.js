export class LinksSection {
    configureRouter(config, router) {
        config.map([
            { route: '', name: 'start', moduleId: './start.js', icon: 'oi-print', title: i18n.t('navigation.links'), nav: true },
        ]);
    }
}