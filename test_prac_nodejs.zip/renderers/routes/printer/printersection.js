export class PrinterSection {
    configureRouter(config, router) {
      config.map([
        { route: '', name: 'start', moduleId: './start.js', icon:'oi-print', image:'../images/printers.svg',title: i18n.t('navigation.printers-overview'), nav: true },
        { route: 'search', name: 'search', moduleId: './search.js', icon:'oi-print', image:'../images/printers.svg',title: i18n.t('navigation.printers'), nav: false },
      ]);
    }
  }