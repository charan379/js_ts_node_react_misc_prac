const authService = remote.require('./services/authentication');
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));
const axios = require('axios');
const powershell = remote.require('./services/powershell');

const { sp, SearchQueryBuilder } = require('@pnp/sp-commonjs');
const { NodeFetchClient } = require('@pnp/nodejs-commonjs');

export class PrinterSearch {

    static inject() {
      return [au.Router]
    }

    constructor(router) {
        this.results = [];
        this.querytext = "";
        this.loading = false;
        this.drivers = [];
        this.router = router;
    }

    navigateBack(){
      this.router.navigateBack();
    }

    attached() {
        powershell.getInstalledDrivers().then((result)=>{
          if (result.drivers){
            let drivers = result.drivers.map(a=>a.Name)
            this.drivers = drivers;
          }
        });

        //attach events for enter key
        this.searchhero.addEventListener('keypress', e => {
            let key = e.which || e.keyCode;

            if (key === 13) {
                this.handleSearch();
            }

        }, false);

        this.searchhero.focus();
    }

    handleSearch() {
      this.search().then(r => {
        this.results = r;
      });
    }

    //needs to be refactored in custom dc
    loadPrinterDetails(printerId) {
      this.loading = true;
  
      let promise = new Promise((resolve, reject) => {
  
        var url = 'https://graph.microsoft.com/beta/sites/'
          + appConfig.servicesite_id + '/lists/'
          + appConfig.printerslist_id
          + '/items/' + printerId
          + '/?expand=fields(select=Id,Title,NetworkAddress,PrinterLocation,SupportedDriver,PrinterType,Remarks,CredentialsRequired)';
  
        axios.get(url, {
          headers: {
            'Authorization': `Bearer ${authService.getAccessToken()}`,
            'content-type': 'application/json'
          },
        }).then((response) => {
          this.errorDuringLoad = false;
          
          let printer = response.data.fields;
  
          let neededDrivers = printer.SupportedDriver ? printer.SupportedDriver.split(',') : [];
  
          let hasDriver = neededDrivers.some((p)=>{
            return this.drivers.includes(p);
          });
  
          printer.driverIsInstalled = hasDriver;
  
          this.loading = false;
          resolve(printer);
        }).catch((error) => {
          if (error) {
            console && console.log(error);
            reject();
            this.loading = false;
            this.errorDuringLoad = true;
            throw new Error(error);
          }
        });
      });
  
      return promise;
    }

    reload() {
      if (this.querytext.length === 0) {
        return;
    }
      this.handleSearch();
    }

    addPrinterPs(printer){
      
      return new Promise((resolve, reject)=>{
        this.loading = true;
        powershell.addPrinter(printer).then((output) => {
            this.loading = false;
            resolve(output);
        }).
            catch((err) => {
                reject(err);
                this.loading = false;
            });
      });
    }  

    search() {

        if (this.querytext.length === 0) {
            return;
        }

        this.loading = true;

        let promise = new Promise((resolve, reject) => {

            authService.getAccessTokenByRefreshToken(appConfig.tenantspo + "/Sites.Search.All").then(accessToken => {
                //we need to cache that token somewhere
                sp.setup({
                    sp: {
                        baseUrl: `${appConfig.servicesite}`,
                        headers: {
                            "Accept": "application/json;odata=verbose",
                            "Authorization": `Bearer ${accessToken}`
                        },
                        fetchClientFactory: () => new NodeFetchClient()
                    }
                });

                let q = new SearchQueryBuilder("Path:" + appConfig.servicesite + "/Lists/Printers" + " (" + this.querytext + ")"
                    ,{
                        TrimDuplicates: false,
                        RowLimit: 500,
                        SelectProperties: ["ListItemID", "Title", "RefinableString00", "PrinterLocation", "NetworkAddress", "SupportedDriver", "PrinterType", "Remarks", "CredentialsRequired"]
                    }).rowLimit(500);
                
                sp.search(q).then((r) => {
                    //this.results = r.PrimarySearchResults;
                    let result = [];
                    r.PrimarySearchResults.forEach(el => {
                        result.push({
                          Id: el.ListItemID,
                          Title: el.Title,
                          PrinterLocation: el.PrinterLocation,
                          PrinterType: el.PrinterType,
                          CredentialsRequired: el.CredentialsRequired
                        })
                      });


                    resolve(result);
                    this.loading = false;
                }).catch(e=>{
                    console.log(e)
                });
            });
            // dc.queryPrinters(this.querytext).then((result)=>{
            //     console.log("query", result);
            //     this.results = result.data.value;
            //     resolve(result);
            // }).catch((e)=>{
            //     console.log(e)
            //     reject(e);
            // });
        });

        return promise;
    }
}