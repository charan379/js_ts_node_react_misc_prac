const { remote } = require('electron');
const axios = require('axios');

const authService = remote.require('./services/authentication');
const dc = remote.require('./services/datacontext');
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));
const powershell = remote.require('./services/powershell');

// move to dc in later release
const { sp, SearchQueryBuilder } = require('@pnp/sp-commonjs');
const { NodeFetchClient } = require('@pnp/nodejs-commonjs');

export class Printers {

  static inject() {
    return [au.dialog.DialogService, au.Router]
  }

  constructor(dialog, router) {
    this.router = router;
    this.dialog = dialog;
    this.errorDuringLoad = false;
    this.loading = false;
    this.location = "";
    this.printers = [];
    this.drivers = [];
  }

  activate() {
    this.loading = true;
    this.errorDuringLoad = false;
    return dc.profileDetails().then((p) => {
      this.profile = p;
      this.location = `${p.usageLocation}${p.country ? '/' + p.country : ''}${p.city ? '/' + p.city : ''}`;
      this.loading = true;

      this.searchPrinters(p).then(results => {
        this.printers = results;
        this.loading = false;

        this.loadDriversAndmarkAvailablePrinters();
      });

      
    }).catch(e=>{
      this.loading = false;
      this.errorDuringLoad = true;
    });
  }

  loadDriversAndmarkAvailablePrinters(){
    //
    powershell.getInstalledDrivers().then((result) => {
      if (result.drivers) {
        let drivers = result.drivers.map(a => a.Name)
        this.drivers = drivers;
        this.availablePrinters = result.printers;


        this.printers.forEach(printer=>{
          this.availablePrinters.forEach(pInfo=>{
            if (pInfo.Name === printer.Title){
              printer.available = true;
            }
          });
        });
      }
      else {
        this.drivers = [];
      }
    }).catch((e)=>{
      //just catch this - this is not crucial for the tool to work
      console.log(e);
    });
  }

  openPrinterDialog() {
    powershell.openPrinterDialog();
  }

  advanceToSearch() {
    this.router.navigateToRoute("printersearch");
  }

  openCredentialManager(){
    return new Promise((resolve, reject) => {
      powershell.openCredentialManager().then((output) => {
      });
    });
  }

  reload() {
    this.loading = true;

    if (this.errorDuringLoad){
      
    }

    this.searchPrinters(this.profile).then((printers) => {
      this.loading = false;
      this.printers = printers;
      this.errorDuringLoad = false;
      this.loadDriversAndmarkAvailablePrinters();
    });
  }

  searchPrinters(profile) {

    let searchString = profile.usageLocation + " " + (profile.city ? profile.city : "")

    let promise = new Promise((resolve, reject) => {
      
      authService.getAccessTokenByRefreshToken(appConfig.tenantspo + "/Sites.Search.All").then(accessToken => {
        sp.setup({
          sp: {
            baseUrl: `${appConfig.servicesite}`,
            headers: {
              "Accept": "application/json;odata=verbose",
              "Authorization": `Bearer ${accessToken}`
            },
            fetchClientFactory: () => new NodeFetchClient()
          }
        });
        console && console.log("Try to find printers based on 'Usage Location':" + searchString)

        /*
         sp.web.select("Title", "Description").get().then(w => {
          console.log(JSON.stringify(w, null, 4));
        });
        */
        //LocationJSON:

        console.log(searchString)

        let q = new SearchQueryBuilder("Path:" + appConfig.servicesite + "/Lists/Printers" + " (PrinterLocation:" + searchString + ")"
          , {
            TrimDuplicates: false,
            RowLimit: 500,

            SelectProperties: ["ListItemID", "Title", "RefinableString00", "NetworkAddress", "PrinterLocation", "SupportedDriver", "PrinterType", "Remarks", "CredentialsRequired"]
          }).rowLimit(500);

        /*Managed Properties 
          PrinterLocation /Mapped to Location & PrinterLocation 
          PrinterType /Mapped to PrinterType
          CredentialsRequired /Mapped to CredentialsRequired
        */

        sp.search(q).then((r) => {
          
          //console.log("Results", r.RowCount);
          // console.log(r.PrimarySearchResults);

          let result = [];

          //console.log(r.PrimarySearchResults)
          if (r.PrimarySearchResults){
            r.PrimarySearchResults.forEach(el => {
              result.push({
                Id: el.ListItemID,
                Title: el.Title,
                PrinterLocation: el.PrinterLocation,
                PrinterType: el.PrinterType,
                CredentialsRequired: el.CredentialsRequired
  
              })
            });
          }
          

          this.errorDuringLoad = false;

          resolve(result);
        }).catch(e => {
          this.errorDuringLoad = true;
        });


      }).catch(e=>{
        this.errorDuringLoad = true;
      });
    });

    return promise;
  }

  loadPrinters() {
    //not used
    let promise = new Promise((resolve, reject) => {

      var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + appConfig.printerslist_id
        + '/items?expand=fields(select=Id,Title,NetworkAddress,PrinterLocation,SupportedDriver,PrinterType,Remarks,CredentialsRequired)';

      axios.get(url, {
        headers: {
          'Authorization': `Bearer ${authService.getAccessToken()}`,
          'content-type': 'application/json'
        },
      }).then((response) => {
        this.errorDuringLoad = false;
        console.log(response)
        resolve(response);
      }).catch((error) => {
        // authService.refreshTokens().then(()=>{
        //   console.log(error);
          
        // });
        if (error) {
          reject();
          this.loading = false;
          this.errorDuringLoad = true;
          throw new Error(error);
        }
      });
    });

    return promise;
  }

  loadPrinterDetails(printerId) {
    this.loading = true;

    let promise = new Promise((resolve, reject) => {

      var url = 'https://graph.microsoft.com/beta/sites/'
        + appConfig.servicesite_id + '/lists/'
        + appConfig.printerslist_id
        + '/items/' + printerId
        + '/?expand=fields(select=Id,Title,NetworkAddress,PrinterLocation,SupportedDriver,PrinterType,Remarks,CredentialsRequired)';

      axios.get(url, {
        headers: {
          'Authorization': `Bearer ${authService.getAccessToken()}`,
          'content-type': 'application/json'
        },
      }).then((response) => {
        this.errorDuringLoad = false;

        let printer = response.data.fields;

        let neededDrivers = printer.SupportedDriver ? printer.SupportedDriver.split(',') : [];

        let hasDriver = neededDrivers.some((p) => {
          return this.drivers.includes(p);
        });

        printer.driverIsInstalled = hasDriver;

        this.availablePrinters.forEach(pInfo=>{
          if (pInfo.Name === printer.Title){
            printer.available = true;
          }
        });

        this.loading = false;
        resolve(printer);
      }).catch((error) => {
        if (error) {
          console && console.log(error);
          reject();
          this.loading = false;
          this.errorDuringLoad = true;
          throw new Error(error);
        }
      });
    });

    return promise;
  }

  addPrinterPs(printer) {
    return new Promise((resolve, reject) => {
      this.loading = true;
      powershell.addPrinter(printer).then((output) => {
        this.loading = false;
        resolve(output);
      }).
        catch((err) => {
          reject(err);
          this.loading = false;
        });
    });
  }

  alert(message, title) {
    this.dialog
      .open({
        viewModel: './dialogs/message.js',
        model: {
          message: message,
          title: title
        }
      })
  }
}