const dc = remote.require('./services/datacontext');

const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));
const powershell = remote.require('./services/powershell');
const mappedDriveInfo = remote.getGlobal("mappedDriveInfo");
const axios = require('axios');
const authService = remote.require('./services/authentication');

import { ManageCredentialsDialog } from '../dialogs/managecredentials.js';

// move to dc in later release
const { sp, SearchQueryBuilder } = require('@pnp/sp-commonjs');
const { NodeFetchClient } = require('@pnp/nodejs-commonjs');

export class Fileshares {

  static inject() {
    return [au.dialog.DialogService]
  }

  constructor(dialog) {
    this.config = appConfig;
    this.loading = false;
    this.errorDuringLoad = false;
    this.querytext = "";
    this.dialog = dialog;
    this.connectedshares = [];
    this.accElement = ".accordion.promoted";
  }

  activate() {
    this.load();
  }

  attached() {
    //attach events for enter key
    this.searchhero.addEventListener('keypress', e => {
      let key = e.which || e.keyCode;

      if (key === 13) {
        this.handleSearch();
      }

    }, false);

    // this.searchhero.focus(); // does not look very nice

    setTimeout(()=>{
      this.initAcc (this.accElement, true);
    }, 50);
  }

  detached(){
    let elements = document.querySelectorAll(this.accElement + " .a-btn");
    // console.log(elements)
    Array.prototype.forEach.call(elements, el=>{
      console.log("remove")
      el.removeEventListener('click', this.handleExpandCollapse)
    });
   
  }
  
  replacePlaceholders(fieldvalue, propertybag){

    if (fieldvalue && fieldvalue.indexOf("{") === -1){ // nothing to replace
      return fieldvalue;
    }
    
    let placeholders = dc.getPlaceholders(fieldvalue);

    placeholders.forEach(property => {
      let val = (propertybag[property] ? propertybag[property] : "");
      
      if (!val){
        fieldvalue = fieldvalue//.replace( property, "{" +property + "}"); //just keep it as is
      }
      else{
        fieldvalue = fieldvalue.replace("{" + property + "}", val);
      }
    });

    return fieldvalue;
  }

  load() {
    this.loading = true;
    this.connectedshares = [];

    //change 2021 - allow dynamic mappings
    return dc.getProfile(true).then(info => {
      this.userDetails = info.rawValues;

      return dc.getTopFileshares().then((fileshares) => {
        //0721 - change check if the user already selected this share 
        fileshares.value.forEach(f => {
          
          f.fields.Address = this.replacePlaceholders (f.fields.Address, this.userDetails);

          if (mappedDriveInfo.get(f.fields.Title)) {
            f.fields.isMapped = true;
            this.connectedshares.push(f);
          }
        });

        this.loading = false;
        this.errorDuringLoad = false;
        this.fileshares = fileshares.value;

        let mapped = mappedDriveInfo.getAll();

        mapped.forEach(md=>{
          let found = false;
          this.connectedshares.forEach((cs)=>{
            if (cs.fields.Address === md.Address){
              found = true;
            }
          });

          if (!found){
            //this.connectedshares.push(md);
          }
        });
      }).catch(e => {
        this.loading = false;
        this.errorDuringLoad = true;
      });
    });
  }

  reload() {
    this.load().then(() => {
      this.handleSearch();
    });
  }

  handleSearch(){
    this.search().then(results => {
      if (results) {
        this.results = results;
        // if we find something make sure this section will be expanded
        this.openAcc(".a-btn.accordion.search");
      }
      this.loading = false;
    });
  }

  loadFileshareDetails(shareID) {
    let promise = new Promise((resolve, reject) => {

      var url = 'https://graph.microsoft.com/beta/sites/'
        + appConfig.servicesite_id + '/lists/'
        + appConfig.filesharelist_id
        + '/items/' + shareID
        + '/?expand=fields(select=Id,Title,Address,DriveName,DriveLetter,Remarks,ShareType,CredentialsRequired,Top)';

      axios.get(url, {
        headers: {
          'Authorization': `Bearer ${authService.getAccessToken()}`,
          'content-type': 'application/json'
        },
      }).then((response) => {
        this.errorDuringLoad = false;
        let share = response.data.fields;

        // change 07/2021 - transform file share details
        share.Address = this.replacePlaceholders (share.Address, this.userDetails);

        if (mappedDriveInfo.get(share.Title)) {
          share.isMapped = true;
        }
        
        resolve(share);
      }).catch((error) => {
        if (error) {
          console && console.log(error);
          reject();
          // this.loading = false;
          this.errorDuringLoad = true;
          throw new Error(error);
        }
      });
    });

    return promise;
  }

  loadFileshareInfoPS(share) {
    return new Promise((resolve, reject) => {
      this.loading = true;

      // hack for now - we need to check if subst was involved
      if (share.ShareType && share.ShareType === 'SharePoint'){
        resolve("{\"exists\":false}");
        this.loading = false;
        return;
      }
      
      // we still have missing info
      if (share.Address.indexOf("{") !== -1){
        resolve("{\"exists\":false}");
        this.loading = false;
        return;
      }
    
      powershell.getFileshareInfo(share).then((output) => {
        this.loading = false;
        resolve(output);
      }).
        catch((err) => {
          reject(err);
          this.loading = false;
        });
    });
  }

  openCredentialManager(){
    return new Promise((resolve, reject) => {
      powershell.openCredentialManager().then((output) => {
      });
    });
  }

  manageCredentialsPS(share) {
    return new Promise((resolve, reject) => {
      
      this.loading = true;
      // we need details otherwise this won't work
      this.loadFileshareDetails(share.fields.id).then((shareDetails)=>{

        share = shareDetails;

        let cleanAddress = share.Address;

        //remove all placeholders for credential info
        let placeholder = dc.getPlaceholders(share.Address);
        placeholder.forEach(p=>{
          cleanAddress = cleanAddress.replace("{" + p + "}","");
        });

        powershell.getCredentialManagerInfo(cleanAddress).then((output) => {
          setTimeout(()=>{
            this.loading = false;
          }, 500);

          // in case we never stored credentials before
          if (!output.info){
            output.info = {};
            output.info.Username = "";
            output.info.LastModified = "";
            output.info.Target = cleanAddress//share.Address
          }
          
  
          this.dialog
          .open({
              viewModel: ManageCredentialsDialog,
              model: 
              { 
                message: i18n.t('fileshares.managecredentials.message', {title: share.Title}), 
                title: i18n.t('fileshares.managecredentials.title', {title: share.Title}),
                username: output.info.UserName,
                lastModified: output.info.LastModified,
                target: output.info.Target ? output.info.Target : "-"
              }
          })
          .whenClosed(result => {
              if (result.wasCancelled || !result.output) {
                  return;
              }
              // if answered yes, reload
              if (result.output.yes) {
  
                powershell.setCredentials(cleanAddress, result.output.username, result.output.password).then((result)=>{
                  if (result.success){
                    
                    this.alert(i18n.t('fileshares.managecredentials.updatedmessage'), i18n.t('fileshares.managecredentials.updatedtitle'));
                  }
                  else{
                    console.log(result.message)
                    this.alert(i18n.t('fileshares.managecredentials.updatefailedmessage'), i18n.t('fileshares.managecredentials.updatedtitle'));
                  }
                });
              }
            });
  
          resolve(output);
        }).
          catch((err) => {
            reject(err);
            this.loading = false;
          });
      });
    });
  }

  mapFilesharePS(share) {
    return new Promise((resolve, reject) => {
      this.loading = true;

      //experimental
      if (share.ShareType === "SharePoint"){

        if (share.Address.indexOf ("mailaddress") == -1){
          share.Address = share.Address + "&mailaddress=" + this.userDetails["mail"];
        }

        if (share.Address.indexOf ("tenantName") == -1){
          share.Address = share.Address + "&tenantName=" + this.userDetails["mail"].split("@")[1];
        }

        if (share.Address.indexOf ("webTitle") == -1){
          share.Address = share.Address + "&webTitle=" + share.Title.split("-")[0].trim();
        }

        if (share.Address.indexOf ("listTitle") == -1){
          share.Address = share.Address + "&listTitle=" +  (share.Title.split("-").length > 1? share.Title.split("-")[1].trim() : share.Title.trim());
        }

        // store row in drives.json
        mappedDriveInfo.set(share.Title, {
          "Address": share.Address,
          "DriveName": share.DriveName,
          "DriveLetter": share.DriveLetter,
          "ShareType": share.ShareType
        });

        powershell.mapSPODrive(share).then((output)=>{
          this.loading = false;

          if (output.success === true) {
            resolve(output);
          }
          else{
            reject(output.message);
          }
          
        }).catch(err=>{
          reject(err.message);
          this.loading = false;
        });

        // resolve({success:true});

        return;
      }

      powershell.mapDrive(share).then((output) => {

        this.loading = false;

        if (output.success === true) {
          // store row in drives.json
          mappedDriveInfo.set(share.Title, {
            "Address": share.Address,
            "DriveName": share.DriveName,
            "DriveLetter": share.DriveLetter,
            "ShareType": share.ShareType
          });
          resolve(output);
        }
        else {
          reject(output.message);
        }
      }).catch((err) => {
          reject(err.message);
          this.loading = false;
      });
    });
  }

  forgetDrive(share){
    mappedDriveInfo.remove(share.Title);
  }

  disconnectFilesharePS(share) {
    return new Promise((resolve, reject) => {

      this.loading = true;

      powershell.disconnectDrive(share).then((output) => {

        this.loading = false;

        //we remove this always for now
        // mappedDriveInfo.remove(share.Title);
        this.forgetDrive(share);

        if (output.success === true) {
          resolve(output);
        }
        else {
          reject(output.message)
        }

      }).catch((err) => {
        reject(err);
        this.loading = false;
      });
    });
  }

  search() {
    this.loading = true;

    let promise = new Promise((resolve, reject) => {

      if (this.querytext.length === 0) {
        resolve();
        return;
      }

      authService.getAccessTokenByRefreshToken(appConfig.tenantspo + "/Sites.Search.All").then(accessToken => {
        //we need to cache that token somewhere
        sp.setup({
          sp: {
            baseUrl: `${appConfig.servicesite}`,
            headers: {
              "Accept": "application/json;odata=verbose",
              "Authorization": `Bearer ${accessToken}`
            },
            fetchClientFactory: () => new NodeFetchClient()
          }
        });

        let q = new SearchQueryBuilder("Path:" + appConfig.servicesite + "/Lists/Fileshares"
          + " (" + this.querytext + ") ContentClass:STS_ListItem"
          , {
            TrimDuplicates: false,
            RowLimit: 500,
            SelectProperties: ["ListItemID", "Title", "RefinableString00", "RefinableString01", "RefinableString03", "RefinableString02"]
          }).rowLimit(500);

        console.log("Path:" + appConfig.servicesite + "/Lists/Fileshares"
          + " (" + this.querytext + ") ContentClass:STS_ListItem")

        sp.search(q).then((r) => {
          //this.results = r.PrimarySearchResults;
          let result = [];
          r.PrimarySearchResults.forEach(el => {
            // console.log(el)
            result.push({
              Id: el.ListItemID,
              Title: el.Title,
              Address: el.RefinableString02 ? el.RefinableString02 : "Not available",
              Remarks: el.RefinableString01,
              ShareType: el.RefinableString03,
              CredentialsRequired: false /*for now wait that details are loaded */
            })

            //transform search result 07/2021
            result.Address = this.replacePlaceholders (result.Address, this.userDetails);

          });
          resolve(result);
          this.loading = false;
        }).catch(e => {
          console.log(e)
        });
      });
    });

    return promise;
  }

  // #region Helper
  
  shorten(str, maxLen, separator = ' ') {
    if (str.length <= maxLen)
      return str;

    return str.substr(0, str.lastIndexOf(separator, maxLen));
  }

  openlinkinbrowser(link) {
    dc.openLinkInExternalBrowser(link);
  }

  alert(message, title) {
    this.dialog
      .open({
        viewModel: './dialogs/message.js',
        model: {
          message: message,
          title: title
        }
      })
  }

  // #endregion

  // #region Accordion handling

  handleExpandCollapse(element, option, e){ 
    console.log(element.parentElement)
    // console.log(element, option, mouseEvent)
    if (!element.parentElement.classList.contains('active')) {
      if (option == true) {
        var elementList = document.querySelectorAll('.a-container');
        Array.prototype.forEach.call(elementList, function (e) {
          e.classList.remove('active');
        });
      }
      if (element.parentElement.classList.contains("a-container")) {
        element.parentElement.classList.add('active');
        e.stopPropagation();
        e.preventDefault();
      }
    } else {
      if (element.parentElement.classList.contains("a-container")) {
        element.parentElement.classList.remove('active');
        e.stopPropagation();
        e.preventDefault();
      }
    }
  }

  initAcc(elem, option) {

    this.accElement = elem;

    let elements = document.querySelectorAll(elem + " .a-btn");
    Array.prototype.forEach.call(elements, el=>{
      el.addEventListener('click', this.handleExpandCollapse.bind(event, el, option));
    });

    // document.addEventListener('click', (e)=>{this.handleClick(e,elem,option)});
  }

  openAcc(elem){
    let etype = "click";
    let elementToClick = document.querySelectorAll(elem)[0];
    if (elementToClick) {

      if (elementToClick.parentElement.classList.contains("active")){
        return;
      }

      if (elementToClick.fireEvent) {
        elementToClick.fireEvent('on' + etype);
      } else {
        var evObj = document.createEvent('Events');
        evObj.initEvent(etype, true, false);
        elementToClick.dispatchEvent(evObj);
      }
    }
  }

  // #endregion
}