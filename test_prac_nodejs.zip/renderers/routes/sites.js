const dc = remote.require('./services/datacontext');
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));

export class Sites {

  constructor() {
    this.config = appConfig;
    this.loading = false;
    this.errorDuringLoad = false;
  }
  
  activate() {
    this.load();
  }

  load (){
    this.loading = true;
    
    return dc.loadsites().then((sites) => {
      this.loading = false;
      this.errorDuringLoad = false;
      this.sites = sites;// sites.data.value;
    }).catch(e=>{
      this.loading = false;
      this.errorDuringLoad = true;
    });
  }

  shorten(str, maxLen, separator = ' ') {
    if (str.length <= maxLen)
        return str;
  
      return str.substr(0, str.lastIndexOf(separator, maxLen));
  }

  reload(){
    return this.load();
  }
  
  openlinkinbrowser(link) {
    dc.openLinkInExternalBrowser(link);
  }
}