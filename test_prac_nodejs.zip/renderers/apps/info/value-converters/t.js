const I18N = remote.require('./services/translation');

export class TValueConverter {
    static inject() { return [I18N]; }

    constructor(i18n) {
        this.service = i18n;
    }

    toView(value, options) {
        if (!value){
            return null;
        }
        return this.service.t(value, options);
    }
}