const i18n = remote.require('./services/translation');
const { ipcRenderer } = require('electron');
const { app } = require('electron');
const userConfig = remote.getGlobal("userConfig");
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(remote.process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));

export class App {
    static inject() {
        return [au.EventAggregator]
    }

    constructor(ea) {
        this.ea = ea;
        this.window = remote.getCurrentWindow();
        this.hideNotificationOnStartup = Boolean(userConfig.get("hideNotificationOnStartup") ? userConfig.get("hideNotificationOnStartup") : false)
    }

    changeNotificationSettings() {
        userConfig.set("hideNotificationOnStartup", this.hideNotificationOnStartup);
    }

    hideNotificationOnStartupChanged() {

    }

    attached() {

    }

    configureRouter(config, router) {
        this.router = router;
        this.router.title = "Service Tool";

        const querystring = require('querystring');
        let query = querystring.parse(global.location.search);
        let data = JSON.parse(query['?data'])

        //if there is a paramater set initial route
        if (data.module) {
            config.map([
                { route: ['', data.module], name: data.module, moduleId: 'routes/' + data.module + '.js', title: i18n.t('infoscreen.' + data.module + '.windowtitle'), nav: true, settings: data.additionalData },
            ]);
        }
        else {
            config.map([
                { route: ['', 'pwdchange'], name: 'pwdchange', moduleId: 'routes/pwdchange.js', title: i18n.t('infoscreen.pwdchange.windowtitle'), nav: true },
            ]);
        }

        config.mapUnknownRoutes('./../../routes/not-found.js');
        this.router = router;
    }
}