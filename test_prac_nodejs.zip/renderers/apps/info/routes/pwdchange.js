const i18n = remote.require('./services/translation');
const { ipcRenderer } = require('electron');

export class PwdChanged{
    
    static inject() {
        return [au.Router]
      }

    constructor(router){
        this.window = remote.getCurrentWindow();
        this.router = router;
    }
    
    attached() {
       
        this.additionalInfo = this.router.currentInstruction.config.settings;
        this.message = i18n.t("infoscreen.pwdchange.message", {lastchanged: window.moment(new Date(this.additionalInfo.date)).fromNow()});
    }

    closewindow(){
        this.window.close();
    }

    updatecredentials(){
        ipcRenderer.send("pwdreminderdate", new Date()); //reset reminder date - this will always be a 1:1 credential mapping
        ipcRenderer.send("navigate", "fileshares");
        this.window.close();
    }
}