const i18n = remote.require('./services/translation');
const { ipcRenderer } = require('electron');

export class ConfigurationUpdate{
    static inject() {
        return [au.Router]
      }

    constructor(router){
        this.window = remote.getCurrentWindow();
        this.router = router;
        this.selectedConfig;
    }
    
    attached() {
        this.message = i18n.t("infoscreen.configurationupdate.message");
        this.remoteConfigurations = this.router.currentInstruction.config.settings.remoteConfigurations;
        
        this.selectedConfig = this.remoteConfigurations[0]
    }

    get UpdateNotes(){
        if (this.selectedConfig)
            return this.selectedConfig.UpdateInfo
        else    
            return "";
    }

    closewindow(){
        this.window.close();
    }

    updateConfig(){
        ipcRenderer.send('apply-org-data', this.selectedConfig);
        this.window.close();
    }
}