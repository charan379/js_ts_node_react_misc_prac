const i18n = remote.require('./services/translation');
const { ipcRenderer } = require('electron');

export class PwdExpiry{
    
    static inject() {
        return [au.Router]
      }

    constructor(router){
        this.window = remote.getCurrentWindow();
        this.router = router;
    }
    
    attached() {
       
        this.additionalInfo = this.router.currentInstruction.config.settings;
        this.message = i18n.t("infoscreen.pwdexpiry.message", {pwdExpiryDate: window.moment(new Date(this.additionalInfo.date)).fromNow(), pwdExpiryDateFull: this.additionalInfo.date_title});
    }

    saveReminderDate(){
        ipcRenderer.send("pwdexpiryreminderdate", this.additionalInfo.date);
        this.window.close();
    }
    closewindow(){
        this.window.close();
    }
}