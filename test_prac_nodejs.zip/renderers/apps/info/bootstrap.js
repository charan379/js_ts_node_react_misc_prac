//needs to be called first

const { remote } = require('electron');
const aurelia = new au.Aurelia();
const path = remote.require('path');
const isDevelopment = remote.process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${remote.getGlobal('__basedir')}`) : path.normalize(remote.process.resourcesPath);
const appConfig = require(path.join(rootPath,'./env-variables'));
// console.log(appConfig)
const i18n = remote.require('./services/translation');

var currentLanguage = "";
var appStarting = true;

// just make sure we start at root - since we don't use any webserver
aurelia.loader.baseUrl = path.normalize(`${__dirname}`);

function setLanguage() {
  if (remote.getGlobal("userConfig").get("language")) {
    //on loaded set the user language
    i18n.changeLanguage(remote.getGlobal("userConfig").get("language"));
  }
  else {
    //on loaded set the configured language
    i18n.changeLanguage(appConfig.defaultlng);
  }
  currentLanguage = i18n.language;
  i18n.off('loaded');

  window.moment.locale(i18n.language);
}
i18n.on('loaded', (loaded) => {
  setLanguage();
});

if (i18n.isInitialized) {
  setLanguage();
}



i18n.on('languageChanged', (lng) => {

  // hack set moment language globally to given language
  window.moment.locale(lng)

  // just in case the language is changed. since we cannot use the 
  // default libs we need to require a reload
  if (lng != currentLanguage && !appStarting) {
    alert(i18n.t("app.restart-required"));
  }

  appStarting = false;
});

aurelia
  .use
  .standardConfiguration()
  .plugin(au.dialog.configure, config => {
    config.useDefaults();
    config.settings.lock = true;
    config.settings.centerHorizontalOnly = false;
    config.settings.startingZIndex = 5;
    config.settings.keyboard = true;
  })
  .globalResources(['./value-converters/t.js','./components/bar.js','./components/footer.js'])
  .developmentLogging();

aurelia
  .start()
  .then(() => {
    aurelia.setRoot('./app.js', document.body);
  });
