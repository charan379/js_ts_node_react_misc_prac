export class Bar{
    
}