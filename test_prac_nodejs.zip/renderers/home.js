const webContents = remote.getCurrentWebContents();
const { ipcMain } = remote;
let oldStatus = 'online';
let reloaded = false;

webContents.on('dom-ready', () => {
  
  let window = remote.getCurrentWindow();

  //send event if online status changes
  require('../main/onlineOfflineListener')()

  ipcMain.on('online-status-changed', (event, status) => {
    if ((!reloaded) && (oldStatus === 'offline') && (oldStatus !== status)) {
      reloaded = true;
      setTimeout(() => window.reload(), 10000);
    }
    oldStatus = status;
  });
});