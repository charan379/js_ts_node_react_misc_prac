const i18n = remote.require('./services/translation');
const { ipcRenderer } = require('electron');
const userConfig = remote.getGlobal("userConfig");

export class App {
  static inject() {
    return [au.EventAggregator]
  }
  
  constructor(ea) {
    this.ea = ea;
  }

  configureRouter(config, router) {
    this.router = router;
    this.router.title = "Service Tool";

    let hidden_modules = userConfig.get("hide_modules");

    let routes = [
      { route: 'news', name: 'news', moduleId: 'routes/news.js', icon: 'oi-bullhorn', image: './images/announcements.svg', title: i18n.t('navigation.announcements'), nav: true },
      { route: 'printers', name: 'printers', moduleId: './routes/printer/printersection.js', icon: 'oi-print', image: './images/printers.svg', title: i18n.t('navigation.printers'), nav: true },
      { route: 'fileshares', name: 'fileshares', moduleId: './routes/fileshares.js', icon: 'oi-folder', image: './images/fileshares.svg', title: i18n.t('navigation.fileshares'), nav: true },
      { route: 'sites', name: 'sites', moduleId: './routes/sites.js', icon: 'oi-cloud', image: './images/sites.svg', title: i18n.t('navigation.sites'), nav: true },
      { route: 'links', name: 'links', moduleId: './routes/links/linkssection.js', icon: 'oi-external-link', image: './images/discovery.svg', title: i18n.t('navigation.links'), nav: true },
    ];

    if (hidden_modules) {
      routes.forEach(r => {
        if (hidden_modules.indexOf(r.name) != -1) {
          r.nav = false;
        }
      });
    }

    /* module_order
      [
        "printers",
        "fileshares",
        "sites",
        "news",
        "links"
      ]
    */
    let module_order = userConfig.get("modules_sortorder");

    if (module_order){
      let ordering = {}; // map for efficient lookup of sortIndex
      for (let i = 0; i < module_order.length; i++)
        ordering[module_order[i]] = i;

      routes.sort(function (a, b) {
        return (ordering[a.name] - ordering[b.name]) //|| a.class.localeCompare(b.class);
      });
    }

    // make sure we have a default route - e.g. default if news is hidden
    for (let i = 0; i < routes.length; i++) {
      if (routes[i].nav) {
        let r = [];
        r.push('');
        r.push(routes[i].route);
        routes[i].route = r;
        break;
      }
    }

    config.map(routes);

    config.mapUnknownRoutes('./routes/not-found.js');

    this.router = router;

    //callback from tray icon
    ipcRenderer.on('route', (event, route) => {
      if (route && route.indexOf('#') === -1) {
        if (route !== this.router.currentInstruction.config.name) {
          this.router.navigateToRoute(route);
        }
      }
      else if (route.indexOf('#') !== -1) { //we got some request via protocol extension
        this.router.navigate(route);
      }
    });

    //just eyecandy
    this.ea.subscribe("router:navigation:processing", (route) => {
      let image = route.instruction.config.image;

      if (image) {
        let footer = document.getElementsByTagName("footer")[0];

        if (footer) {
          footer.className = "fade-in-image footer " + route.instruction.config.name;
          footer.style.backgroundImage = "url(" + image + ")";
        }
        else{
          setTimeout(()=>{
            let footer = document.getElementsByTagName("footer")[0];
            if (footer) {
              footer.className = "fade-in-image footer " + route.instruction.config.name;
              footer.style.backgroundImage = "url(" + image + ")";
            }
          }, 1000);
        }
      }
    });
  }
}