export class TruncateValueConverter { // eslint-disable-line import/prefer-default-export
    toView(value, length = 10) { // eslint-disable-line class-methods-use-this
      return value && value.length > length ? `${value.substring(0, length)}...` : value;
    }
  }