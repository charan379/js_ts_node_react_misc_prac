const SCRIPT_REGEX = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;

export class SanitizeHtmlValueConverter {
  toView(value) {
    return !!value ? this.sanitize(value) : "";
  }

  sanitize(input) {
    return input.replace(SCRIPT_REGEX, '');
  }
}