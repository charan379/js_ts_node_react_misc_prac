const dc = remote.require('./services/datacontext');

export class ProfilePropertyValueConverter {

    static inject() { return [dc]; }

    toView(value) {
        // we transform it directly when queried in the backend for now - kept for future use
        if (value.indexOf('{') !== -1) {

            return dc.profileDetails().then((p) => {

                let placeholders = dc.getPlaceholders(value);

                placeholders.forEach(property=>{

                    let val = p.rawValues[property];

                    // we could not find the value - generate something readable from it
                    if (!val){
                        value = value.replace("{" + property + "}","*" + i18n.t("fileshares.user_value") + ":" + dc.beautifyPlaceholder(property) + "*");
                    }
                    else{
                        value = value.replace("{" + property + "}", p.rawValues[property]);
                    }

                    

                    
                });

                return value;
            });
        }
        else {
            return value;
        }
    }
}