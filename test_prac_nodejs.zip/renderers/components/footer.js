var appVersion = require('electron').remote.app.getVersion();

export class FooterElement{
    
    constructor(){
        this.version = "v" + appVersion;
    }
}