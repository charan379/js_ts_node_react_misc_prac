const { Aurelia, Bindable } = au;

export class Mainnav{

    activate(){
        this.router = router;
    }

    navigateToRoute(route){
        this.router.navigateToRoute(route);
    }

    static get $resource() {
        return {
            bindables: ['router']
        };
    }
}