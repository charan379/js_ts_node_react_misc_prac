const { remote } = require('electron');
const i18n = remote.require('./services/translation');
import { ConfirmDialog } from '../dialogs/confirm.js';
import { PromptDialog } from '../dialogs/prompt.js';
import { FileshareDialog } from '../dialogs/fileshare-details.js';
const dc = remote.require('./services/datacontext');
const mappedDriveInfo = remote.getGlobal("mappedDriveInfo");

export class Fileshare {

    static get $resource() {
        return {
            bindables: ['share','loadFileshareDetails','mapFilesharePs','disconnectFilesharePs','loadFilesharePs','manageCredentialsPs']
        };
    }
    
    static inject() {
        return [au.dialog.DialogService]
    }

    constructor(dialog) {
        this.dialog = dialog;
        this.share = null;
        this.detailsLoaded = false;
        this.shareDetails = null;
    }

    bind (){
        this.detailsLoaded = false;
        this.hideManageCredentials = (this.manageCredentialsPs ? false : true);
        this.hideManageCredentials = (this.share.ShareType === 'SharePoint' ? true : this.hideManageCredentials);
        this.hideDetails = this.loadFileshareDetails? false : true;
        this.hideMap = this.mapFilesharePs ? false : true;
    }

    handleConnect(originalAddress){
        this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: i18n.t('fileshares.confirm_message', {title: this.share.Title}), 
                title: i18n.t('fileshares.confirm', {title: this.share.Title}) }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    this.loading = false;
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
    
                    this.mapFilesharePs({share:this.share}).then(()=>{
    
                        //for now we always write a row into the database
                        this.share.isMapped = true;
    
                        this.alert(
                            i18n.t("fileshares.success_message"),
                            i18n.t("fileshares.success_message_title")
                        );
    
                        this.loading = false;
    
                    }).catch((err)=>{
    
                        this.alert(
                            i18n.t("fileshares.error_message", {error: err}),
                            i18n.t("fileshares.error_message_title"),
                        );

                        // in case we got a connection error - reset to original value
                        if (originalAddress){
                            this.share.Address = originalAddress;
                        }
    
                        this.loading = false;
                    });
                }
                else{
                    this.loading = false;
                }
            });
    }

    openConnectDialog() {
        
        let originalAddress = this.share.Address;

        if (this.share.Address.indexOf("{") !== -1) {
            
            let placeholders = dc.getPlaceholders(this.share.Address);

            let fields = [];

            placeholders.forEach(placeholder =>{
                fields.push({title: dc.beautifyPlaceholder(placeholder), key: placeholder, value: ""});
            }); 

            this.dialog
                .open({
                    viewModel: PromptDialog,
                    model: {
                        message: i18n.t('fileshares.prompt_message', { title: this.share.Title }),
                        title: i18n.t('fileshares.prompt', { title: this.share.Title }),
                        fields: fields
                    }
                })
                .whenClosed(result => {
                    if (result.wasCancelled || !result.output) {
                        return;
                    }
                    // if answered yes, reload
                    if (result.output.yes) {
                        
                        result.output.fields.forEach(f=>{
                            this.share.Address = this.share.Address.replace("{" + f.key + "}", f.value);
                        });

                        this.handleConnect(originalAddress)
                    }
                    
                });
        }
        else{
            this.handleConnect();
        }
    }

    openDisconnectDialog(){
        this.dialog
        .open({
            viewModel: ConfirmDialog,
            model: { message: i18n.t('fileshares.confirm_message_disconnect', {title: this.share.Title}), 
            title: i18n.t('fileshares.confirm_disconnect', {title: this.share.Title}) }
        })
        .whenClosed(result => {
            if (result.wasCancelled || !result.output) {
                return;
            }
            // if answered yes, reload
            if (result.output.yes) {
                
                //for now we will remove the drive from the local database
                this.share.isMapped = false;

                if (this.share.ShareType === 'SharePoint'){
                    
                    this.alert(i18n.t("fileshares.confirm_spomapping_disconnect"), i18n.t("fileshares.confirm_spomapping_disconnect_title"));

                    mappedDriveInfo.remove(this.share.Title);
                }
                else{
                    this.disconnectFilesharePs({ share: this.share }).then((result)=>{
                    
                        this.alert(
                            i18n.t("fileshares.success_message_disconnect"),
                            i18n.t("fileshares.success_message_title_disconnect")
                        );
                        this.loading = false;
                        
    
                    }).catch((err)=>{
    
                        this.loading = false;
                        this.alert(
                            i18n.t("fileshares.error_message_disconnect", {error: err}),
                            i18n.t("fileshares.error_message_title_disconnect"),
                        );
                    });
                }
                
            }
        });
    }

    mapFileshare() {
        //change 05/2020 - we check if the drive is already mapped
        this.loadFilesharePs({ share: this.share }).then((result) => {

            let queryResult = JSON.parse(result);
            this.share.alreadyMappedInSystem = queryResult.exists

            if (!this.detailsLoaded) {
                this.loadFileshareDetails(this.share.id).then((fileshareIncludingDetails) => {
                    this.detailsLoaded = true;
                    this.share = fileshareIncludingDetails;
                    this.shareDetails = fileshareIncludingDetails;

                    if (mappedDriveInfo.get(this.share.Title)) {
                        this.share.isMapped = true;
                    }
                    else{
                        this.share.isMapped = false;
                    }

                    this.openConnectDialog();
                });
            } else {
                this.openConnectDialog();
            }
        });
    }

    disconnectFileshare(){
        this.loading = true;

        this.loadFilesharePs({ share: this.share }).then((result) => {
            
            let queryResult = JSON.parse(result);
            this.share.alreadyMappedInSystem = queryResult.exists

            if (!this.detailsLoaded) {
                this.loadFileshareDetails(this.share.Id).then((fileshareIncludingDetails) => {
                    this.detailsLoaded = true;
                    this.share = fileshareIncludingDetails;
                    this.shareDetails = fileshareIncludingDetails;
                    
                    if (mappedDriveInfo.get(this.share.Title)) {
                        this.share.isMapped = true;
                    }
                    else{
                        this.share.isMapped = false;
                    }
                    this.openDisconnectDialog();
                });
            } else {
                this.openDisconnectDialog();
                
            }

            this.loading = false;
        });
    }

    openDetailsDialog() {
        this.dialog.open({
            viewModel: FileshareDialog,
            model: this.share
        });
    }

    showDetails() {
        if (!this.detailsLoaded) {
            this.loading = true;
            
            return this.loadFileshareDetails(this.share.id).then((fileshareIncludingDetails) => {
                
                this.share = fileshareIncludingDetails;
                this.detailsLoaded = true;
                this.loading = false;

                this.loadFilesharePs({ share: this.share }).then((result) => {
                    let queryResult = JSON.parse(result);
                    this.share.alreadyMappedInSystem = queryResult.exists;
                    this.openDetailsDialog();
                });

            }).catch(e => {
                this.loading = false;
            });
        }
        else {
            this.openDetailsDialog()
        }
    }
   
    alert(message, title) {
        this.dialog
          .open({
            viewModel: './dialogs/message.js',
            model: {
              message: message,
              title: title
            }
          }).whenClosed(result => {
              this.loading = false;
          });
    }
}