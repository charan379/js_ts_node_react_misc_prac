const authProcess = remote.require('./main/auth-process');
const dc = remote.require('./services/datacontext');
const POWERSHELL = require('../services/powershell');
const i18n = remote.require('./services/translation');
const userConfig = remote.getGlobal("userConfig");
import { ConfirmDialog } from '../dialogs/confirm.js';
import { ProfileDialog } from '../dialogs/profile.js';

export class AppBar {

    static get $resource() {
        return {
            bindables: ['router']
        };
    }

    static inject() {
        return [au.dialog.DialogService]
    }

    constructor(dialog) {
        this.dialog = dialog;
        this.window = remote.getCurrentWindow();
        this.profile = {};
        this.profileDetails = {};
        this.image = "";
        this.shortname = "";

        this.hideRemoteSupport = false;
        //change 2021 - hide remote support on demand
        if (userConfig.get("hide_remotesupport")){
            this.hideRemoteSupport = userConfig.get("hide_remotesupport");
        }

        this.shiftDown = false;
        this.ctrlDown = false;
    }

    attached() {
        this.loadProfile();
        
        
        this.handleKeyDown = (event)=>{
            if(event.keyCode === 16 || event.charCode === 16){
                this.shiftDown = true;
            }

            if(event.keyCode === 17 || event.charCode === 17){
                this.ctrlDown = true;
            }
        };
        
        this.handleKeyUp = (event)=>{
            if(event.keyCode === 16 || event.charCode === 16){
                this.shiftDown = false;
            }

            if(event.keyCode === 17 || event.charCode === 17){
                this.ctrlDown = false;
            }
        };
        
        window.addEventListener ? document.addEventListener('keydown', this.handleKeyDown) : document.attachEvent('keydown', this.handleKeyDown);
        window.addEventListener ? document.addEventListener('keyup', this.handleKeyUp) : document.attachEvent('keyup', this.handleKeyUp);
    }

    openProfileDialog(){
        this.dialog
            .open({
                lock: false,
                viewModel: ProfileDialog,
                model: { profile: this.profileDetails, image: this.image, title: "Details" }
            });            
    }

    detached() {
        
    }

    loadProfile() {
        // this is really fast
        this.profile = dc.getProfile();

        // this might take some time
        dc.profileDetails().then(result => {
            // console.log("userprofile", result)
            this.profileDetails = result;
            this.shortname = this.shortname + " (" + this.profileDetails.usageLocation + ")";
        });

        // transform result
        if (this.profile)
            this.shortname = this.profile.name.replace(/^(.{15}[^\s]*).*/, "$1");

        dc.getProfileImage().then((result) => {
            this.image = result;
        })
        .catch(() => { //just hide the profile image if there is none
            document.getElementById('picture').style.display = "none";
        });
    }

    closeApp() {

        if(this.shiftDown && !this.ctrlDown){
            remote.app.exit(0);
            return;
        }
        else if (this.shiftDown && this.ctrlDown){
            remote.app.relaunch();
            remote.app.exit(0);
        }

        this.window.hide()
    }

    openSettingsDialog() {
        this.dialog
            .open({
                viewModel: './dialogs/settings.js'
            })
    }

    launchAppPS() {

        this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: i18n.t("appbar.launch-remote-assistance-confirm"), title: i18n.t("appbar.launch-remote-assistance-confirm-title") }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
                    //move to somewhere else
                    POWERSHELL.launchAppPS(userConfig.get("remotesupportapp"),"").then((result)=>{
                        if (result.success){
                            remote.getCurrentWindow().hide();
                        }else{
                            alert('Unexpected error: ' + result.message);
                        }
                        
                    }).catch((e)=>{
                        alert('Unexpected error:' + e.message);
                    });
                    
                }
            });
    }

    logout() {

        this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: i18n.t("appbar.logout-confirm"), title: i18n.t("appbar.logout") }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {
                    authProcess.createLogoutWindow().then(() => {
                        remote.getCurrentWindow().close();
                    });
                }
            });
    }
}