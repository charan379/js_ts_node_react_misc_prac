const { remote } = require('electron');
const i18n = remote.require('./services/translation');
import { ConfirmDialog } from '../dialogs/confirm.js';
import { PrinterDetailsDialog } from '../dialogs/printer-details.js';

export class Printer {

    static get $resource() {
        return {
            bindables: ['printer','loadPrinterDetails', 'addPrinterPs', 'drivers']
        };
    }
    
    static inject() {
        return [au.dialog.DialogService]
    }

    constructor(dialog) {
        this.dialog = dialog;
        this.printer = null;
        this.detailsLoaded = false;
        this.printerDetails = null;
    }

    bind (){
        this.detailsLoaded = false;
    }

    openConnectDialog() {
        this.dialog
            .open({
                viewModel: ConfirmDialog,
                model: { message: i18n.t('printers.confirm_message', {title: this.printer.Title}), 
                title: i18n.t('printers.confirm', {title: this.printer.Title}) }
            })
            .whenClosed(result => {
                if (result.wasCancelled || !result.output) {
                    return;
                }
                // if answered yes, reload
                if (result.output.yes) {

                    this.addPrinterPs({printer:this.printer}).then((res)=>{
                        let result = JSON.parse(res);
                        if (result.success){
                            this.alert(
                                i18n.t("printers.success_message"),
                                i18n.t("printers.success_message_title")
                            );
                        }
                        else{
                            this.alert(
                                i18n.t("printers.error_message", {error: result.message}),
                                i18n.t("printers.error_message_title")
                            );
                        }
                        
                    }).catch((err)=>{
                        this.alert(
                            i18n.t("printers.error_message", {error: err.message}),
                            i18n.t("printers.error_message_title")
                        );
                    });
                }
            })
    }

    addPrinter() {
        if (!this.detailsLoaded) {
            this.loadPrinterDetails(this.printer.Id).then((printerIncludingDetails) => {
                this.detailsLoaded = true;
                this.printer = printerIncludingDetails;
                this.printerDetails = printerIncludingDetails;
                this.openConnectDialog();
            });
        } else {
            this.openConnectDialog();
        }
    }

    openDetailsDialog() {
        this.dialog.open({
            viewModel: PrinterDetailsDialog,
            model: this.printer
        })
    }

    showDetails() {
        if (!this.detailsLoaded) {
            this.loading = true;
            return this.loadPrinterDetails(this.printer.Id).then((printerIncludingDetails) => {
                this.printer = printerIncludingDetails;
                this.detailsLoaded = true;
                this.loading = false;
                this.openDetailsDialog()
            }).catch(e => {
                this.loading = false;
            });
        }
        else {
            this.openDetailsDialog()
        }
    }
   
    alert(message, title) {
        this.dialog
          .open({
            viewModel: './dialogs/message.js',
            model: {
              message: message,
              title: title
            }
          });
    }
}