# System Requirements

Modified on: Wed, 25 Jan 2023 09:34

# TKE Service Tool - System Requirements

These are the minimum system requirements for using the TKE Service  Tool on your device. If your device or environment does not meet these  requirements, you may not be able to map printers and fileshares.



| **Enduser device** | Windows 10 H1/H2                                             |
| ------------------ | ------------------------------------------------------------ |
| **Backend**        | Sharepoint Online                                            |
| **Permissions**    | End user must have access to the configured item(s).         |
| **Credentials**    | The password must not contain one of these characters: quotation marks, blank spaces |
| **Printers**       | Printer must be supported by Windows Printer driver must be available on the device Connection to the network resource must be established at the time of mapping |
| **Fileshares**     | All Network connections that are supported by Windows 10 are supported A manual connection must be possible Connection to the network resource must be established at the time of mapping |
| **Languages**      | Supported Languages: German, English, Czech, Spanish, French, Hungarian, Italian, Dutch, Portuguese, Polish, Romanian, Russian, Turkish, Croatian |