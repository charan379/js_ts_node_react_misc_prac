## Remarks

The organizational configuration is stored in a SharePoint Online (SPO) list and enables the propagation of basic settings to the desktop application. Relevant list items are queried during the tool’s startup phase, if they are available. This mechanism allows administrators to apply baseline configurations to all members of a specified Entra Group.

## Visibility Remark

The visibility of list entries is governed by Entra Group membership. Users assigned to multiple groups may see all associated organizational units during the tool's selection (“popup”) phase, which may lead to confusion. To minimize ambiguity and improve user experience, it is recommended to maintain a 1:1 mapping between users and Entra Groups wherever possible.

## SPO Keys (JSON)

| Key                       | Value/Remarks                                                |
| ------------------------- | ------------------------------------------------------------ |
| windowBounds              | (Used internally)                                            |
| minimized                 | Start app minimized                                          |
| autostart                 | Start application after logon                                |
| language                  | Configured language (en/de etc.)                             |
| alwaysontop               | Show application always on top of other windows              |
| sendnotifications         | Enables desktop notifications for new announcements/news etc. |
| fileshareautomapping      | Adds or removes the Run-key (true\|false) - HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run |
| (location)                | (Currently not used) User defined location string for auto discovery |
| remotesupportapp          | e.g. "C:\\Users\\Public\\Desktop\\TKE QuickSupport.exe"      |
| hide_remotesupport        | true\|false                                                  |
| hide_modules              | Possible values: "news","sites","fileshares","printers","links" |
| modules_sortorder         | Possible values: "news","sites","fileshares","printers","links" |
| hideNotificationOnStartup | Enables/Disable Popups during ST startup (true\|false)       |
| maxPasswordAge            | Used for calculating change password reminder on startup for Domain Services (Default 90 days) |
| lastremoteupdate          | (Used internally)                                            |
| pwdreminderdate           | (Used internally)                                            |
| isDebug                   | (Used internally)                                            |

