# Service Tool Test Catalog

11.2021

[TOC]

Test Categories

## General Info/Testing Procedure

For testing the latest tool version is available via Intune (UAT group) and can also be downloaded and installed manually from the [Service Tool Testing site](https://tke.sharepoint.com/sites/tkeservice-test/) (for production and testing).

If a test user does not have the appropriate permission to access the tkeservice-test site please open a ticket at [cinc.tkelevator.com]().

For fast switching of configuration between Test and Prod it is possible to replace the *env-variables.json* file in the folder *C:\Program Files\Service Tool\resources*. Both files are available in their respective folders on the SPO site. Restart of the tool is required after swapping the files. 

Provided test cases are based on general tool functionality and based reported/fixed bugs during initial preview phase.

## General

| No   | Precondition         | Action                                                   | Expected Result                                              |
| ---- | -------------------- | -------------------------------------------------------- | ------------------------------------------------------------ |
| #1   |                      |                                                          | Automatic system locale detection during first startup. Tool will use the system locale if the language is available: EN,DE,CS,ES,FR,HR,HU,IT,NL,PL,PT,RO,RU,TR (fallback language: en) |
| #2   |                      | User clicks on the **Team Viewer icon** in the title bar | After confirmation Team Viewer Quick Connect starts up.      |
| #3   |                      | User clicks on the **Sign out** icon in the title bar.   | After confirmation the user is signed out of the account. Next time the tool is started the user needs to provide credentials in order to continue. *Remarks: This has no impact on previously selected resources (printers, network shares etc.)* |
| #4   |                      | User clicks on the **X** icon.                           | The app is getting minimized.                                |
| #5   |                      | User holds **Shift** and clicks on the **X** icon.       | The app is closed.                                           |
| #6   |                      | User clicks on **Gear** icon (settings dialog)           | The settings dialog is displayed to the user.                |
| #7   | Settings dialog open | User selects a different language and hits save.         | The application will show a warning that the application will need to be restarted. After restart the application opens in the previously selected language. |
| #8   | Settings dialog open |                                                          |                                                              |

## Printers

Navigate to **Printers** menu.

*Remarks: Visibility of printers is based on SPO permissions. For the "Nearby Printers" functionality to work the user needs to have Country (+ City) attribute provided in AAD .*

| No   | Precondition                                                 | Action                                                       | Expected Result                                              |
| ---- | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| #1   | -                                                            | Click **Open Printer and Devices dialog**                    | Windows Printers Dialog is displayed                         |
| #2   | -                                                            | Click **Credential Manager**                                 | Windows Credential Manager is displayed                      |
| #3   | No printer with found (no printer in the printers list matching the geo region/+city  of the currently signed in user) |                                                              | User should see a "No printer found" message. User can click on "Advanced Search" for manual search. |
| #4   | "Nearby Printers" found                                      | User can click on printer details to show details (info icon) . | A popup with printer details is displayed. Inside the dialog the user can see if the required printer driver is available. |
| #5   | (Network printer) User has access to resource. Assumption the printer requires Windows Credentials. | User clicks on **Connect** to connect to the printer.        | User needs to confirm the request. User will be asked to provide the required credentials (username/password). Printer will be installed and available to the user. |
| #6   | (Network printer) User has no access to the resource.        | User clicks on **Connect** to connect to the printer.        | User needs to confirm the request. User will be asked to provide the required credentials (username/password). User will be presented an error message stating that the resource could not be accessed due to a permission error. |
| #7   | (Network printer) User has access to the resource. Printer driver is not available. | User clicks on **Connect** to connect to the printer.        | Users needs to confirm the request. User enters credentials installation fails stating that the printer driver was not available on the system. |
| #8   | (Print server) User has access to the resource. Printer driver is not installed on client. | User clicks on **Connect** to connect to the printer.        | Users needs to confirm the request.  User will be asked to provide the required credentials (username/password). TBD: (Printer Nigthmare and ABR checks in progress - optimal case printer driver is downloaded and installed (ABR auto approval)) |
| #9   | User has access to printer list and printers are available in this list. | User clicks on **Advanced Search**                           | User is able to find printers by search term (including wildcard). |
| #10  | A printer has been previously installed.                     |                                                              | Printer will show a green check mark icon next to the printer name. |



## Network Shares

Navigate to **Network Shares** section.

| No   | Precondition                                                 | Action                                                       | Expected Result                                              |
| ---- | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| #1   |                                                              | User clicks on **Open Windows Credential Manager**.          | The Windows Credential Manager is displayed to the user.     |
| #2   | Assumes a promoted share is available to the user (Top=True selected in SPO) |                                                              | The tool shows a list of **Promoted** shares.                |
| #3   |                                                              | User clicks on the info icon (i)                             | A popup shows the details for the selected resource.         |
| #4   | It is assumed the user has access to the resource. User has not yet provided credentials for the resource. | User clicks on **Connect** of the requested share row.       | After confirming the request, the user needs to provide the required credentials (username/password). After a success message, the printer is available in Windows Explorer. |
| #5   | It is assumed the user has **no** access to the resource (network location not available or does have the required permission to access the resource) | User clicks on **Connect** for the resource.                 | After confirming the request, the user needs to provide the required credentials (username/password). The user is presented an error message (Access denied/Not available). |
| #6   | (Dynamic share) {Parameter}                                  | User clicks on **Connect** for the resource.                 | The user is presented a dialog for entering the required parameter. After entering the required parameter(s) the flow is similar to #4. |
| #7   | It is assumed at least one network share has been mapped successfully. (Settings: Map network shares during OS startup: Checked!) | User reboots system.                                         | After login the previously selected network shares will be mapped again. <br /><br />*Remarks: Due to some recent Windows changes it can take up to 2 minutes for the network shares to show up in the Explorer. However the drives should be available shortly after the login. "Save as" dialogs/Explorer address bar should be usable.* |
| #8   | It is assumed at least one network share has been mapped successfully. | User selects **Disconnect** for the item. User reboots system. | After confirmation the drive should no longer show up in Explorer. After reboot the drive should not be available. |
| #9   | It is assumed that the user has at least one network drive of type **Domain Services** mapped successfully. The user changes the password in AAD* | User starts the Service Tool                                 | The user will be presented a **Password reminder** dialog window. The user can jump directly to the network tab to change the password if required. |
| #10  |                                                              | User clicks on the **key** icon for a resource               | A popup is displayed to the user which gives the option to change the stored credentials for the connection. Additionally the dialog shows when the credentials were last updated. |
| #11  | It is assumed at least one network share has been mapped successfully. Settings dialog is open. | User clicks on **Forget all rembered drives** and reboots the machine. | After confirmation and reboot the previously selected network drives won't be mapped automatically. |

**During testing it may be easier to manually edit the reminder date directly in the user configuration. Settings "Open user-preferences.json" and change pwdreminderdate value as required.*

## Links/Tools

Navigate to **Tools** menu.

Remarks: Visibility is based on SPO permission for the respective item.

| No   | Precondition                                                 | Action                                                       | Expected Result                                              |
| ---- | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| #1   | It is assumed that at least one hyperlink is available.      | User expands section **Hyperlinks** and clicks on the hyperlink. | A new browser window (default browser) opens and shows the link target. |
| #2   | ""                                                           | User drag & drops hyperlink to desktop.                      | The user selects a hyperlink and drags the link to the desktop. A shortcut icon will be created. |
| #3   | It is assumed that at least one shortcut is available.       | User expands the section **Shortcuts** and clicks on the shortcut. | Assuming the target is available on the client the shortcut is executed. If the shortcut does not find a valid target an error message is displayed to the user. |
| #4   | ""                                                           | User drag & drops the shortcut to the desktop.               | A shortcut is created on the desktop. The icon is created based on the target application. |
| #5   | It is assumed that at least one remote desktop connection exists. | User expands section **Remote Desktops**                     | The Remote Desktop Connection window appears. Only RDP connections are supported! |
| #6   | ""                                                           | User drag & drops the rdp connection to the desktop.         | An RDP shortcut is created in the target folder.             |

## News

Navigate to **News** menu.

Remarks: Visibility is based on SPO permission for the respective page.

| No   | Precondition | Action                                   | Expected Result                              |
| ---- | ------------ | ---------------------------------------- | -------------------------------------------- |
| #1   |              | User clicks on article/news item.        | The page opens in the tkeservice site.       |
| #2   |              | User click on **View All Announcements** | The start page of the tkeservice site opens. |

