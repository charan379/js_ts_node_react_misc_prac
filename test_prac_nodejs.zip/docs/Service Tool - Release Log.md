## **TKE Service Tool - Version 23H2 (Build 0.9.130)**



### Fixed

- (Hotfix version) Fixed an issue after a password change to reconnect the drives. The issue was introduced in the latest build version 0.9.129 of ST. Using the "Update Credentials" functionality directly from ST may result in an incorrect  resource path being stored in the Windows Credential Manager along with  the updated credentials. This issue can lead to duplicate entries for a  single resource and therefore cause inconsistent results while  connecting to a network resource. The update will revert the change that causes this issue.

------



## TKE Service Tool - Version 22H1 (Build 0.9.128)

### Fixed

- Fixed an issue showing an incorrect error message when user enters wrong credentials during network drive mapping (mapdrive.ps1)
- Fixed output formating for error messages when showing non-ASCII characters (PS UTF-8 support)
- Issue reported by Miriam Behmenburg (forwarded from BU LA)
- Fixed a memory leak in PowerShell processing which could cause extensive memory usage
- Fixed issues with Hardware Acceleration to decrease overall CPU usage
- Fixed the application context menu to sometimes not using the correct language
- Fixed missing hyper links


### New

- Introduced a new Service Tool configuration default: "Map network shares during OS startup" to Enabled

------



## TKE Service Tool - Version 21H2 (Build 0.9.127)

### Updated

- Numerous bug fixes and performance upgrades (Upgrade to recent Electron version, Microsoft library updates)
- Several UI changes (e.g. direct access to credential manager)
- SMB drive mapping updates - drives.json (stores all user selected network shares which get remapped on startup)
- Backend/ConfigurationSPO Org settings settings updates
- Several SPO schema updates
- Improved Remote Support link handling

### Fixed

- Several bug fixes during mapping process
- Several translation errors fixed
- Windows Credential Manager does not start


### New

- Integration of the following languages in preview CS,ES,FR,HR,HU,IT,NL,PL,PT,RO,RU,TR (DE/EN is fully supported)
- Support for placeholders in network share UNC path (e.g. {{VarName}})
- Integration of password change reminder for Domain Services network shares
- Visual grouping for "Promoted", "Connected" drives including credential management per drive
- Support for Shortcuts and Remote Desktops