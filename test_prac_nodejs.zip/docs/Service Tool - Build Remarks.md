## Build version

Following tool versions were used to build the latest release version (0.9.130/23H2) of the tool (deployed via Intune).

## Linux (DEV)

Host: Fedora 38

nodejs - v21.6.1+
yarn - 1.22.19+

## WIN (PRIMARY)

Host: Windows 10

nodejs - 16.13.0+
yarn - 1.17.3+