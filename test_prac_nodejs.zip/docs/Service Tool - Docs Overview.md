# Docs Overview

This section provides a brief summary of the documents contained in the `doc` folder, based on the most recent software release (2023).

[TOC]

## Files and Folders

### **Service Tool – Technical Overview.md**

Provides a high-level architectural overview of the solution, including core components, data flow, and key security considerations.

### **Service Tool – System Requirements**

Outlines the minimum system requirements necessary to install and operate the application.

### **Service Tool – Release Log.md**

Lists all major changes and enhancements introduced in each version of the application.

### **Service Tool – Test Catalog.md**

Defines the core test cases used for integration testing and user acceptance testing (UAT).

### **Service Tool – OrgConfigKeys_SPO.md**

Details the configuration keys used to manage organizational settings via SharePoint Online (SPO), including notes on Entra Group-based list item assignment.

### **Service Tool – Build Remarks.md**

Specifies the required build environment and dependencies needed to generate a release version suitable for deployment via Microsoft Intune.

### **Archive Folder**

Contains early-stage project documentation, concepts, and legacy files originating from the project’s initial development phase (2019). These files are retained for informational purposes only and are not relevant to the current implementation.

### **Support Folder**

Includes exported PDF documents from the service desk, such as administrative guides and instructions for managing organizational settings in SharePoint Online.
