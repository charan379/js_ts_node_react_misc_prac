# Service Tool Process Updates

Date: 2021

[TOC]

## Network drive mapping process



```sequence
Service Tool->SPO: Query for user shares including metadata (same for search based access)
Service Tool->drives.json: Query for already mapped shares
User->Service Tool: Select drive for mapping

```





### Automatic mapping during Windows startup

The required mapping script will be registered if "Map network shares during OS startup" is selected in the Service Tool configuration.

#### Drives.json

The drives.json file is stored in the Appdata folder. The file contains all shares the user manually selected within the tool. The selected drives will be automatically mapped during Windows startup (if configured).

Format

| Field       | Example value                       |
| ----------- | ----------------------------------- |
| Address     | \\media\\datastore                  |
| DriveName   | resource                            |
| DriveLetter | s                                   |
| ShareType   | Legacy, Domain Services, SharePoint |

![image-20210727150540828](/home/dennis/.config/Typora/typora-user-images/image-20210727150540828.png)



```mermaid
graph LR
 A[Mapdrives.ps1]-- Query -->B[(drives.json)]
         B --> C{Exists?}
         C -->|yes| D[[Run mapping for each drive]]
         C -->|no| E[Exit]       
```

#### Script based mapping process (once per share)

```mermaid
graph LR
   0[(Read metadata)] -->a
   a{Is share accessible?} -- yes --> b{Creds stored*?} -- yes --> c["Map share"]
   c --> d{Success?} -- yes --- e
   d -- error --> f(End mapping process)
   a -- no --> e
   e[Exit/Next]
   b -- no --> g[Ask user for domain credentials] --> h[Store credentials] --> 0
   i[*Credentials are stored as generic credentials]
   style f fill:#f44336,stroke:#f44336,stroke-width:1px,color:#fff
```



## Automatic Mapping for SPO libraries (OneDrive Client) - NOT USED

**Remarks: This was never enabled for the desktop client nor used by any BU.**

Format

```powershell
odopen://sync/?siteId={SITEID}&amp;webId={WEBID}&amp;listId={LISTID}&amp;userEmail={EMAILADDRESS}&amp;webUrl=URL&amp;webTitle={NAME FOR FOLDER IN EXPLORER}&amp;listTitle={LIBRARY NAME}
```

Example

```powershell
odopen://sync/?siteId=%7B72ab09d8-21b4-4cac-a88e-6fa7fa86e333%7D&amp;webId=%7B83d55dc5-4e01-40e4-8e8e-960965d2aab1%7D&amp;listId=%7Ba91eecc2-0227-40f3-8aa4-12e65b4d61a8%7D&amp;userEmail=dennis%40binarysafari.de&amp;webUrl=https%3A%2F%2Fbinarysafari.sharepoint.com%2Fsites%2Ftkeci&amp;webTitle=ABCGiraffenAlarm&amp;listTitle=Documents
```

#### Subst Reference

```powershell
subst x: C:\users\username\tenantname\{SITETITLE} - {LIBRARY NAME}
```

Important Requirement 

&mailaddress=validmailaddress needs to be added&tenantName= the tenant name&webTitle=some title &listTitle=some title

## Run key

Script will be registered as Run script in HKCU.

```powershell
Computer\HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
```

Open and close 

```powershell
cmd /c start /min "" powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass "& ""C:\users\{path}\startup.ps1"""
```

Testsystem

*cmd /c start /min "" powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass "& ""C:\startuptest\automap-servicetool-drives.ps1"""*

## Script order

```mermaid
graph LR
   a[automap-servicetool-drives.ps1] -- for each drive -->b[smbdrivemapper.ps1]
```



## New configuration options

| Parameter          | Location              | Example                                                      |
| ------------------ | --------------------- | ------------------------------------------------------------ |
| hide_modules       | user-preferences.json | "hide_modules": ["news","printers"]                          |
| hide_remotesupport | user-preferences.json | "hide_remotesupport": true                                   |
| modules_sortorder  | user-preferences.json | "modules_sortorder":["printers","news"]                      |
| beta               | user-preferences.json | "beta":"true" (*during tests)                                |
| lastremoteupdate   | user-preferences.json | "lastremoteupdate": "2021-08-04T09:17:17Z" (will be set automatically) |

## Supported Module Names

- news
- printers
- fileshares
- sites
- links

## Search CHANGES RefinableString003

set to ShareType

## Printers Testing

\\\192.168.3.91\2012R2_C2665dnf_Color_MFP

