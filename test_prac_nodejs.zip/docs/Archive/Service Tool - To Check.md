## To Check



## Improvements and fixes for build #128

- Introduced a new Service Tool configuration default:  "Map network shares during OS startup" to **Enabled**
  - Issue reported by Ronald Geest
- Fixed an issue showing an incorrect error message when user enters wrong credentials during network drive mapping (mapdrive.ps1)
- Fixed output formating for error messages when showing non-ASCII characters (PS UTF-8 support)
  - Issue reported by Miriam Behmenburg (forwarded from BU LA)
- Fixed a memory leak in PowerShell processing which could cause extensive memory usage
- Fixed issues with Hardware Acceleration to decrease overall CPU usage
- Translations 
  - Fixed the application context menu to sometimes not using the correct language
  - Fixed missing hyper links



## Under investigation/Known issues

- Disconnecting a network drive within the Service Tool may sometimes fail
- Startup times may not be optimal if the path C:\Program Files\Service Tool\ is not excluded from Anti Malware/Defender scan (and AppData Roaming)
- On some systems/profiles network drives take longer to show up Windows Explorer (approx. 2 minutes)
- Printer search may return folder content type elements which can't be mapped and should not show up in search results.