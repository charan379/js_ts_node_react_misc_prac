2021

## Outstanding Technical Tasks and Notes

- **Drive Mapping Configuration Format**
  Implementation uses a JSON-based format. Current stability is estimated at approximately 70%.
- **Reminder Date Storage**
  Functionality to store a reminder date (e.g., for password renewal) should be implemented and compared against the timestamp of the last password change.
- **Password Change Scripts**
  Password change scripts need to be tested for functionality and reliability.
- **Stored Credentials Management**
  Extend the existing list functionality to include management of stored credentials. Current progress is estimated at 60%.
- **Tab Management**
  Implement or improve the tab management functionality within the application UI.
- **Advanced Search Visibility**
  The Advanced Search option does not appear when no printers are discovered. This behavior should be reviewed and improved for better user guidance.

### Example: User Connection Configuration

```
"userconnection": {
    "servicesite": "https://tketest.sharepoint.com/sites/tkeService-butest",
    "servicesite_id": "{e42f7754-e05a-4a3c-9d0b-eff737b06e77}",
    "siteslist_id": "Sites",
    "printerslist_id": "Printers",
    "announcement_list_id": "Site Pages",
    "filesharelist_id": "Fileshares"
}
```

This configuration defines the connection parameters to SharePoint Online lists used by the tool for services, printers, announcements, and file shares.