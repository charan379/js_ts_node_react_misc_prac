# tke Service Tool (Windows 10)

**Features**

- Printer Discovery
  - Authenticated Printer discovery (backed by SharePoint Online permissions and groups)
  - Add or remove printers (in user context)
- File Share Discovery
  - List all published FileShares (backed by SharePoint Online)
  - Select and Mount 
- TeamViewer Quick Support Integration
  - Launch Quick Support directly from Tool
- Push Links from SharePoint Online
- Run directly from Windows System Tray
- SSO - for Azure joined devices
- Packaged for use within Intune
- Start with parameters from command line



![1569228830676](./1569228830676.png)