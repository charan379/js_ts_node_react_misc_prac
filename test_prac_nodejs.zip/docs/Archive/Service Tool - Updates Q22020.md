# Service Tool - Required Updates Q2/2021

[TOC]

## Planned Improvements

### SmbMapper

Script improvement planned. Script will remove the network drive prior to mapping. Mapping popup message needs to be update ("...clicking will remove and reconnect the drive")

## Improved mapping experience

#### Initial situation/problem statement 

Stored credentials in the Windows Credential Manager cannot be updated automatically by Windows when they expire. In order to prevent the user logout due to failed sign ins a mechanism is required to prevent the account logout (or at least increase the chance to prevent that outcome). Additionally the OOTB end-user experience for changing stored credentials is probably not good enough for a standard user, considering the user does not know that their credentials are stored anywhere at all (or how to change them).

### Approach

Make the user aware that they need to update their **stored** credentials if the update their domain sign in info (Azure or legacy AD resources). Additionally it is required to provide a way to easily change these credentials. 

In order to prevent the account logout during Windows login the drive mapping should not be done "persisted". If a file mapping is already in place and not working correctly, users will click on the drives repeatedly and therefore increase the failed login count even further. 

Hence the Service Tool should map the drives during startup, while checking if the user has changed the credentials recently. If that is the case the user gets displayed an additional info message telling them, that they probably need to update their stored credentials.



### Overview

*Rough brainstorming version!*

#### "Day 1"- experience

```sequence
Service Tool->AAD:Sign in (simplified)
AAD-> Service Tool: Return profile info (Store Refresh Token etc.)
Service Tool-> SPO(Graph): Query for automap fileshares
SPO(Graph)->Service Tool: Return a list of automap fileshares (needs change in SPO top != automap)
Service Tool->Mapping Dialog: "---Your organization wants you to use these x number of drives which require your Windows domain credentials---" (One challenge per location?)
Mapping Dialog->Service Tool: Save credentials and save the notification date (the day the credentials where updated by the tool)
Mapping Dialog->Service Tool: ---Click complete--- Drives will be mapped (non persistent) - User can start working
```

**The whole step "save the notification date" might not be necessary. We don't have much meta data for stored credentials but we should be able to access the last update date on these elements - therefore we could use this date for comparison.**

#### "Day 2+n"- experience (no file shares were mapped before)

*Only shows "best case"*

```sequence
Service Tool->AAD:Sign in SSO
AAD-> Service Tool: Update Refresh Token
Service Tool-> SPO(Graph): Query for fileshares the user wants/is required to mount (Issue 1 - How do we know which drives the user wants and needs to map?)
SPO(Graph)->Service Tool: Return a list of fileshares
Service Tool->Service Tool:Check if last pwd change date is newer than the last stored date (if possible query Credential Manager for that info)
Service Tool->Service Tool:If last pwd change date > Show dialog (***Otherwise simply map them - no dialog shown - best case)
Service Tool->Notification Dialog: "'You recently changed your password. You have stored credentials for the following locations - would you like to update the password?''"
Notification Dialog->Service Tool: Save last notification date. Open Windows Credential Manager* (or custom UI for managing the connections)
Notification Dialog->Service Tool: "'Click complete'" - Drives will get mapped (non persistent)
```

### Pitfalls

- The tool currently does not know which drives a user likes to map (this info is currently not stored nor tracked)
  - Likewise - if the user has several stored credentials we currently don't know if these were manually added or by the tool - there is no metadata assigned to these.
- In case of HS this can work, because they already are using Azure Domain Services (Pwd hash sync). In case of other BUs still using their legacy AD environments this won't work and even worse could confuse users because they may changed their AAD password (what we can figure out) but they did **not** change their local AD credentials (or can't change those credentials at all - which is what will happen...). Technically we can't figure that out - therefore we need to make it somewhat configurable.
  - Because of that we somehow need to configure this per BU or file share (in SPO?)
- If the user disables the Autostart for the Service Tool - they won't have their drives ready. Still not sure if the non persistent route is a good way to go about this.
- If the Service Tool does not work properly (for whatever reason - Bug, Windows Update, deployment issue etc.) impact is huge



## Known Issues

| No   | Area    | Description                                                  | Estimated fix |
| ---- | ------- | ------------------------------------------------------------ | ------------- |
| 1    | General | After an extended period of time (30-60 minutes?) of inactivity the application fails to connect to M365 resources and crashes (is not usable anymore).<br /><br />Possible cause: The access token is expired and automatic refresh seems to fail. Needs more investigation. | KW21          |
|      |         |                                                              |               |
|      |         |                                                              |               |

## Scrapbook

```powershell
LastPasswordChangeTimeStamp each time user logs in check if password change
LastTimeStoredCredentialsRefresh 
if (LastPasswordChangeTimeStamp > LastTimeStoredCredentialsRefresh){
 	Ask user to refresh stored credentials	
}

Do something to reduce the posiblities for account logout

rundll32.exe keymgr.dll, KRShowKeyMgr

cmdkey /list

runas /u:yourdomain\a_test_user notepad.exe


#usage: Test-UserCredential -username UserNameToTest -password (Read-Host)

Function Test-UserCredential { 
    Param($username, $password) 
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement 
    $ct = [System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:computername 
    $opt = [System.DirectoryServices.AccountManagement.ContextOptions]::SimpleBind 
    $pc = New-Object System.DirectoryServices.AccountManagement.PrincipalContext -ArgumentList $ct 
    $Result = $pc.ValidateCredentials($username, $password).ToString() 
    $Result 
}

$PlainPassword="your_password"
$SecurePassword = $PlainPassword | ConvertTo-SecureString -AsPlainText-Force
$UserName = "your_username"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $UserName,$SecurePassword
Start-Process whoami -Credential $Credentials
```

