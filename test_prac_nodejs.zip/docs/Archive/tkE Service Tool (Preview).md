# tkE Service Tool (Preview) - Technical Overview

*December 2019 /Document status: Draft/ Created by: Dennis Battenfeld (CONGUIDE GmbH)*

The tkE Service Tool is a desktop application for propagation of support/service related news, discovery of network printers, network shares and service tools (e.g. ticket tools, remote support) for Windows 10.

The basic idea behind the tool is to provide a central application to the users which makes discovering and accessing service/support related information, printers, file shares and tools as easy as possible while maintaining the ability to target information to a certain group of users (by OU/region/site).

*The application is currently under development. All presented information in this document is based on the current status of the software (12/2019) and may be subject to change in future versions.*

[TOC]

## Overview

The tkE Service Tool is a cross platform desktop application based on Electron (https://electronjs.org/) with SSO** support. 

**The user has to sign in once after installation. If the user starts the application within 90 days the app updates the stored refresh token and the user is automatically signed in, otherwise the user has to sign in again*.

**Microsoft currently does not support SSO in a non hybrid AD/AAD enviroment for custom applications.*

Based on the currently signed in user the applications queries data from SharePoint Online (news, printers, network shares, links) and Microsoft Graph (user profile information). The application launches on system startup (default) and can be started from a Windows tray item.

![image-20191216103141850](./image-20191216103141850.png)

![image-20191216102151810](./image-20191216102151810.png)

## Registration, Authentication and Data Access

The application needs to be registered as **Native Application** in the Azure Portal. Scope-wise the application uses the following **delegated** permissions:

| Scope                         | Remarks                                                      |
| ----------------------------- | ------------------------------------------------------------ |
| offline_access (MS Graph)     | Needed for storing the refresh token                         |
| openid (MS Graph)             | Used for authentication                                      |
| profile (MS Graph)            | Contact information and profile image                        |
| Sites.Read.All (MS Graph)     | Used to access certain information from service sitecollection |
| User.Read (MS Graph)          | Basic user info                                              |
| Sites.Search.All (Sharepoint) | Used for search based discovery of printers/fileshares       |

The application does **not** write any data to SharePoint Online and is **not** able update any user information in AAD.

The application uses the **Authorization Code Grant Flow** (https://docs.microsoft.com/de-de/azure/active-directory/develop/v1-protocols-oauth-code). The following sequence shows a common sequence during  *first startup*.

```sequence
Client->AAD App:Sign into app (User Authorization Request)
Client->AAD App:Authorization (Step is not needed if admin consent is given /default)
AAD App->Client: Authorization Code Grant
Client->AAD App: Access Token Request via Code (MS Graph)
AAD App->Client: Access Token Grant (Access Token for MSGraph + Refresh Token)
Client->Window Credential Store: Storing Refresh Token
Client-> AAD App: Access Token Request for SPO
AAD App->Client: Access Token Grant (Access Token for MSOnline) 
```

After initial startup the sequence looks like the following (if all tokens are valid):

```sequence
Client->Windows Credential Store: (Query for Refresh Token*)
Client->AAD App: Use stored refresh token to aquire access tokens (expiry after 60 minutes)
AAD App->Client: Provide new Access Token and new Refresh Token
Client->Windows Credential Store: Update refresh token
Client->AAD App: Request new access token for MSO
AAD App->Client: All access token are refreshed - user can use the app
```

On every launch (from Tray or hard reload) the application tries to update all required tokens automatically. If that process fails (infrastructure issue/connectivity problems etc.) the user might need to sign in again. 

### Security

The application works in the security context of a **standard user**. The application uses a provided set of PowerShell-Scripts for adding printers, mapping file shares and launching windows tools or settings. The app purposely does **not** use any local web server (no open ports etc.). The provided scripts are stored under "C:\Program Files" and therefore the user should not be able to modify those files. The application does not run any external websites in "IFrames" data is only downloaded from SPO/MSGraph via API calls.

The refresh token is stored securely within the **Windows Credential Store**.

## Tool Configuration

The application uses two separate configuration files. The environment configuration is provided within the provided MSI package and contains the following information:

| Key                  | Value/Remarks                                                |
| -------------------- | ------------------------------------------------------------ |
| authorityurl         | https://login.microsoftonline.com/                           |
| tenantid             | GUID/ID of the tenant                                        |
| clientId             | GUID of the registered application                           |
| redirectUri          | https://login.microsoftonline.com/common/oauth2/nativeclient |
| tenantspo            | https://xyz.sharepoint.com/ Absolute Url /Tenant             |
| servicesite          | https://xyz.sharepoint.com/sites/xyz /Absolute Url to the service sitecollection |
| servicesite_id       | {GUID}/WebID of the service sitecollection                   |
| printerslist_id      | {GUID}/ID of the printer list in SPO                         |
| announcement_list_id | {GUID}/ID of the pages/news list in SPO                      |
| fileshare_list_id    | {GUID}/ID of the network share list in SPO                   |
| languages            | List of supported languages (code/title)                     |
| fallbackLng          | Default language                                             |
| activitychecktimeout | 900 / Time to query for new information on SPO site. Minds the notification setting in user settings. |

The second configuration (user configuration) is created during first run of the application and stored per user (e.g. AppSettings/Roaming/ServiceTool/user-preferences.json) and contains the following settings:

| Key               | Value/Remarks                                                |
| ----------------- | ------------------------------------------------------------ |
| windowBounds      | Only used internally                                         |
| minimized         | Start app minimized                                          |
| autostart         | Start application after logon                                |
| language          | Configured language                                          |
| alwaysontop       | Show application always on top of other windows              |
| sendnotifications | Enables desktop notifications for new announcements/news etc. |
| (location)        | (Currently not used) User defined location string for auto discovery |

The user can configure those settings directly within the software.

![image-20191216101349322](./image-20191216101349322.png)

## SharePoint Online Overview

All required data for the desktop application is served from a SharePoint Online SiteCollection (Template Communication Site or TeamSite) via MSGraph or SPO APIs. There are no special requirements for the service site. 

### Required Lists

*Remarks: The schema is not final. For installation on the production tenant list templates will be provided.*

**Pages (uses default library and standard News Post functionalty)**

Changed from default:

A new Field NewsType (Choice) was added to give the author the ability to color code the news item within the tool (e.g. primary, secondary, success, danger, warning, info, light, dark). This field is optional.

*Remarks: The default Description field is used within the tool to render a summary line underneath the title of each news item. This should be provided by the author of the item.*

**Printers**

| Field                        | Remarks                                                      |
| ---------------------------- | ------------------------------------------------------------ |
| Location (Location Column)   | Can be used with fulltext search but there is no way to access this information in search results. This is subject to change. |
| Network Address              | DNS/IP Network Location - Path to printer                    |
| Printer Location             | Physical location of the printer (should be a user identifiable string e.g. Country, Region, Site, Building, Floor etc.) |
| Printer Name                 | Name of the printer                                          |
| Printer Type                 | Type of printer (used in search e.g. Floor Printer or Epson XYZ) |
| Remarks                      | (Multiple Lines of Text)                                     |
| Ask for Credentials (Yes/No) | (Under testing) The user needs to provide Windows Credentials in a popup before the printer is mounted. The provided information is stored in the Windows Credential Store. |
| Supported Driver             | Name of the required printer driver. When launching the printer details dialog all installed printers and drivers of the current user are evaluated. If the required printer driver is not found, the user is presented with a warning. (Under testing) |

**Fileshares**

| Field               | Remarks                                                      |
| ------------------- | ------------------------------------------------------------ |
| Name                | "Personal Store", "Production site ABX"                      |
| Address             | Network location of the fileshare.                           |
| Ask for Credentials | If needed the user can store Windows Domain Credentials into the windows credential store prior to the mapping process. |
| DriveName           | Name of the drive                                            |
| Remarks             |                                                              |

**Links**

| Field | Remarks                                                      |
| ----- | ------------------------------------------------------------ |
| URL   | All links will be opened in the default user browser on click. |
| Notes | Short description                                            |

**Sites (in Development)**

| Field | Remarks                                                      |
| ----- | ------------------------------------------------------------ |
| URL   | All links will be opened in the default user browser on click. |
| Description | Short description                                            |

### Search and Search Configuration

Automatic discovery of printers is based on usage location and profile contact information of the current user. In order to search for specific information the following properties need to be specified as *Managed Properties*.

| Property                    | Mapped To                                            |
| --------------------------- | ---------------------------------------------------- |
| RefinableString00 (default) | ows_Location, ows_PrinterLocation (Under evaluation) |
| RefinableString01 (default) | ows_Remarks                                          |
| RefinableString02 (default) | ows_Address,ows_NetworkAddress                       |
| PrinterLocation             | ows_PrinterLocation (Multi, Query, Search, Retrieve) |
| PrinterType                 | ows_PrinterType (Query, Search, Retrieve)            |

### Permissions

The site needs to be accessible for all users in the tenant in a read only role (AAD Default Group: Everyone except external users). For administration the user needs to have write permissions on all required lists. 

*Remarks: For security trimming of e.g. printers (per region or OU), the administrator can use folders and unique permissions on those folders (AAD groups should be used for unique permissions).*

## Installation/Upgrade

The application including the required environment configuration* is provided via MSI package. The app is installed for all users by default (including Shortcut on Desktop).

Default Installation Path: **C:\Program Files\Service App**

**SharePoint Site including all required lists and configuration needs to be in place in order to provide the configuration*

Upgraded packages will be deployed through Intune. The MSI installer handles all required upgrade steps.

### Intune Deployment

No special requirements. App Icon is provided.

tbd - Assignments - The app is installed by assignments and not through *Company Portal*

