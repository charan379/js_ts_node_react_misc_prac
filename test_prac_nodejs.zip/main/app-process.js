const { BrowserWindow, protocol, shell } = require('electron');
const path = require('path');

function createAppWindow(callback, minimized) {

  // let scaleFactor = require('electron').screen.getPrimaryDisplay().scaleFactor;

  let win = new BrowserWindow({
    width: 600,
    height: 1000,
    backgroundColor: '#FFF',
    frame: false,
    autoHideMenuBar: true,
    allowpopups: true,
    resizable: false,
    // zoomFactor: scaleFactor !== 1 ? parseFloat (scaleFactor) : parseFloat (1),
    /* this is nice - in case of an js error this is not working that great - therefore turned off for now  */
    alwaysOnTop: global.userConfig.get("alwaysontop") 
      ? global.userConfig.get("alwaysontop") : false, 
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.normalize(`${__dirname}`) + '/appicon/png/48x48.png',
    show: false //default hide
  });

  // hack for using real links in translations and UI
  const PROTOCOL_PREFIX_AU = 'au';
  const PROTOCOL_PREFIX_EX = 'ex';

  // redirects link to aurelia router
  protocol.registerHttpProtocol(PROTOCOL_PREFIX_AU, (req, cb) => {
    let parsed = req.url.replace("au://", ""); //remove protocol part
    win.webContents.send('route', parsed);
  });

  // opens the link in default browser
  protocol.registerHttpProtocol(PROTOCOL_PREFIX_EX, (req, cb) => {
    let parsed = req.url.replace("ex://", ""); //remove protocol part
    shell.openExternal(parsed);
  });

  win.once('ready-to-show', () => {
    if (callback)
      callback(win);
    !minimized && win.show();    
  });

  win.loadFile('./renderers/home.html');

  win.on('closed', () => {
    win = null;
  });

  return win;
}

module.exports = createAppWindow;