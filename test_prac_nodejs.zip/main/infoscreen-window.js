const { BrowserWindow, protocol, shell } = require('electron');
const path = require('path');

function createInfoScreenWindow(callback, minimized, module, additionalData) {
  //requested info module e.g. pwdChangeNotification
  let opts = {
    width: 800,
    height: 430,
    backgroundColor: '#FFF',
    frame: false,
    autoHideMenuBar: true,
    allowpopups: true,
    resizable: false,
    /* this is nice - in case of an js error this is not working that great - therefore turned off for now  */
    alwaysOnTop: global.userConfig.get("alwaysontop")
      ? global.userConfig.get("alwaysontop") : false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.normalize(`${__dirname}`) + '/appicon/png/48x48.png',
    show: true //default hide
  };

  let win = new BrowserWindow(opts);

  // offset in case of multiple windows
  const pos = win.getPosition();
  let newX = pos[0] + Math.floor(Math.random() * 50) + 1;
  win.setPosition(newX, pos[1])

  win.once('ready-to-show', () => {
    if (callback) {
      // require('remote').getCurrentWindow().toggleDevTools();
      callback(win, {status:"open"});
    }

    !minimized && win.show();
  });

  data = { "module": module }

  if (additionalData) {
    data.additionalData = additionalData;
  }

  win.loadFile('./renderers/apps/info/infoscreen.html', { query: { "data": JSON.stringify(data) } });

  win.on('closed', () => {
    win = null;

    if (callback) {
      callback(null, {status:"closed"});
    }
  });

  return win;
}

module.exports = createInfoScreenWindow;