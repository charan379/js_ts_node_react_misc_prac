const { Tray, Menu, ipcMain, nativeImage } = require('electron');
const i18n = require('../services/translation');

class ApplicationTray {
	constructor(window, appMenu, iconPath) {
		this.window = window;
		this.iconPath = iconPath;
		this.appMenu = appMenu;
		this.addTray();
	}

	addTray() {
		this.tray = new Tray(this.iconPath);
		this.tray.setToolTip(i18n.t('tray.tooltip'));
		this.tray.on('click', () => this.showAndFocusWindow());
		this.tray.setContextMenu(Menu.buildFromTemplate(this.appMenu.filter(m=>!m.hidden)));
		ipcMain.on('tray-update', (event, {icon, flash}) => this.updateTrayImage(icon, flash));
	}

	showAndFocusWindow() {
		this.window.show();
		this.window.focus();
	}

	updateTrayImage(iconUrl, flash) {
		const image = nativeImage.createFromDataURL(iconUrl);
		this.tray.setImage(image);
		this.window.flashFrame(flash);
	}
}

exports = module.exports = ApplicationTray;