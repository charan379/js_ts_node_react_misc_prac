const path = require('path');
const { app } = require('electron');
const i18n = require('../services/translation');

const POWERSHELL = require('../services/powershell');

class TrayMenu {

    constructor(window) {
        this.window = window;

        let hidden_modules = global.userConfig.get("hide_modules");
        let hide_remotesupport = global.userConfig.get("hide_remotesupport");
        
       

        this.submenu = [
            
            {
                label: i18n.t("tray.remotesupport"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.startRemoteSupport(),
                hidden: hide_remotesupport ? hide_remotesupport : false
            },            
            {
                label: i18n.t("tray.announcements"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open("news"),
                hidden: hidden_modules && hidden_modules.indexOf("news") !== -1
            },
            {
                label: i18n.t("tray.printers"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open("printers"),
                hidden: hidden_modules && hidden_modules.indexOf("printers") !== -1
            },
            {
                label: i18n.t("tray.networkshares"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open("fileshares"),
                hidden: hidden_modules && hidden_modules.indexOf("fileshares") !== -1
            },
            {
                label: i18n.t("tray.sites"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open("sites"),
                hidden: hidden_modules && hidden_modules.indexOf("sites") !== -1
            },
            {
                label: i18n.t("tray.links"),
                // icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open("links"),
                hidden: hidden_modules && hidden_modules.indexOf("links") !== -1
            },
            {
                type: 'separator',
                hidden: global.mappedDriveInfo && global.mappedDriveInfo.count() > 0 ? false : true
            },
            {
                //Hotfix for manual reconnection
               label: i18n.t("settings.advanced-settings-mapdrives"),
               click: () => this.mapAllDrives(),
               hidden: global.mappedDriveInfo && global.mappedDriveInfo.count() > 0 ? false : true
           },
            {
                type: 'separator'
            },
            {
                label: i18n.t("tray.open"),
                // accelerator: 'ctrl+O',
                icon: path.normalize(`${__dirname}`) + '/appicon/png/16x16.png',
                click: () => this.open(),
            },
            {
                label: i18n.t("tray.refresh"),
                // accelerator: 'ctrl+R',
                click: () => this.reload(),
            },
            {
                label: i18n.t("tray.hide"),
                // accelerator: 'ctrl+H',
                click: () => this.hide(),
            },

            { type: 'separator' },
            {
                label: i18n.t("tray.quit"),
                // accelerator: 'ctrl+Q',
                click: () => this.quit(),
            },
            { type: 'separator' },
           
        ];

        if (global.userConfig.get('isDebug') && global.userConfig.get('isDebug').toLowerCase() === 'true'){
            this.submenu.push( {
                label: i18n.t("tray.debug"),
                click: () => this.debug()
            });
        }
    }

    debug() {
        this.window.openDevTools();
    }

    reload() {
        this.window.show();
        this.window.reload();
    }

    quit() {
        app.quit();
    }

    mapAllDrives(){
        POWERSHELL.mapAllDrives().then(res=>{
        });
        // let confirmMessage = i18n.t("settings.advanced-settings-mapdrives-confirm");
        // let title = i18n.t("settings.advanced-settings-mapdrives");
    
        // this.dialog
        //         .open({
        //             viewModel: ConfirmDialog,
        //             model: { message: confirmMessage, title: title }
        //         })
        //         .whenClosed(result => {
        //             if (result.wasCancelled || !result.output) {
        //                 return;
        //             }
        //             // if answered yes, reload
        //             if (result.output.yes) {
                      
        //             }
        //         });
      }

    startRemoteSupport(){
        POWERSHELL.launchAppPS(global.userConfig.get("remotesupportapp"), "");
    }

    open(route) {

        if (route) {
            this.window.webContents.send('route', route);
        }

        if (!this.window.isVisible()) {
            this.window.show();
        }

        this.window.focus();
    }

    hide() {
        this.window.hide();
    }
}

module.exports = TrayMenu;