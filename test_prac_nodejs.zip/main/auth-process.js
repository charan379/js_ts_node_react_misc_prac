const { BrowserWindow, Menu } = require('electron');
const authService = require('../services/authentication');
const createAppWindow = require('../main/app-process');
const path = require('path');

const process = require('process');
const isDevelopment = process.env.NODE_ENV === 'development';

const rootPath = isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.resourcesPath);
const envVariables = require(path.join(rootPath, './env-variables'));

const { redirectUri } = envVariables;
let win = null;

function createAuthWindow(callback) {

  destroyAuthWin();
  Menu.setApplicationMenu(null);

  // Create the browser window.
  win = new BrowserWindow({
    width: 800,
    height: 600,
    frame: true,
    title: "Service Tool",
    icon: path.normalize(`${__dirname}`) + '/appicon/png/48x48.png'
  });

  win.on('page-title-updated', function(e) {
    e.preventDefault()
  });

  win.loadURL(authService.getAuthenticationURL());

  const { session: { webRequest } } = win.webContents;

  const filter = {
    urls: [
      'file:///callback*',
      redirectUri
    ]
  };

  webRequest.onBeforeRequest(filter, async ({ url }) => {
    await authService.loadTokens(url);
    createAppWindow(callback);
    return destroyAuthWin();
  });

  win.on('authenticated', () => {
    destroyAuthWin();
  });

  win.on('closed', () => {
    win = null;
  });
}

function destroyAuthWin() {
  if (!win) return;
  win.close();
  win = null;
}

function createLogoutWindow() {
  return new Promise(resolve => {
    const logoutWindow = new BrowserWindow({
      show: false
    });

    logoutWindow.loadURL(authService.getLogOutUrl());

    logoutWindow.on('ready-to-show', async () => {
      logoutWindow.close();
      await authService.logout();
      resolve();
    });
  });
}

module.exports = {
  createAuthWindow,
  createLogoutWindow,
};