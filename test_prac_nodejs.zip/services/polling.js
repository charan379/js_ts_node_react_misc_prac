const EventEmitter = require('events');

class Poller extends EventEmitter {
    /**
     * @param {int} timeout in seconds how long should we wait after the poll started?
     */
    constructor(timeout = 100) {
        super();
        this.pollTimer = null;
        this.timeout = timeout * 1000;
    }

    poll() {
        this.pollTimer = setTimeout(() => this.emit('poll'), this.timeout);
    }

    onPoll(cb) {
        this.on('poll', cb);
    }

    stop(){
        clearTimeout(this.pollTimer);
    }
}

module.exports = Poller;