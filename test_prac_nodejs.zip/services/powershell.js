const PowerShell = require('node-powershell');
const process = require('process');
const isDevelopment = process.env.NODE_ENV === 'development';

function addPrinter(printer) {

    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        // ps.addCommand(path.join(rootPath, '/psscripts/add-printer.ps1')).then(()=>{
        ps.addCommand(isDevelopment ? './psscripts/add-printer.ps1' : './resources/psscripts/add-printer.ps1').then(() => {
            ps.addParameters([{
                name: "Printername",
                value: printer.Title
            },
            {
                name: "NeedsCredentials",
                value: printer.CredentialsRequired
            },            
            {
                name: "PrinterHostAddress",
                value: printer.NetworkAddress
            }])

            if (printer.SupportedDriver)
            {
                ps.addParameters([{
                    name: "PrinterDriverName",
                    value: printer.SupportedDriver
                }]);
            }

            ps.invoke()
                .then(output => {
                    console.log("OUTPUT", output);
                    resolve(output);
                })
                .catch(err => {
                    console.log(err);
                    reject(err);
                }).finally(() => {
                    ps.dispose();
                });
        });
    });

    return promise;
}

function disconnectDrive(share){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [{
            name: "sourcePath",
            value: share.Address
        }];

        parameters.push({
            name: "removeOnly",
            value: true
        });

        ps.addCommand(isDevelopment ? './psscripts/mapdrive.ps1' : './resources/psscripts/mapdrive.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                console.log(output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

function mapSPODrive(share){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        /*
            $metadata,    
            $mailaddress,
            $explorerWebTitle, # for Explorer
            $explorerListTitle, # for Explorer,
            $mapAsDrive = $false,
            $driveLetter,
            $driveName,
            $tenantName,
            $mapOnly = $false
        */

        let parameters = [{
            name: "driveLetter",
            value: share.DriveLetter
        },
        {
            name: "driveName",
            value: share.DriveName ? share.DriveName : share.Title // hack - at least get something to work with
        },       
        {
            name: "metadata",
            value: "\""+ share.Address + "\""
        }        
        ];

        parameters = parameters.filter(p=>{
            return p.value != null;
        });

        ps.addCommand(isDevelopment ? './psscripts/add-spodrive.ps1' : './resources/psscripts/add-spodrive.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                console.log("OUTPUT", output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function mapDrive(share){

    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [{
            name: "driveLetter",
            value: share.DriveLetter
        },
        {
            name: "driveName",
            value: share.DriveName ? share.DriveName : null
        },
        {
            name: "authRequired",
            value: share.CredentialsRequired
        },
        // {
        //     name: "serverResource",
        //     value: share.Address
        // },
        {
            name: "sourcePath",
            value: share.Address
        }        
        ];

        parameters = parameters.filter(p=>{
            return p.value != null;
        });

        // this is not used in this version
        if (share.remap){
            parameters.push({
                name: "remap",
                value: true
            });
        }

        ps.addCommand(isDevelopment ? './psscripts/mapdrive.ps1' : './resources/psscripts/mapdrive.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                console.log("OUTPUT", output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function mapAllDrives() {
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        ps.addCommand(isDevelopment ? './psscripts/start-autodrivemapper.ps1' : './resources/psscripts/start-autodrivemapper.ps1');

        ps.invoke()
            .then(output => {
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
    });

    return promise;
}

function getCredentialManagerInfo(serverResource){

    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [{
            name: "serverResource",
            value: serverResource
        }]

        ps.addCommand(isDevelopment ? './psscripts/get-credentialmanagerinfo.ps1' : './resources/psscripts/get-credentialmanagerinfo.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                console.log("OUTPUT", output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function setCredentials(target, username, password){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        //PS 7 hack to properly pass the quotation marks in string
        password = password.replace ('"', '""');

        let parameters = [{
            name: "sourcePath",
            value: target
        },{
            name: "username",
            value: username
        },{
            name: "password",
            value: password
        }]

        ps.addCommand(isDevelopment ? './psscripts/set-credentials.ps1' : './resources/psscripts/set-credentials.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function getFileshareInfo(share){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        

        let parameters = [{
            name: "serverResource",
            value: share.Address
        }]

        ps.addCommand(isDevelopment ? './psscripts/get-smbdriveinfo.ps1' : './resources/psscripts/get-smbdriveinfo.ps1').then(() => {
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                console.log("OUTPUT", output);
                resolve(output);
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function getInstalledDrivers() {
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        // ps.addCommand('"' + path.join(rootPath, '/psscripts/get-printerinfo.ps1') + '"');
        ps.addCommand(isDevelopment ? './psscripts/get-printerinfo.ps1' : './resources/psscripts/get-printerinfo.ps1');

        ps.invoke()
            .then(output => {
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
    });

    return promise;
}

function createLnkShortcut(destination, url, displayname){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [];

        parameters.push({
            name: "TempDestination",
            value: destination
        });

        parameters.push({
            name: "Url",
            value: url
        });

        parameters.push({
            name: "ShortcutDisplayName",
            value: displayname
        });

        ps.addCommand(isDevelopment ? './psscripts/create-urlfile.ps1' : './resources/psscripts/create-urlfile.ps1').then(()=>{
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                // console.log(output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function createShortcut(destination, executable, displayname, iconfile, workingdirectory, params){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [];

        parameters.push({
            name: "TempDestination",
            value: destination
        });

        parameters.push({
            name: "ShortcutTargetPath",
            value: executable
        });

        parameters.push({
            name: "ShortcutDisplayName",
            value: displayname
        });

        if (iconfile){
            parameters.push({
                name: "IconFile",
                value: iconfile
            });
        }
        
        if (workingdirectory){
            parameters.push({
                name: "WorkingDirectory",
                value: workingdirectory
            })
        }

        if (params){
            parameters.push({
                name: "ShortcutArguments",
                value: params
            });
        }

        ps.addCommand(isDevelopment ? './psscripts/create-shortcut.ps1' : './resources/psscripts/create-shortcut.ps1').then(()=>{
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                // console.log(output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function launchAppPS(path, params) {
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [];

        if (path){
            parameters.push({
                name: "executable",
                value: path
            })            
        }

        if (params){
            parameters.push({
                name: "params",
                value: params
            });
        }

        ps.addCommand(isDevelopment ? './psscripts/launch.ps1' : './resources/psscripts/launch.ps1').then(()=>{
            ps.addParameters(parameters)

            ps.invoke()
            .then(output => {
                // console.log(output);
                resolve(JSON.parse(output));
            })
            .catch(err => {
                console.log(err);
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });

        
    });

    return promise;
}

function openPrinterDialog() {
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        // ps.addCommand(path.join(rootPath,'/psscripts/show-printersettings.ps1'));
        ps.addCommand(isDevelopment ? './psscripts/show-printersettings.ps1' : './resources/psscripts/show-printersettings.ps1');


        ps.invoke()
            .then(output => {
                resolve(output);
            })
            .catch(err => {
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
    });

    return promise;
}

function openCredentialManager(){

    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });
        
        let parameters = [{
            name: "executable",
            value: "rundll32.exe"
        },{
            name: "params",
            value: "keymgr.dll, KRShowKeyMgr"
        }];


        ps.addCommand(isDevelopment ? './psscripts/launch.ps1' : './resources/psscripts/launch.ps1').then(()=>{
            ps.addParameters(parameters);
           
            ps.invoke()
            .then(output => {
                resolve(output);
            })
            .catch(err => {
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function getStartupScriptStatus(){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [{
            name: "mode",
            value: "status"
        }];

        // ps.addCommand(path.join(rootPath,'/psscripts/show-printersettings.ps1'));
        ps.addCommand(isDevelopment ? './psscripts/register-autodrivemapper.ps1' : './resources/psscripts/register-autodrivemapper.ps1').then(()=>{
            ps.addParameters(parameters);

            ps.invoke()
            .then(output => {
                resolve(JSON.parse(output));
            })
            .catch(err => {
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

function setStartupScript(enable){
    let promise = new Promise((resolve, reject) => {

        const ps = new PowerShell({
            executionPolicy: 'Bypass',
            noProfile: true
        });

        let parameters = [{
            name: "mode",
            value: enable ? "Add" : "Remove"
        }];

        // ps.addCommand(path.join(rootPath,'/psscripts/show-printersettings.ps1'));
        ps.addCommand(isDevelopment ? './psscripts/register-autodrivemapper.ps1' : './resources/psscripts/register-autodrivemapper.ps1').then(()=>{
            ps.addParameters(parameters);

            ps.invoke()
            .then(output => {
                resolve(JSON.parse(output));
            })
            .catch(err => {
                reject(err);
            }).finally(() => {
                ps.dispose();
            });
        });
    });

    return promise;
}

module.exports = {
    mapDrive,
    disconnectDrive,
    addPrinter,
    launchAppPS,
    openCredentialManager,
    getInstalledDrivers,
    openPrinterDialog,
    getFileshareInfo,
    getStartupScriptStatus,
    setStartupScript,
    getCredentialManagerInfo,
    setCredentials,
    mapAllDrives,
    mapSPODrive,
    createShortcut,
    createLnkShortcut
};