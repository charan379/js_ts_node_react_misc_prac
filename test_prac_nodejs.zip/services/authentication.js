// Authorization Code Grant Flow
const jwtDecode = require('jwt-decode');
const axios = require('axios');
const path = require('path');
const url = require('url');
const process = require('process');
const isDevelopment = process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.resourcesPath);
const envVariables = require(path.join(rootPath, './env-variables'));

const keytar = require('keytar');
const os = require('os');
const { tenantid, authorityurl, clientId, redirectUri } = envVariables;
const REDIRECT_URI = redirectUri;
const keytarService = 'openid-oauth-tkeservice';
const keytarAccount = os.userInfo().username;

let accessToken = null;
let profile = null;
let refreshToken = null;

// testing
Date.prototype.addHours = function(h) {
  this.setTime(this.getTime() + (h*60*60*1000));
  return this;
}

function isAccessTokenValid(access_token){
  if (!access_token){
    return false;
  }

  try{
    let token = jwtDecode (access_token);
    const expiryDate = new Date(0);
    expiryDate.setUTCSeconds(token.exp);
    
    // console.debug("access token will expire on ", expiryDate.toString());
  
    if (new Date() > expiryDate){
      return false;
    }
  }
  catch (e){
    //if the token is invalid
    return false;
  }

  return true;
}

function destroyAccessToken(){
  accessToken = "Invalid-" + accessToken;
}

function getAccessToken() {
  let access_token = accessToken;

  //this will run into an error - but better than a complete crash
  if (!isAccessTokenValid(access_token)){
    console.log("access token is expired. refresh")
    refreshTokens();
  }

  return access_token;
}

function getProfile() {
  return profile;
}

function getAuthenticationURL() {
  var url= authorityurl
    + tenantid +'/oauth2/v2.0/authorize?' +
    'scope=openid User.Read profile offline_access Sites.Read.All&' +
    'response_type=code&' +
    'response_mode=fragment&'+
    'client_id=' + clientId + '&' +
    '&nonce=679011' + 
     //'&prompt=consent'+ //admin consent should be used - just for testing
    '&state=223344'+
    'redirect_uri=' + redirectUri;
  return url;
}

function refreshTokens() {
  return new Promise(async (resolve, reject) => {
    const refreshToken = await keytar.getPassword(keytarService, keytarAccount);

    if (!refreshToken)
      return reject();

    const refreshOptions = {
      method: 'POST',
      url: `${authorityurl}${tenantid}/oauth2/v2.0/token`,
      headers:{'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
      body: "grant_type=refresh_token&client_id="+clientId+"&refresh_token="+refreshToken,
      json: true,
    };

    axios.post(refreshOptions.url, refreshOptions.body, {
      headers: refreshOptions.headers
    }).then((res) => {
      accessToken = res.data.access_token;

      // Testing for better sso experience - refresh token expires after 90 days inactive - we
      // update the token whenever the app launches
      if (res.data.refresh_token && res.data.refresh_token.length > 0) {
        keytar.setPassword(keytarService, keytarAccount, res.data.refresh_token);
      }

      profile = jwtDecode(res.data.id_token);
      resolve();

    }).catch(async error => {
      await logout();
      return reject(error || body.error);
    });
  });
}

function getAccessTokenByRefreshToken(scope) {
  return new Promise(async (resolve, reject) => {
    const refreshToken = await keytar.getPassword(keytarService, keytarAccount);

    if (!refreshToken) {
      return reject();
    }

    const refreshOptions = {
      method: 'POST',
      url: `${authorityurl}${tenantid}/oauth2/v2.0/token`,
      headers:{'Content-Type': 'application/x-www-form-urlencoded'},
      body: "grant_type=refresh_token&client_id="+clientId+"&refresh_token="+refreshToken + (scope ? "&scope=" + scope : ""),
      json: true
    };

    axios.post(refreshOptions.url, refreshOptions.body, {
      headers: refreshOptions.headers
    }).then((res) => {
      resolve(res.data.access_token);
    }).catch(error => {
      return reject(error);
    });

  });
}

function loadTokens(callbackURL) {
  return new Promise((resolve, reject) => {
    const urlParts = url.parse(callbackURL, true);
    let code = urlParts.hash.match(/\#(?:code)\=([\S\s]*?)\&/)[1]

    const refreshOptions = {
      method: 'POST',
      url: `${authorityurl}${tenantid}/oauth2/v2.0/token`,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: "grant_type=authorization_code&client_id="+clientId+"&code="+code+"&redirect_uri="+REDIRECT_URI
    };

    axios.post(refreshOptions.url, refreshOptions.body, {
      headers: refreshOptions.headers
    }).then((res) => {
      
      
      accessToken = res.data.access_token;
      profile = jwtDecode(res.data.id_token);
      refreshToken = res.data.refresh_token;
      
      keytar.setPassword(keytarService, keytarAccount, res.data.refresh_token);
      resolve();

    }).catch(async error => {
      await logout();
      return reject(error || body.error);
    });
  });
}

async function logout() {
  await keytar.deletePassword(keytarService, keytarAccount);
  accessToken = null;
  profile = null;
  refreshToken = null;
}

function getLogOutUrl() {
  return `${authorityurl}common/oauth2/logout`;
}

module.exports = {
  getAccessToken,
  destroyAccessToken,
  getAuthenticationURL,
  getLogOutUrl,
  getProfile,
  loadTokens,
  logout,
  refreshTokens,
  getAccessTokenByRefreshToken
};