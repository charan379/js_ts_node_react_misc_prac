const AutoLaunch = require('auto-launch');
const process = require('process');
const path = require('path');

const isDevelopment = process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.resourcesPath);
const config = require(path.join(rootPath, './env-variables'));

class AutoRun{

    constructor(){
        this.autolauncher = new AutoLaunch({
            name: config.appname,
            path: isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.execPath)
        });
    }

    disable(){
        this.autolauncher.isEnabled()
        .then((isEnabled)=>{
            if(isEnabled){
                this.autolauncher.disable();
            }

            return;
        }).catch(function(err){
            // ignore
        });;
    }

    enable(){
        this.autolauncher.isEnabled()
        .then((isEnabled)=>{
            if(isEnabled){
                return;
            }
            
            this.autolauncher.enable();
        })
        .catch(function(err){
            // ignore
        });
    }
}

module.exports = AutoRun;