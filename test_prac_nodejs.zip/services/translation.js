const i18n = require('i18next');
const path = require('path');
const i18nextBackend = require('i18next-fs-backend');
const process = require('process');
const isDevelopment = process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.resourcesPath);
const config = require(path.join(rootPath, './env-variables'));

// isDevelopment ? './psscripts/add-printer.ps1' : './resources/psscripts/add-printer.ps1'
const i18nextOptions = {
  backend:{
    loadPath: isDevelopment ? path.join(__dirname, '../locales/{{lng}}/{{ns}}.json') : path.join(__dirname, '../../../resources/locales/{{lng}}/{{ns}}.json')
  },
  interpolation: {
    escapeValue: false
  },
  fallbackLng: config.fallbackLng,
  whitelist: config.languages.map(a=>a.code)
};

console.log(isDevelopment ? path.join(__dirname, '../locales/{{lng}}/{{ns}}.json') : path.join(__dirname, '../../../resources/locales/{{lng}}/{{ns}}.json'))
 
i18n.use(i18nextBackend);
 
// initialize if not already initialized
if (!i18n.isInitialized) {
  i18n.init(i18nextOptions);
}
 
module.exports = i18n;