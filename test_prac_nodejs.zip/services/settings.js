const electron = require('electron');
const path = require('path');
const fs = require('fs');

class Store {
  constructor(opts) {
    this.defaultOpts = opts;
    this.opts = opts;
    const userDataPath = (electron.app || electron.remote.app).getPath('userData');
    this.path = path.join(userDataPath, opts.configName + '.json');
    this.data = parseDataFile(this.path, opts.defaults);
  }

  exists(){
    const userDataPath = (electron.app || electron.remote.app).getPath('userData');
    this.path = path.join(userDataPath, this.opts.configName + '.json');
    return fs.existsSync(this.path);
  }

  filename(){
    return this.path;
  } 

  reset(){
    return new Promise((resolve, reject)=>{
      if (this.exists()){
        fs.unlink(this.path, (err) => {
          if (err) {
              reject(err);
              return;
          }

          this.data = parseDataFile(this.path, this.defaultOpts.defaults);
          resolve();
        });
      }
      else{
        resolve();
      }
    });
  }
  
  get(key) {
    return this.data[key];
  }

  hasKey(key){
    if (this.data[key] != undefined){
      return true;
    }
    return false;
  }
  
  set(key, val) {
    this.data[key] = val;
    fs.writeFileSync(this.path, JSON.stringify(this.data, null, "\t"));
  }
}

function parseDataFile(filePath, defaults) {
  try {
    return JSON.parse(fs.readFileSync(filePath));
  } catch(error) {
    return defaults;
  }
}

module.exports = Store;