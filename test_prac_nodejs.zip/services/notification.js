const notifier = require('node-notifier');
const path = require('path');

class Notification{

    constructor(callback){
        this.notifier = notifier;
        this.callback = callback;
    }

    notify (title, message, icon = null, wait = true, force = false){
        // if the user does not want any notifications
        if (!global.userConfig.get("sendnotifications") && !force){
            return;
        }

        if (this.callback){
            this.notifier.on('click', (notifierObject, options, event) => {
               this.callback();
            });
        }

        this.notifier.notify({
            'title': title,
            'message': message,
            'icon': icon ? icon : path.normalize(`${__dirname}`) + '/../main/appicon/png/32x32.png',
            'wait': wait
        });

       
    }
}

module.exports = Notification;

