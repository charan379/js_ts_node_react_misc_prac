const Poller = require('./polling');
const dc = require('./datacontext');
const Notification = require('./notification');
const moment = require("moment");
const i18n = require('./translation');

class ActivityManager {
    constructor(window) {
        this.window = window;
    }

    handleAnnouncements(polltime) {
        try {
            let poll = new Poller(polltime);
            let lastNotificationTime = moment(Date.now());
            let notifier = new Notification(callback);

            function callback() {
                if (this.window) {
                    this.window.webContents.send('route', "news");
                }
            }

            poll.poll();
            poll.onPoll(() => {
                let startDate = lastNotificationTime;
                let shouldNotify = false;

                dc.loadnews(5).then((news) => {
                    let endDate = moment(Date.now());

                    news.data.value.some(newsEntry => {
                        let compareDate = moment(newsEntry.lastModifiedDateTime);
                        shouldNotify = compareDate.isBetween(startDate, endDate);

                        return shouldNotify; //if true breaks loop
                    });

                    if (shouldNotify) {
                        lastNotificationTime = moment(Date.now());
                        notifier.notify(i18n.t("announcements.notify_announcements_title"), i18n.t("announcements.notify_announcements_body"));
                    }

                    poll.poll();
                });
            });
        }
        catch (e) {
            // don't flood
        }
    }
}

module.exports = ActivityManager;