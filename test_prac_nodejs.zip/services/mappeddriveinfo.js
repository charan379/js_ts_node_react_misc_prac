const electron = require('electron');
const path = require('path');
const fs = require('fs');

class MappedDriveInfo {
    constructor(opts) {
        this.opts = opts;
        const userDataPath = (electron.app || electron.remote.app).getPath('userData');
        this.path = path.join(userDataPath, opts.configName + '.json');
        this.data = parseDataFile(this.path, opts.defaults);
    }

    exists() {
        const userDataPath = (electron.app || electron.remote.app).getPath('userData');
        this.path = path.join(userDataPath, this.opts.configName + '.json');
        return fs.existsSync(this.path);
    }

    filename(){
        return this.path;
    }

    count(){

        if (!this.data){
            return 0;
        }

        return Object.keys(this.data).length;
    }

    removeFile(){

        return new Promise((resolve, reject)=>{

            if (this.exists()){
                fs.unlink(this.path, (err) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve();
                });
            }
            
        });
    }

    getAll(){
        if (!this.data){
            return [];
        }

        let result = [];

        for (var key in this.data) {
            result.push(this.data[key]);
        }
        return result;
    }

    get(key) {
        if (!this.data){
            return null;
        }
        return this.data[key];
    }

    remove(key){
        delete this.data[key];

        fs.writeFileSync(this.path, JSON.stringify(this.data, null, "\t"));
    }

    // key is drive path, val is payload
    set(key, val) {

        if (!this.exists()){
            fs.writeFileSync(this.path,"");
            this.data = {};
        }

        this.data[key] = val;
        fs.writeFileSync(this.path, JSON.stringify(this.data, null, "\t"));
    }
}

function parseDataFile(filePath, defaults) {
    try {
      return JSON.parse(fs.readFileSync(filePath));
    } catch(error) {
      return defaults;
    }
  }
  
  module.exports = MappedDriveInfo;