const { shell } = require('electron');
const axios = require('axios');
const path = require('path');
const authService = require('./authentication');
const process = require('process');
const isDevelopment = process.env.NODE_ENV === 'development';
const rootPath = isDevelopment ? path.normalize(`${global.__basedir}`) : path.normalize(process.resourcesPath);
const appConfig = require(path.join(rootPath, './env-variables'));
const moment = require('moment');

let cachedProfile = null;
var retry = 0;

function getProfile(includeDetails) {
  //this is soley based on the token info and might be preferred for faster init time
  if (!includeDetails) {
    return authService.getProfile();
  }

  let promise = new Promise((resolve, reject) => {
    let url = 'https://graph.microsoft.com/beta/me';
    retry = 0;
    axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
      },
    }).then((result) => {
      console.log("Query Graph For Profile Information")
      let profileDetails = {
        surname: result.data.surname,
        streetAddress: result.data.streetAddress,
        userPrincipalName: result.data.userPrincipalName,
        state: result.data.state,
        usageLocation: result.data.usageLocation,
        preferredLanguage: result.data.preferredLanguage,
        postalCode: result.data.postalCode,
        officeLocation: result.data.officeLocation,
        mobilePhone: result.data.mobilePhone,
        mail: result.data.mail,
        jobTitle: result.data.jobTitle,
        givenName: result.data.givenName,
        displayName: result.data.displayName,
        department: result.data.department,
        country: result.data.country,
        city: result.data.city,
        businessPhones: result.data.businessPhones,
        faxNumber: result.data.faxNumber,
        rawValues: result.data
      }

      cachedProfile = cachedProfile;

      resolve(profileDetails);
    }).catch((error) => {

      if (error || error.response.status === 401){
        //we try to refresh it one time
        authService.refreshTokens().then(()=>{
          if (retry === 0){
            getProfile(includeDetails).then((r)=>{
              resolve(r);
            });
            retry = 1;
            return;
          }
          reject();
        });
      }

      // console.log(error);
      // reject(null);
    });
  });

  return promise;
}

function getUserLastPwdChange() {

  let promise = new Promise((resolve, reject) => {
    let url = 'https://graph.microsoft.com/beta/me';

    axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
      },
    }).then((result) => {

      url = "https://graph.microsoft.com/beta/users/"+ result.data.userPrincipalName + "?$select=displayName,lastPasswordChangeDateTime"

      axios.get(url, {
        headers: {
          'Authorization': `Bearer ${authService.getAccessToken()}`,
          'content-type': 'application/json',
        },
      }).then((result) => {
        resolve(result.data.lastPasswordChangeDateTime);
      }).catch((error) => {
        window.console && console.log(error);
        reject(null);
      });
      
    }).catch((error) => {
      window.console && console.log(error);
      reject(null);
    });
  });

  return promise;
}

function getProfileImage() {
  let promise = new Promise((resolve, reject) => {
    var url = 'https://graph.microsoft.com/beta/me/photos/48x48/$value';
    axios.get(url, {
      responseType: 'arraybuffer',
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'image/jpg',
      },
    }).then((response) => { //funky return blob
      let photo = 'data:' + response.headers['content-type'] + ';base64,' + Buffer.from(response.data, 'binary').toString('base64');
      resolve(photo);
    }).catch((error) => {
      typeof window !== 'undefined' && window.console && console.log(error);
      reject(null);
    });
  });

  return promise;
}

function loadnews(count = 20) {
  let promise = new Promise((resolve, reject) => {
    retry = 0;
    var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + appConfig.announcement_list_id
      + '/items?expand=fields(select=Id,Title,WikiField,_TopicHeader,Description,Created, Modified,NewsType,PromotedState)&$filter=fields/PromotedState eq 2&$top=' + count + '&$orderby=fields/Created desc';
    axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      },
    }).then((response) => {
      
      //just sligh transform for dates
      response.data.value.forEach(element => {
        element.lastModifiedDateTimeFormatted = moment(element.lastModifiedDateTime).fromNow()
        element.createdDateTimeFormatted = moment(element.createdDateTime).fromNow();
      });

      resolve(response);
    }).catch((error) => {
      // testing
      if (error.response.status === 401){
        //we try to refresh it one time
        authService.refreshTokens().then(()=>{
          if (retry === 0){
            loadnews().then((r)=>{
              resolve(r);
            });
            retry = 1;
            return;
          }
          reject();
        }).catch(()=>{
          reject(error);
          throw new Error(error);
        });
      }
      else if (error){
        reject(error);
        throw new Error(error);
      }
      else{
        reject();
      }
    });
  });

  return promise;
}

function loadsites(count = 20) {
  let promise = new Promise((resolve, reject) => {
    retry = 0;
    // console.log(appConfig.siteslist_id)
    var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + appConfig.siteslist_id
      + '/items?expand=fields(select=Id,Title,Description,SiteUrl,Created,Modified,FSObjType)&$top=' + count + '&$orderby=fields/Created desc'; //does currently not support filter?
   

      axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      },
    }).then((response) => {
      
      let filtered = [];
      filtered.data = [];
      filtered.data.value = [];

      //just simple transform
      response.data.value.forEach(element => {
        element.lastModifiedDateTimeFormatted = moment(element.lastModifiedDateTime).fromNow()
        element.createdDateTimeFormatted = moment(element.createdDateTime).fromNow();

        if (element.fields.FSObjType === '0'){ //filter out folders
          filtered.push(element);
        }
      });

      resolve(filtered);
    }).catch((error) => {
      // testing
      if (error.response.status === 401){
        //we try to refresh it one time
        authService.refreshTokens().then(()=>{
          if (retry === 0){
            loadsites().then((r)=>{
              resolve(r);
            });
            retry = 1;
            return;
          }
          reject();
        }).catch(()=>{
          reject(error);
          throw new Error(error);
        });
      }
      else if (error){
        reject(error);
        throw new Error(error);
      }
      else{
        reject();
      }
    });
  });

  return promise;
}

function openLinkInExternalBrowser(link) {
  shell.openExternal(link);
}

function queryPrinters(query) {
  let promise = new Promise((resolve, reject) => {
    retry = 0;
    console.log(query);
    var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + appConfig.printerlist_id 
      + '/items?expand=fields(select=Id,Title,IPAddress,Location)&filter=startswith(fields/Title,\'' + query + '\')';
    // console.log(url)
    axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      },
    }).then((response) => {
      resolve(response);
    }).catch((error, error2) => {
      authService.refreshTokens().then(()=>{
        if (retry === 0){
          queryPrinters().then((r)=>{
            resolve(r);
          });
          retry = 1;
          return;
        }
        reject();
      });
      reject(error);
    });
  });
  return promise;
}

function getTopFileshares() {  

  let promise = new Promise((resolve, reject) => {
    retry = 0;
    var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + appConfig.filesharelist_id 
      + '/items?expand=fields(select=Id,Title,Fileshare,Top,CredentialsRequired,Address,Remarks,ShareType)&filter=fields/Top eq 1'
    // console.log(url)
    axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      },
    }).then((response) => {

      

      resolve(response.data);
    }).catch((error) => {
      if (error.response.status === 401){
        //we try to refresh it one time
        authService.refreshTokens().then(()=>{
          if (retry === 0){
            getTopFileshares().then((r)=>{
              resolve(r);
            });
            retry = 1;
            return;
          }
          reject();
        });
      }

      reject(error);
    });
  });
  return promise;
}

function beautifyPlaceholder(value){
  let result = value;

  try{
    let components = result.split('_');
    let currentElement = components[components.length -1]
    currentElement = currentElement.replace(/([a-z](?=[A-Z]))/g, '$1 ')
    result = currentElement;
  }
  catch (e){
  }

  return result;
}

function getPlaceholders(str) {
  let regex = /\{(\w+)\}/g;
  let result = [];
  let match;

  while (match = regex.exec(str)) {
      result.push(match[1]);
  }

  return result;
}

function getOrgSettings(){
  let promise = new Promise((resolve, reject) => {
    retry = 0;
    
    var url = 'https://graph.microsoft.com/beta/sites/' + appConfig.servicesite_id + '/lists/' + "OrgSettings"
      + '/items?expand=fields(select=Id,Title,Settings,UpdateInfo,_ModerationStatus)&$orderby=fields/Modified desc';
    
      axios.get(url, {
      headers: {
        'Authorization': `Bearer ${authService.getAccessToken()}`,
        'content-type': 'application/json',
        'Prefer': 'HonorNonIndexedQueriesWarningMayFailRandomly'
      },
    }).then((response) => {
      resolve(response);
    }).catch((error, error2) => {
      //can happen during upgrade
      if (error.response && error.response.status === 404){
        reject("Not found");
        return;
      }

      authService.refreshTokens().then(()=>{
        if (retry === 0){
          getOrgSettings().then((r)=>{
            resolve(r);
          });
          retry = 1;
          return;
        }
        reject();
      });
      reject(error);
    });
  });
  return promise;
}


module.exports = {
  profileDetails : () => {

    let promise = new Promise((resolve, reject)=>{
      if (!cachedProfile){
        getProfile(true).then((result)=>{
          resolve (result);
        })
      }
      else{
        resolve(cachedProfile);
      }
    });

    return promise;
  },
  getProfileImage,
  getProfile,
  loadnews,
  openLinkInExternalBrowser,
  queryPrinters,
  getTopFileshares,
  // loadFileshareDetails,
  loadsites,
  getUserLastPwdChange,
  getPlaceholders,
  beautifyPlaceholder,
  getOrgSettings
}