const fs = require('fs');
const path = require('path');
const { app, shell } = require('electron');
const POWERSHELL = require('./powershell');

function writeShortcut(file) {

  return new Promise((resolve, reject) => {

    let extension = ".url"; //default hyperlink
    let filename = "";
    let content = "";

    if (file.linkType == "Rdp") {
      //rdp files are text files only - payload needs to be provided
      extension = ".rdp";
      content = file.fields.LinkContents;
      filename = path.join(path.normalize(app.getPath("temp")), file.fields.Title + extension)

      fs.writeFile(filename, content, err => {
        if (err) {
          reject(err)
          return;
        }

        //file written successfully
        resolve(filename);
      });
    }

    if (file.linkType == "Shortcut") {

      extension = ".lnk";
      filename = path.join(path.normalize(app.getPath("temp")), file.fields.Title + extension);

      return POWERSHELL.createShortcut(path.normalize(app.getPath("temp")),
        file.fields.LinkContents, file.fields.Title, null, null, null)
        .then((result) => {
          if (result.success) {
            resolve(filename);
          }
          else {
            reject(result);
          }
        }).catch(err => {
          reject(err);
        });
    }

    if (file.linkType == "Hyperlink") {
      filename = path.join(path.normalize(app.getPath("temp")), file.fields.URL.Description + ".url");

      return POWERSHELL.createLnkShortcut(path.normalize(app.getPath("temp")),
        file.fields.URL.Url, file.fields.URL.Description)
        .then((result) => {
          if (result.success) {
            resolve(filename);
          }
          else {
            reject(result);
          }
        }).catch(err => {
          reject(err);
        });
    }
  });
}

module.exports = {
  writeShortcut: writeShortcut
}